#!/usr/bin/env bash
# 07 - Install and/or configure CoreDNS for AZUL
#
# Works in three modes automatically:
#   A. No coredns Deployment exists (e.g. k3s started with --disable coredns):
#      -> installs CoreDNS from the bundled manifest using COREDNS_IMAGE
#   B. coredns exists but is broken (ImagePullBackOff on default image):
#      -> patches the Deployment image to COREDNS_IMAGE (if set)
#   C. coredns exists and is healthy:
#      -> just applies the *.kp.local hosts block and restarts.
#
# In all cases, the Azul hostnames from config.sh are added to the Corefile.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

MANIFEST="${SCRIPT_DIR}/charts/coredns-manifest.yaml"

echo "=== CoreDNS setup ==="

# --- Probe current state ----------------------------------------------------
HAS_DEPLOY=false
if kubectl -n kube-system get deployment coredns >/dev/null 2>&1; then
    HAS_DEPLOY=true
    CURRENT_IMAGE=$(kubectl -n kube-system get deployment coredns \
        -o jsonpath='{.spec.template.spec.containers[0].image}')
    echo "Existing CoreDNS deployment: image=${CURRENT_IMAGE}"
else
    echo "No coredns deployment in kube-system — will install from bundled manifest."
fi

# --- Path A: install from scratch -------------------------------------------
if [[ "$HAS_DEPLOY" == "false" ]]; then
    if [[ -z "${COREDNS_IMAGE:-}" ]]; then
        echo "FATAL: CoreDNS is not installed, but COREDNS_IMAGE is empty in config.sh."
        echo "Set COREDNS_IMAGE to the image in your offline registry, e.g.:"
        echo "  COREDNS_IMAGE=\"myregistry.local:5000/coredns/coredns:v1.11.3\""
        exit 1
    fi

    # Figure out what ClusterIP the DNS service should have.
    EXISTING_DNS=$(kubectl -n kube-system get svc kube-dns -o jsonpath='{.spec.clusterIP}' 2>/dev/null || true)
    if [[ -n "$EXISTING_DNS" ]]; then
        CLUSTER_DNS_IP="$EXISTING_DNS"
        echo "Reusing existing kube-dns ClusterIP: $CLUSTER_DNS_IP"
    else
        # Common defaults: k3s=10.43.0.10, kubeadm default=10.96.0.10
        if kubectl get svc -A -o jsonpath='{range .items[*]}{.spec.clusterIP}{"\n"}{end}' 2>/dev/null \
            | grep -q '^10\.43\.'; then
            CLUSTER_DNS_IP="10.43.0.10"
        else
            CLUSTER_DNS_IP="10.96.0.10"
        fi
        echo "Using CLUSTER_DNS_IP=${CLUSTER_DNS_IP} (probe)"
    fi

    INSTALL_HOSTS="        hosts {
            ${CLUSTER_IP} ${KEYCLOAK_HOST}
            ${CLUSTER_IP} ${OPENSEARCH_HOST}
            ${CLUSTER_IP} ${MINIO_HOST}
            ${CLUSTER_IP} ${MINIO_API_HOST}
            ${CLUSTER_IP} ${AZUL_HOST}
            fallthrough
        }"

    echo "Rendering CoreDNS manifest and applying..."
    HOSTS_BLOCK="$INSTALL_HOSTS" \
    COREDNS_IMAGE="$COREDNS_IMAGE" \
    CLUSTER_DNS_IP="$CLUSTER_DNS_IP" \
    python3 -c "
import os, sys, pathlib
src = pathlib.Path('${MANIFEST}').read_text()
out = (src
    .replace('__COREDNS_IMAGE__', os.environ['COREDNS_IMAGE'])
    .replace('__CLUSTER_DNS_IP__', os.environ['CLUSTER_DNS_IP'])
    .replace('__HOSTS_BLOCK__', os.environ['HOSTS_BLOCK']))
sys.stdout.write(out)
" | kubectl apply -f -

    echo "Waiting for CoreDNS to be ready..."
    kubectl -n kube-system rollout status deployment/coredns --timeout=180s
    echo ""
    echo "=== CoreDNS installed ==="
    kubectl -n kube-system get pods -l k8s-app=kube-dns -o wide
    exit 0
fi

# --- Path B: patch image if COREDNS_IMAGE is set and different ---------------
if [[ -n "${COREDNS_IMAGE:-}" && "$CURRENT_IMAGE" != "$COREDNS_IMAGE" ]]; then
    echo "Overriding image: ${CURRENT_IMAGE} -> ${COREDNS_IMAGE}"
    kubectl -n kube-system set image deployment/coredns coredns="$COREDNS_IMAGE"
fi

# --- Path C: replace hosts block in existing configmap -----------------------
# CoreDNS allows only ONE `hosts { }` block per server block. We must always:
#   1. Strip any existing `hosts { ... fallthrough ... }` block from the Corefile
#      (otherwise if the hostname domain changed — e.g. home.local -> kp.local —
#      we end up with two blocks and CoreDNS crashes with
#      "plugin/hosts: this plugin can only be used once per Server Block")
#   2. Insert the fresh block built from current config.sh hostnames.
# This is idempotent: running with unchanged config is a no-op patch.
echo "Replacing Azul hosts block in Corefile..."
PATCH_HOSTS="    hosts {
        ${CLUSTER_IP} ${KEYCLOAK_HOST}
        ${CLUSTER_IP} ${OPENSEARCH_HOST}
        ${CLUSTER_IP} ${MINIO_HOST}
        ${CLUSTER_IP} ${MINIO_API_HOST}
        ${CLUSTER_IP} ${AZUL_HOST}
        fallthrough
    }
"
kubectl -n kube-system get configmap coredns -o json | \
    HOSTS_BLOCK="$PATCH_HOSTS" python3 -c "
import json, sys, os, re
cm = json.load(sys.stdin)
corefile = cm['data']['Corefile']
# 1. Remove every existing hosts { ... fallthrough ... } block (DOTALL, non-greedy)
corefile = re.sub(r'^[ \t]*hosts \{[^}]*?fallthrough\s*\}\s*\n', '', corefile, flags=re.MULTILINE | re.DOTALL)
# 2. Insert fresh block after 'prometheus', 'ready', or '.:53 {' — whichever exists first
if re.search(r'    prometheus :\d+\n', corefile):
    corefile = re.sub(r'(    prometheus :\d+\n)', r'\1' + os.environ['HOSTS_BLOCK'], corefile, count=1)
elif re.search(r'    ready\n', corefile):
    corefile = re.sub(r'(    ready\n)', r'\1' + os.environ['HOSTS_BLOCK'], corefile, count=1)
else:
    corefile = re.sub(r'(\.:53 \{\n)', r'\1' + os.environ['HOSTS_BLOCK'], corefile, count=1)
cm['data']['Corefile'] = corefile
cm['metadata'].pop('resourceVersion', None)
json.dump(cm, sys.stdout)
" | kubectl apply -f -

# --- Restart and wait --------------------------------------------------------
echo "Restarting CoreDNS..."
kubectl -n kube-system rollout restart deployment/coredns

if ! kubectl -n kube-system rollout status deployment/coredns --timeout=120s; then
    echo ""
    echo "FATAL: CoreDNS failed to roll out. Current state:"
    kubectl -n kube-system get pods -l k8s-app=kube-dns
    BAD=$(kubectl -n kube-system get pods -l k8s-app=kube-dns --no-headers 2>/dev/null \
          | awk '$3 != "Running"{print $1; exit}')
    if [[ -n "$BAD" ]]; then
        echo ""
        echo "Events for $BAD:"
        kubectl -n kube-system describe pod "$BAD" | awk '/Events:/,/^$/' | tail -10
    fi
    echo ""
    echo "If this is ImagePullBackOff, set COREDNS_IMAGE in config.sh to an image reachable from this cluster."
    exit 1
fi

echo "=== CoreDNS configured — image: $(kubectl -n kube-system get deploy coredns -o jsonpath='{.spec.template.spec.containers[0].image}') ==="
