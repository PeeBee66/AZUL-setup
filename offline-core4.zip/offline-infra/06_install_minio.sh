#!/usr/bin/env bash
# 06 - Install MinIO (S3-compatible object storage)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/azul-infra"
VALUES="${SCRIPT_DIR}/values.yaml"

echo "=== Installing MinIO ==="

kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

if ! kubectl -n "$NAMESPACE" get secret s3-keys >/dev/null 2>&1; then
  echo "Creating MinIO S3 keys secret..."
  kubectl -n "$NAMESPACE" create secret generic s3-keys \
    --from-literal=accesskey="$S3_ACCESS_KEY" \
    --from-literal=secretkey="$S3_SECRET_KEY"
fi

helm install azul-minio "$CHART" \
  -n "$NAMESPACE" \
  -f "$VALUES" \
  --set keycloak.enable=false \
  --set kafka.enable=false \
  --set opensearch.enable=false \
  --set minio.backup.enable=false \
  --set minio.main.ingress.api.host="$MINIO_API_HOST" \
  --set minio.main.ingress.console.host="$MINIO_HOST" \
  --set minio.main.ingress.ingressClassName="$INGRESS_CLASS" \
  --set minio.main.ingress.secretName="$TLS_SECRET_MINIO" \
  --set minio.main.image="$IMG_MINIO"

echo "Waiting for MinIO..."
kubectl -n "$NAMESPACE" rollout status statefulset/s3-store-minio --timeout=180s

echo "=== MinIO installed ==="
