#!/usr/bin/env bash
# Uninstall AZUL infra components.
#
# USAGE:
#   ./uninstall_all.sh                   # uninstall ALL components (interactive)
#   ./uninstall_all.sh all               # same as above, no prompt
#   ./uninstall_all.sh all --purge       # ALSO delete PVCs + namespaces (full wipe)
#   ./uninstall_all.sh ingress           # only ingress-nginx controller
#   ./uninstall_all.sh ingress --purge   # also deletes namespace + ingressclass
#   ./uninstall_all.sh cert-manager      # NO-OP (managed by Rancher)
#   ./uninstall_all.sh strimzi           # only Strimzi operator
#   ./uninstall_all.sh opensearch-op     # only OpenSearch operator
#   ./uninstall_all.sh keycloak          # only Keycloak + Postgres (helm + secret)
#   ./uninstall_all.sh keycloak --purge  # also deletes postgres-claim PVC
#   ./uninstall_all.sh kafka             # only Kafka
#   ./uninstall_all.sh kafka --purge     # also deletes kafka PVC
#   ./uninstall_all.sh opensearch        # only OpenSearch + Dashboards + its certs
#   ./uninstall_all.sh opensearch --purge # also deletes opensearch PVC
#   ./uninstall_all.sh minio             # only MinIO
#   ./uninstall_all.sh minio --purge     # also deletes minio PVC
#   ./uninstall_all.sh coredns           # remove CoreDNS hosts entries
#   ./uninstall_all.sh purge             # JUST nuke PVCs + namespaces (after uninstalls)
#
# PURGE MODE:
#   Keycloak, OpenSearch, Kafka, and MinIO keep their PVCs by default so you
#   don't lose data. But if you're reinstalling with different PASSWORDS or
#   CONFIG, the old PVC state (e.g. Postgres's Keycloak DB with old passwords)
#   will override the new secrets — causing login failures.
#
#   Use --purge when you want a TRULY clean slate for fresh config.

set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

TARGET="${1:-all}"
PURGE_FLAG="${2:-}"
if [[ "$PURGE_FLAG" == "--purge" ]] || [[ "$TARGET" == "purge" ]]; then
    PURGE=true
else
    PURGE=false
fi

log() { echo "[uninstall] $*"; }

# --- Per-component uninstall functions ---------------------------------------

uninstall_ingress() {
    log "ingress-nginx:"
    # Safety: skip removal if any Ingress resource outside the AZUL namespaces
    # exists. Tearing down the shared controller would take out unrelated
    # workloads (HA, UniFi, Rancher, etc.) in a homelab cluster.
    # Use jsonpath instead of awk column positions (which depend on kubectl
    # output format — CLASS is actually column 3, not 4).
    OTHER_INGRESSES=$(kubectl get ingress -A -o jsonpath='{range .items[*]}{.metadata.namespace}/{.metadata.name} class={.spec.ingressClassName}{"\n"}{end}' 2>/dev/null \
        | awk '$1 !~ /^(azul|azul-infra|ingress-nginx)\// {print $1}')
    if [[ -n "$OTHER_INGRESSES" ]]; then
        log "  KEPT — other consumers of ingressClass 'nginx' detected:"
        echo "$OTHER_INGRESSES" | awk '{print "    Ingress: "$1}'
        log "  Force removal (AZUL only): not safe. Either drop those ingresses first,"
        log "  or run: helm uninstall ingress-nginx -n ingress-nginx"
        return 0
    fi
    helm uninstall ingress-nginx -n ingress-nginx 2>/dev/null && log "  removed" || log "  not found"
    if [[ "$PURGE" == "true" ]]; then
        kubectl delete ns ingress-nginx --ignore-not-found=true --wait=false 2>/dev/null | sed 's/^/  /'
        kubectl delete ingressclass nginx --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
    fi
}

# cert-manager is assumed installed by Rancher — NOT uninstalled by these scripts.
# Kept as a no-op for backward compat with older call sites.
uninstall_cert_manager() {
    log "cert-manager: managed by Rancher — skipping (use Rancher UI to uninstall)"
}

uninstall_strimzi() {
    log "Strimzi Kafka operator:"
    helm uninstall strimzi-kafka-operator -n kafka 2>/dev/null && log "  removed" || log "  not found"
    log "  (Strimzi CRDs kept — kafka namespace kept)"
}

uninstall_opensearch_op() {
    log "OpenSearch operator:"
    helm uninstall opensearch-operator -n opensearch-operator 2>/dev/null && log "  removed" || log "  not found"
}

uninstall_keycloak() {
    log "Keycloak + Postgres:"
    helm uninstall azul-keycloak -n azul-infra 2>/dev/null && log "  helm release removed" || log "  helm release not found"
    # Manually-created secret (03_install_keycloak.sh creates this outside helm)
    kubectl -n azul-infra delete secret keycloak --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
    if [[ "$PURGE" == "true" ]]; then
        # CRITICAL: postgres-claim contains the Keycloak DB. If you keep it,
        # old realm/users/passwords will persist and break reinstalls with new config.
        kubectl -n azul-infra delete pvc postgres-claim --ignore-not-found=true --wait=false 2>/dev/null | sed 's/^/  /'
        kubectl -n azul-infra delete pod -l app=postgres --grace-period=0 --force 2>/dev/null >/dev/null
    fi
}

uninstall_kafka() {
    log "Kafka:"
    helm uninstall azul-kafka -n azul-infra 2>/dev/null && log "  helm release removed" || log "  helm release not found"
    if [[ "$PURGE" == "true" ]]; then
        kubectl -n azul-infra delete pvc -l strimzi.io/cluster=azul-kafka --ignore-not-found=true --wait=false 2>/dev/null && log "  kafka PVCs removed"
        kubectl -n azul-infra delete pvc data-0-azul-kafka-nodes-0 --ignore-not-found=true --wait=false 2>/dev/null >/dev/null
    fi
}

uninstall_opensearch() {
    log "OpenSearch:"
    # cert-manager resources (setup-certs.sh creates these outside helm)
    kubectl -n azul-infra delete certificate keycloak-tls-cert --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
    kubectl -n azul-infra delete secret keycloak-tls --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
    # Credential secrets (05_install_opensearch.sh creates these outside helm)
    kubectl -n azul-infra delete secret azul-cluster-admincredentials azul-cluster-dashboardcredentials --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
    # Uninstall helm release (this removes CA/node/admin certs/issuers that are chart-owned)
    helm uninstall azul-opensearch -n azul-infra 2>/dev/null && log "  helm release removed" || log "  helm release not found"
    if [[ "$PURGE" == "true" ]]; then
        # PVC (data)
        kubectl -n azul-infra delete pvc data-azul-opensearch-nodes-0 --ignore-not-found=true --wait=false 2>/dev/null | sed 's/^/  /'
        # Chart-created secrets that may survive helm uninstall (cert-manager managed)
        kubectl -n azul-infra delete secret \
            azul-opensearch-ca-cert \
            azul-opensearch-certs \
            azul-opensearch-admin-certs \
            azul-opensearch-securityconfig \
            --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
        # Chart-created Certificate + Issuer CRs (helm should delete these, but
        # cert-manager may recreate the secrets — delete explicitly)
        kubectl -n azul-infra delete certificate \
            azul-opensearch-ca-certificate \
            azul-opensearch-certs \
            azul-opensearch-admin-certs \
            --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
        kubectl -n azul-infra delete issuer \
            azul-opensearch-selfsigned-issuer \
            azul-opensearch-ca-issuer \
            --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
        # ConfigMap (trust bundle, patched by setup-certs.sh)
        kubectl -n azul-infra delete configmap azul-opensearch-certs --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
    fi
}

uninstall_minio() {
    log "MinIO:"
    helm uninstall azul-minio -n azul-infra 2>/dev/null && log "  helm release removed" || log "  helm release not found"
    # Manually-created secret (06_install_minio.sh creates this outside helm)
    kubectl -n azul-infra delete secret s3-keys --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
    if [[ "$PURGE" == "true" ]]; then
        kubectl -n azul-infra delete pvc data-s3-store-minio-0 --ignore-not-found=true --wait=false 2>/dev/null | sed 's/^/  /'
    fi
}

uninstall_coredns() {
    log "CoreDNS hosts entries:"
    COREFILE=$(kubectl -n kube-system get configmap coredns -o jsonpath='{.data.Corefile}' 2>/dev/null)
    if echo "$COREFILE" | grep -q "$KEYCLOAK_HOST"; then
        HOSTS_ENTRIES=$(echo "$COREFILE" | awk '/hosts \{/,/^    \}/' | grep -vE 'hosts \{|^    \}|fallthrough' | wc -l)
        EXPECTED=5
        if [[ "$HOSTS_ENTRIES" -eq "$EXPECTED" ]]; then
            kubectl -n kube-system get configmap coredns -o json | python3 -c "
import json, sys, re
cm = json.load(sys.stdin)
cm['data']['Corefile'] = re.sub(r'    hosts \{[^}]*fallthrough\n    \}\n', '', cm['data']['Corefile'])
cm['metadata'].pop('resourceVersion', None)
print(json.dumps(cm))
" | kubectl apply -f - >/dev/null
            kubectl -n kube-system rollout restart deployment/coredns >/dev/null
            kubectl -n kube-system rollout status deployment/coredns --timeout=60s >/dev/null 2>&1
            log "  removed"
        else
            log "  KEPT — hosts block has $HOSTS_ENTRIES entries (expected $EXPECTED). Edit manually:"
            log "    kubectl -n kube-system edit configmap coredns"
        fi
    else
        log "  (no Azul hosts entries found)"
    fi
}

# Clean up Longhorn volumes that were bound to AZUL PVCs. Without this, the
# StorageClass's `Retain` policy leaves "Released" PVs + detached Longhorn
# volumes consuming the storage quota forever. On a small cluster this fills
# up fast and new installs fail to schedule replicas ("volume not ready for
# workloads" / robustness=faulted).
#
# Targets:
#   - PVs in `Released` phase whose claimRef pointed at azul-infra/azul
#   - Longhorn `volumes.longhorn.io` with no backing PV
clear_azul_longhorn_orphans() {
    if ! kubectl get crd volumes.longhorn.io >/dev/null 2>&1; then
        return 0   # Longhorn not installed — nothing to do
    fi
    log "Scanning for orphan Longhorn volumes from AZUL..."

    # Delete released PVs that belonged to azul namespaces
    local released_count=0
    for pv in $(kubectl get pv -o jsonpath='{range .items[?(@.status.phase=="Released")]}{.metadata.name}{"\n"}{end}' 2>/dev/null); do
        local claim_ns
        claim_ns=$(kubectl get pv "$pv" -o jsonpath='{.spec.claimRef.namespace}' 2>/dev/null)
        if [[ "$claim_ns" == "azul-infra" || "$claim_ns" == "azul" ]]; then
            kubectl delete pv "$pv" --wait=false >/dev/null 2>&1 && released_count=$((released_count+1))
        fi
    done
    [[ "$released_count" -gt 0 ]] && log "  deleted $released_count released PVs"

    # Wait briefly for Longhorn to reconcile, then delete any Longhorn volume
    # whose PV is now gone (orphan).
    sleep 5
    local orphan_count=0
    for vol in $(kubectl -n longhorn-system get volumes.longhorn.io --no-headers 2>/dev/null | awk '{print $1}'); do
        if ! kubectl get pv "$vol" >/dev/null 2>&1; then
            kubectl -n longhorn-system delete volume.longhorn.io "$vol" --wait=false >/dev/null 2>&1 && orphan_count=$((orphan_count+1))
        fi
    done
    [[ "$orphan_count" -gt 0 ]] && log "  deleted $orphan_count orphan Longhorn volumes"
    [[ "$released_count" -eq 0 && "$orphan_count" -eq 0 ]] && log "  (none found)"
}

# Force-clear namespaces stuck in Terminating because spec.finalizers still has
# 'kubernetes' even though all content and content-level finalizers are gone.
# This is a known Kubernetes quirk (not an AZUL bug): the /finalize subresource
# must be replaced directly, which is what we do here.
clear_stuck_namespaces() {
    local tries=0
    for ns in "$@"; do
        if ! kubectl get ns "$ns" >/dev/null 2>&1; then continue; fi
        # Wait up to 60s for normal termination first
        for i in $(seq 1 12); do
            kubectl get ns "$ns" >/dev/null 2>&1 || break
            sleep 5
        done
        if ! kubectl get ns "$ns" >/dev/null 2>&1; then continue; fi
        # Still there — is it stuck with empty content?
        local phase
        phase=$(kubectl get ns "$ns" -o jsonpath='{.status.phase}' 2>/dev/null)
        if [[ "$phase" != "Terminating" ]]; then continue; fi
        log "  $ns stuck in Terminating — clearing spec.finalizers via /finalize"
        kubectl get ns "$ns" -o json 2>/dev/null | \
            python3 -c "import sys,json;d=json.load(sys.stdin);d['spec']['finalizers']=[];print(json.dumps(d))" | \
            kubectl replace --raw "/api/v1/namespaces/${ns}/finalize" -f - >/dev/null 2>&1 \
            && log "    $ns: cleared" || log "    $ns: clear failed (inspect with kubectl get ns $ns -o yaml)"
    done
}

show_leftovers() {
    echo ""
    echo "=== Leftover PVCs in azul-infra (data preserved) ==="
    LEFTOVER=$(kubectl -n azul-infra get pvc --no-headers 2>/dev/null)
    if [[ -n "$LEFTOVER" ]]; then
        echo "$LEFTOVER" | awk '{printf "  %-40s %-10s %s\n", $1, $2, $4}'
        echo "  (delete: kubectl -n azul-infra delete pvc --all)"
    else
        echo "  (none)"
    fi
    echo ""
    echo "=== Leftover namespaces ==="
    for ns in azul-infra kafka opensearch-operator cert-manager; do
        kubectl get ns "$ns" >/dev/null 2>&1 && echo "  $ns"
    done
}

# --- Dispatch ----------------------------------------------------------------

case "$TARGET" in
    all)
        if [[ -z "${1:-}" ]]; then
            echo "=== Uninstalling AZUL Infrastructure (ALL) ==="
            if [[ "$PURGE" == "true" ]]; then
                echo "*** --purge mode: PVCs and namespaces will ALSO be deleted (data loss) ***"
            else
                echo "PVCs are kept by default (data preserved)."
            fi
            read -p "Continue? (y/N) " -r
            [[ "$REPLY" =~ ^[Yy]$ ]] || exit 0
        fi
        # Reverse order of install
        uninstall_minio
        uninstall_opensearch
        uninstall_kafka
        uninstall_keycloak
        uninstall_opensearch_op
        uninstall_strimzi
        uninstall_ingress
        uninstall_coredns
        if [[ "$PURGE" == "true" ]]; then
            log "Clearing finalizers on OpenSearch CRs (operator is gone, can't clean itself)..."
            for ns in azul-infra; do
                kubectl -n "$ns" get opensearchclusters -o name 2>/dev/null | while read cr; do
                    kubectl -n "$ns" patch "$cr" -p '{"metadata":{"finalizers":[]}}' --type=merge 2>/dev/null | sed 's/^/  /'
                done
                # Same for Kafka CRs (Strimzi gone)
                kubectl -n "$ns" get kafkas.kafka.strimzi.io -o name 2>/dev/null | while read cr; do
                    kubectl -n "$ns" patch "$cr" -p '{"metadata":{"finalizers":[]}}' --type=merge 2>/dev/null | sed 's/^/  /'
                done
                kubectl -n "$ns" get kafkanodepools.kafka.strimzi.io -o name 2>/dev/null | while read cr; do
                    kubectl -n "$ns" patch "$cr" -p '{"metadata":{"finalizers":[]}}' --type=merge 2>/dev/null | sed 's/^/  /'
                done
            done
            log "Removing namespaces (purge)..."
            kubectl delete ns azul-infra azul kafka opensearch-operator --wait=false 2>/dev/null | sed 's/^/  /'
            log "Removing Strimzi + OpenSearch CRDs (purge)..."
            kubectl get crd 2>/dev/null | grep -E 'strimzi|opster' | awk '{print $1}' | xargs -r kubectl delete crd --wait=false 2>/dev/null | sed 's/^/  /' | tail -3
            log "Clearing any stuck Terminating namespaces..."
            clear_stuck_namespaces azul-infra azul kafka opensearch-operator ingress-nginx
            clear_azul_longhorn_orphans
        fi
        show_leftovers
        ;;
    purge)
        # Nuke ALL PVCs and namespaces (assumes helm releases already removed)
        echo "=== PURGE — deleting all Azul PVCs and namespaces ==="
        echo "This is irreversible. Data will be lost."
        read -p "Continue? (y/N) " -r
        [[ "$REPLY" =~ ^[Yy]$ ]] || exit 0
        for ns in azul-infra azul; do
            if kubectl get ns "$ns" >/dev/null 2>&1; then
                log "Deleting PVCs in $ns..."
                kubectl -n "$ns" delete pvc --all --wait=false 2>/dev/null | sed 's/^/  /' | tail -10
            fi
        done
        log "Deleting namespaces..."
        kubectl delete ns azul-infra azul kafka opensearch-operator --wait=false 2>/dev/null | sed 's/^/  /'
        log "Removing Strimzi + OpenSearch CRDs..."
        kubectl get crd 2>/dev/null | grep -E 'strimzi|opster' | awk '{print $1}' | xargs -r kubectl delete crd --wait=false 2>/dev/null | sed 's/^/  /' | tail -3
        log "Clearing any stuck Terminating namespaces..."
        clear_stuck_namespaces azul-infra azul kafka opensearch-operator ingress-nginx
        clear_azul_longhorn_orphans
        ;;
    ingress|ingress-nginx) uninstall_ingress ;;
    cert-manager)      uninstall_cert_manager ;;
    strimzi)           uninstall_strimzi ;;
    opensearch-op|opensearch-operator) uninstall_opensearch_op ;;
    keycloak)          uninstall_keycloak ;;
    kafka)             uninstall_kafka ;;
    opensearch)        uninstall_opensearch ;;
    minio)             uninstall_minio ;;
    coredns)           uninstall_coredns ;;
    -h|--help|help)
        grep -E "^#( |$)" "$0" | sed 's/^# \{0,1\}//'
        exit 0
        ;;
    *)
        echo "ERROR: unknown component: $TARGET"
        echo "Run '$0 --help' for usage."
        exit 1
        ;;
esac

echo ""
echo "=== Uninstall complete ==="
