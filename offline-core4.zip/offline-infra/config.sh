#!/usr/bin/env bash
# Shared config for all infra install scripts.
# Edit these values for your target environment.

# --- Container Registry ---
# Set to your offline registry (e.g. "myregistry.local:5000")
# Leave empty to use upstream defaults (internet required).
REGISTRY="192.168.66.41:5000"

# --- Kubernetes ---
NAMESPACE="azul-infra"
CLUSTER_IP="192.168.66.201"

# --- Hostnames ---
AZUL_HOST="azul.kp.local"
KEYCLOAK_HOST="keycloak.azul.kp.local"
OPENSEARCH_HOST="opensearch.azul.kp.local"
MINIO_HOST="minio.azul.kp.local"
MINIO_API_HOST="minio-api.azul.kp.local"

# --- Ingress ---
# Which IngressClass to use for all ingresses. Usually "nginx".
# If your cluster uses a different controller (traefik, haproxy, contour, etc.)
# set it here — every chart's ingress resource will pick it up.
INGRESS_CLASS="nginx"

# Max request body size — OpenSearch uploads (CORS evidence, bulk index) can be
# several hundred MB. nginx default is 1m and will 413 on anything bigger.
# Format: nginx syntax ("600m", "1g", etc.) — must be accepted by your controller.
INGRESS_PROXY_BODY_SIZE="600m"

# TLS secret names. Each chart creates a Certificate (cert-manager) in these
# secrets; the Ingress then references them. Change only if you need to avoid
# a naming collision with something else in the namespace.
TLS_SECRET_KEYCLOAK="keycloak-tls"
TLS_SECRET_OPENSEARCH="opensearch-tls"
TLS_SECRET_OS_DASHBOARDS="dashboard-ingress-tls"
TLS_SECRET_MINIO="minio-tls"

# --- Container Images ---
# ingress-nginx (installed by 00_install_ingress.sh as a DaemonSet with hostPort 80/443)
IMG_INGRESS_CONTROLLER="192.168.66.41:5000/ingress-nginx/controller:v1.14.3"
IMG_INGRESS_WEBHOOK="192.168.66.41:5000/ingress-nginx/kube-webhook-certgen:v1.6.1"
IMG_INGRESS_OPENTELEMETRY="192.168.66.41:5000/ingress-nginx/opentelemetry-1.25.3:v20240813-b933310d"

# cert-manager (NOT installed by these scripts — assumed pre-installed by Rancher).
# Variables kept for reference / override in diagnostics only.
IMG_CERTMGR_CONTROLLER="quay.io/jetstack/cert-manager-controller:v1.17.2"
IMG_CERTMGR_WEBHOOK="quay.io/jetstack/cert-manager-webhook:v1.17.2"
IMG_CERTMGR_CAINJECTOR="quay.io/jetstack/cert-manager-cainjector:v1.17.2"
IMG_CERTMGR_STARTUP="quay.io/jetstack/cert-manager-startupapicheck:v1.17.2"

# Strimzi (defaultImageRegistry + defaultImageRepository cover all strimzi images)
IMG_STRIMZI_REGISTRY="192.168.66.41:5000"
IMG_STRIMZI_REPOSITORY="strimzi"
IMG_STRIMZI_TAG="0.50.0"

# OpenSearch Operator
IMG_OS_OPERATOR="192.168.66.41:5000/opensearchproject/opensearch-operator:2.8.0"
IMG_KUBE_RBAC_PROXY="192.168.66.41:5000/kubebuilder/kube-rbac-proxy:v0.15.0"

# Keycloak + Postgres
IMG_KEYCLOAK="192.168.66.41:5000/keycloak/keycloak:26.1"
IMG_POSTGRES="192.168.66.41:5000/postgres:17.4"

# Kafka (broker images come from Strimzi above, this is just kafkactl)
IMG_KAFKACTL="192.168.66.41:5000/deviceinsight/kafkactl:v5.13.0-ubuntu"

# OpenSearch cluster images (operator pulls these via the OpenSearchCluster CR)
# IMG_OS_REPO — sets spec.general.defaultRepo (prefix for image name when no explicit image set)
# IMG_OS_IMAGE + IMG_OS_TAG — full override for the OpenSearch cluster image (spec.general.image)
# IMG_OS_DASH_IMAGE + IMG_OS_DASH_TAG — full override for OpenSearch Dashboards (spec.dashboards.image)
# IMG_BUSYBOX — full override for the init-helper busybox used by the operator (spec.initHelper.image)
#
# Offline registry example:
#   IMG_OS_REPO="myregistry.local:5000/opensearchproject"
#   IMG_OS_IMAGE="myregistry.local:5000/opensearchproject/opensearch"
#   IMG_OS_TAG="2.19.1"
#   IMG_OS_DASH_IMAGE="myregistry.local:5000/opensearchproject/opensearch-dashboards"
#   IMG_OS_DASH_TAG="2.19.1"
#   IMG_BUSYBOX="myregistry.local:5000/busybox:1.37.0"
IMG_OS_REPO=""
IMG_OS_IMAGE="192.168.66.41:5000/opensearchproject/opensearch"
IMG_OS_TAG="3.2.0"
IMG_OS_DASH_IMAGE="192.168.66.41:5000/opensearchproject/opensearch-dashboards"
IMG_OS_DASH_TAG="3.2.0"
IMG_BUSYBOX="192.168.66.41:5000/busybox:1.37.0"

# MinIO
IMG_MINIO="192.168.66.41:5000/minio/minio:RELEASE.2025-09-07T16-13-09Z"

# --- Credentials ---
# OpenSearch internal users.
# Bcrypt hashes in values.yaml are AUTO-GENERATED at install time from these
# passwords, so changing a password here "just works" — no hash regen needed.
OS_ADMIN_PASS="cuvJ7K09EgApwfV2o9rQ7avR554uRP7e"       # admin user (full access)
OS_DASH_PASS="4xIQW0pLfSWFbvnHCJWpWJUqKCIYio4A"        # kibanaserver user (dashboards)
OS_MONITOR_PASS="cuvJ7K09EgApwfV2o9rQ7avR554uRP7e"     # monitor user (prometheus exporter)
OS_WRITER_PASS="cuvJ7K09EgApwfV2o9rQ7avR554uRP7e"      # azul_writer (metastore — must match offline-core/config.sh OS_WRITER_PASS)

# Keycloak
KC_ADMIN_PASSWORD="aDwQL6kkEl3MIcyTXBNMpCmC+oAPHWl0"
KC_DB_PASSWORD="MAgLmTJwrtesmwVuOp5vcVg8EIHBhmQ1"

# MinIO
S3_ACCESS_KEY="b26340be283b45acc0ba6afbf2789800"
S3_SECRET_KEY="38fbf2b72e819df4e9d7dbfaecf9983f20dae7a6ebec0611410af9331caf361e"

# --- Certificate Settings ---
# These control cert-manager Certificate resources created by setup-certs.sh
# and the OpenSearch chart (via --set overrides in 05_install_opensearch.sh).

# Private key
CERT_KEY_SIZE="2048"                  # 2048 or 4096
CERT_KEY_ALGORITHM="RSA"              # RSA or ECDSA

# Internal-use certs (long-lived — OpenSearch node/admin, Keycloak ingress)
CERT_INTERNAL_DURATION="87600h"       # 10 years (87600h)
CERT_INTERNAL_RENEW_BEFORE="8760h"    # 1 year before expiry

# Ingress cert (shorter-lived — Azul web UI)
CERT_WEB_DURATION="8760h"             # 1 year
CERT_WEB_RENEW_BEFORE="720h"          # 30 days before expiry

# OpenSearch cert DNS suffix (used in SANs: azul-opensearch.<suffix>, etc.)
# This is NOT a DNS domain — it's an identifier in the cluster certificate mesh.
CERT_OS_SUFFIX="opensearch"

# Root CA
CERT_CA_COMMON_NAME="Azul Test CA"
CERT_CA_DURATION="87600h"             # 10 years

# --- Keycloak Realm Setup ---
KC_LOCAL_PORT="18080"                 # local port for port-forward during realm setup

# Realm and client identities — referenced by install scripts AND values.yaml.
# Changing these requires matching edits in the chart's `security.oidc.*` settings,
# which the install scripts override via --set using these variables.
KC_REALM="azul"                       # Keycloak realm name
KC_WEB_CLIENT_ID="azul-web"           # Public OIDC client (browser login)
KC_OSD_CLIENT_ID="opensearch-dashboards"
KC_OSD_CLIENT_SECRET="opensearch-dashboards-secret"
KC_SERVICE_CLIENT_ID="azul-service"
KC_SERVICE_CLIENT_SECRET="azul-service-secret"

# Test user (regular user with all Azul roles, in 'general' group)
TEST_USER="basic"
TEST_PASSWORD="basic12345"
TEST_FIRST_NAME="Test"
TEST_LAST_NAME="User"

# Admin user (in 'opensearch-admins' group)
ADMIN_USER="azuladmin"
ADMIN_PASSWORD="admin12345"
ADMIN_FIRST_NAME="Admin"
ADMIN_LAST_NAME="User"

DOMAIN="kp.local"                     # Email domain for users (basic@kp.local etc.)

# --- Misc ---
TEMP_DIR="/tmp"                       # Where scripts write scratch files

# --- CoreDNS image override ---
# CoreDNS is a cluster component (installed by k3s/Talos/Rancher). Our 07_setup_coredns.sh
# only patches its configmap — it does NOT install CoreDNS.
#
# If CoreDNS is broken (ImagePullBackOff, wrong tag, registry blocked in your offline env),
# set COREDNS_IMAGE to force the deployment to use an image that IS pullable.
#
# Common scenarios:
#   - Offline/air-gapped cluster:
#       COREDNS_IMAGE="myregistry.local:5000/coredns/coredns:v1.13.2"
#   - Rancher using mirrored image with bad tag:
#       COREDNS_IMAGE="rancher/mirrored-coredns-coredns:v1.12.0"
#   - Pin to a known-working tag:
#       COREDNS_IMAGE="registry.k8s.io/coredns/coredns:v1.11.3"
#
# Leave empty to use whatever image the cluster installed by default.
# Check current: kubectl -n kube-system get deploy coredns -o jsonpath='{.spec.template.spec.containers[0].image}'
COREDNS_IMAGE="192.168.66.41:5000/coredns/coredns:v1.11.3"
