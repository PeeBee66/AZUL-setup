#!/usr/bin/env bash
# 00 - Install ingress-nginx controller (k3s, offline)
#
# Installs nginx-ingress as a DaemonSet with hostPort 80/443 so every node in
# the cluster can receive ingress traffic on its own IP. This matches how k3s
# normally runs traefik (hostPort), and works for a bare-metal / homelab
# cluster without a cloud LoadBalancer.
#
# Skips if ANY ingress-nginx release already exists.
#
# Uses images from config.sh (IMG_INGRESS_*). In an offline environment set
# REGISTRY or the IMG_INGRESS_* variables to point at your mirror.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/ingress-nginx-4.14.3.tgz"
NS="ingress-nginx"

# --- Detect existing install ---
EXISTING=$(helm list -A -o json 2>/dev/null | python3 -c "
import sys, json
for r in json.load(sys.stdin):
    if r['chart'].startswith('ingress-nginx'):
        print(f\"{r['name']}\t{r['namespace']}\t{r['chart']}\")" 2>/dev/null)
if [[ -n "$EXISTING" ]]; then
    echo "=== ingress-nginx already installed — skipping ==="
    echo "$EXISTING" | awk -F'\t' '{printf "  Release: %s  Namespace: %s  Chart: %s\n", $1, $2, $3}'
    echo ""
    echo "If you need to reinstall:"
    echo "$EXISTING" | awk -F'\t' '{printf "  helm uninstall %s -n %s\n", $1, $2}'
    exit 0
fi

# Also check for a non-helm install (manifests, k3s traefik, etc.)
if kubectl get ingressclass nginx >/dev/null 2>&1; then
    echo "=== ingressclass 'nginx' already exists (non-helm) — skipping install ==="
    kubectl get pods -A -l app.kubernetes.io/name=ingress-nginx 2>/dev/null || true
    exit 0
fi

# --- Split image refs into repository + tag (helm --set needs them separate) ---
split_image() {
    local ref="$1"
    local repo="${ref%:*}"
    local tag="${ref##*:}"
    echo "$repo $tag"
}
read CTRL_REPO CTRL_TAG <<<"$(split_image "$IMG_INGRESS_CONTROLLER")"
read WEBHOOK_REPO WEBHOOK_TAG <<<"$(split_image "$IMG_INGRESS_WEBHOOK")"
read OTEL_REPO OTEL_TAG <<<"$(split_image "$IMG_INGRESS_OPENTELEMETRY")"

echo "=== Installing ingress-nginx (DaemonSet, hostPort 80/443) ==="
echo "  controller: $IMG_INGRESS_CONTROLLER"
echo "  webhook:    $IMG_INGRESS_WEBHOOK"

# --- Install ---
# kind=DaemonSet + hostPort=true + service.type=ClusterIP
#   -> every node listens on :80 / :443, matching how k3s's built-in traefik works.
# admissionWebhooks.patch.enabled=false
#   -> skip the pre-install job that tries to pull kube-webhook-certgen. We disable
#      the admission webhook entirely below (simpler/faster, fine for homelab).
# ingressClassResource.default=true
#   -> makes "nginx" the default class so ingresses without a class still work.
helm install ingress-nginx "$CHART" \
  -n "$NS" --create-namespace \
  --set controller.kind=DaemonSet \
  --set controller.hostPort.enabled=true \
  --set controller.hostPort.ports.http=80 \
  --set controller.hostPort.ports.https=443 \
  --set controller.service.type=ClusterIP \
  --set controller.ingressClassResource.default=true \
  --set controller.admissionWebhooks.enabled=false \
  --set 'controller.tolerations[0].key=node-role.kubernetes.io/control-plane' \
  --set 'controller.tolerations[0].operator=Exists' \
  --set 'controller.tolerations[0].effect=NoSchedule' \
  --set controller.image.registry="${CTRL_REPO%%/*}" \
  --set controller.image.image="${CTRL_REPO#*/}" \
  --set controller.image.tag="$CTRL_TAG" \
  --set controller.image.digest="" \
  --set controller.image.digestChroot="" \
  --set controller.opentelemetry.image.registry="${OTEL_REPO%%/*}" \
  --set controller.opentelemetry.image.image="${OTEL_REPO#*/}" \
  --set controller.opentelemetry.image.tag="$OTEL_TAG" \
  --set controller.opentelemetry.image.digest="" \
  --set controller.admissionWebhooks.patch.image.registry="${WEBHOOK_REPO%%/*}" \
  --set controller.admissionWebhooks.patch.image.image="${WEBHOOK_REPO#*/}" \
  --set controller.admissionWebhooks.patch.image.tag="$WEBHOOK_TAG" \
  --set controller.admissionWebhooks.patch.image.digest=""

echo "Waiting for ingress-nginx controller DaemonSet to be ready..."
kubectl -n "$NS" rollout status daemonset/ingress-nginx-controller --timeout=180s

echo ""
echo "=== ingress-nginx installed ==="
kubectl -n "$NS" get pods -o wide | head -20
echo ""
echo "The controller is listening on port 80/443 on every node."
# Derive the domain from AZUL_HOST so this message stays honest if config.sh changes.
DOMAIN_TAIL="${AZUL_HOST#*.}"
echo "Point DNS (*.${DOMAIN_TAIL} -> $CLUSTER_IP) or use --resolve in curl."
