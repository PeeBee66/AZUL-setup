#!/usr/bin/env bash
# 08 - Configure Keycloak realm, roles, clients, and users
# Requires: Keycloak running (step 03), OpenSearch Dashboards needs this to stop crash-looping.
# Idempotent — safe to re-run (409 responses on existing resources are expected).
set -uo pipefail   # NOT -e: we want to continue even if an individual API call fails
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

echo "=== Configuring Keycloak ==="

KC_PASS=$(kubectl get secret keycloak -n "$NAMESPACE" -o jsonpath='{.data.KEYCLOAK_ADMIN_PASSWORD}' | base64 -d)
KC_PASS_ENCODED=$(python3 -c "import urllib.parse, sys; print(urllib.parse.quote(sys.argv[1], safe=''))" "$KC_PASS")
KC_URL="http://localhost:${KC_LOCAL_PORT}"

# Kill any existing port-forward on our port
pkill -f "port-forward.*${KC_LOCAL_PORT}:8080" 2>/dev/null
sleep 2

# Start port-forward
kubectl port-forward svc/keycloak -n "$NAMESPACE" "${KC_LOCAL_PORT}:8080" >/dev/null 2>&1 &
PF_PID=$!
sleep 5

cleanup() { kill "$PF_PID" 2>/dev/null; wait "$PF_PID" 2>/dev/null; }
trap cleanup EXIT

# Get admin token
echo "Getting admin token..."
TOKEN=$(curl -sf -X POST "${KC_URL}/realms/master/protocol/openid-connect/token" \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -d "username=admin&password=${KC_PASS_ENCODED}&grant_type=password&client_id=admin-cli" \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['access_token'])")

if [[ -z "$TOKEN" ]]; then echo "FATAL: Failed to get admin token"; exit 1; fi

api() {
    local method=$1 path=$2 data=${3:-}
    local code
    code=$(curl -s -o /dev/null -w '%{http_code}' -X "$method" "${KC_URL}${path}" \
      -H "Authorization: Bearer ${TOKEN}" \
      -H 'Content-Type: application/json' \
      ${data:+-d "$data"})
    echo "  $method $path -> $code"
    if [[ "$code" -ge 400 ]] && [[ "$code" != "409" ]]; then
        echo "    WARNING: unexpected $code"
    fi
}

api_get() {
    curl -s "${KC_URL}${1}" -H "Authorization: Bearer ${TOKEN}"
}

# Read a JSON array from stdin, print the .id where .name == $1 (empty on any error).
# Defensive against the API returning non-list (error body, port-forward drop, 401, etc.).
find_id_by_name() {
    python3 -c '
import sys, json
try:
    data = json.load(sys.stdin)
    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict) and item.get("name") == sys.argv[1]:
                print(item["id"]); break
except Exception:
    pass
' "$1"
}

# 1. Create realm
echo "Creating ${KC_REALM} realm..."
api POST "/admin/realms" \
  "{\"realm\":\"${KC_REALM}\",\"enabled\":true,\"displayName\":\"Azul Malware Repository\",\"accessTokenLifespan\":300,\"ssoSessionMaxLifespan\":36000}"

# 2. Create roles
echo "Creating realm roles..."
for role in azul-access azul_read azul_admin azul_write s-any s-official; do
    api POST "/admin/realms/${KC_REALM}/roles" "{\"name\":\"${role}\"}"
done

# 3. Create groups
echo "Creating groups..."
api POST "/admin/realms/${KC_REALM}/groups" '{"name":"general"}'
api POST "/admin/realms/${KC_REALM}/groups" '{"name":"opensearch-admins"}'

# 4. Create 'azul' client scope with realm-roles mapper
echo "Creating azul client scope..."
api POST "/admin/realms/${KC_REALM}/client-scopes" \
  '{"name":"azul","protocol":"openid-connect","attributes":{"include.in.token.scope":"true","display.on.consent.screen":"false"}}'

SCOPE_ID=$(api_get "/admin/realms/${KC_REALM}/client-scopes" | find_id_by_name "azul")

api POST "/admin/realms/${KC_REALM}/client-scopes/${SCOPE_ID}/protocol-mappers/models" \
  '{"name":"realm-roles","protocol":"openid-connect","protocolMapper":"oidc-usermodel-realm-role-mapper","config":{"multivalued":"true","claim.name":"roles","jsonType.label":"String","id.token.claim":"true","access.token.claim":"true","userinfo.token.claim":"true"}}'

api POST "/admin/realms/${KC_REALM}/client-scopes/${SCOPE_ID}/protocol-mappers/models" \
  '{"name":"subject","protocol":"openid-connect","protocolMapper":"oidc-sub-mapper","config":{"id.token.claim":"true","access.token.claim":"true","userinfo.token.claim":"true"}}'

# 5. Create 'audience' client scope
echo "Creating audience client scope..."
api POST "/admin/realms/${KC_REALM}/client-scopes" \
  '{"name":"audience","protocol":"openid-connect","attributes":{"include.in.token.scope":"true","display.on.consent.screen":"false"}}'

AUDIENCE_SCOPE_ID=$(api_get "/admin/realms/${KC_REALM}/client-scopes" | find_id_by_name "audience")

api POST "/admin/realms/${KC_REALM}/client-scopes/${AUDIENCE_SCOPE_ID}/protocol-mappers/models" \
  "{\"name\":\"${KC_WEB_CLIENT_ID}-audience\",\"protocol\":\"openid-connect\",\"protocolMapper\":\"oidc-audience-mapper\",\"config\":{\"included.client.audience\":\"${KC_WEB_CLIENT_ID}\",\"id.token.claim\":\"false\",\"access.token.claim\":\"true\",\"introspection.token.claim\":\"true\"}}"

# 6. Create web client (public, for Web UI)
echo "Creating ${KC_WEB_CLIENT_ID} client..."
api POST "/admin/realms/${KC_REALM}/clients" \
  "{\"clientId\":\"${KC_WEB_CLIENT_ID}\",\"enabled\":true,\"publicClient\":true,\"standardFlowEnabled\":true,\"directAccessGrantsEnabled\":true,\"rootUrl\":\"https://${AZUL_HOST}\",\"redirectUris\":[\"https://${AZUL_HOST}/*\",\"http://localhost:*\"],\"webOrigins\":[\"https://${AZUL_HOST}\",\"*\"],\"defaultClientScopes\":[\"openid\",\"profile\",\"email\",\"azul\",\"audience\"],\"optionalClientScopes\":[\"offline_access\"]}"

WEB_CLIENT_UUID=$(api_get "/admin/realms/${KC_REALM}/clients?clientId=${KC_WEB_CLIENT_ID}" | python3 -c '
import sys, json
try:
    d = json.load(sys.stdin)
    if isinstance(d, list) and d and isinstance(d[0], dict): print(d[0]["id"])
except Exception:
    pass')

ROLES_SCOPE_ID=$(api_get "/admin/realms/${KC_REALM}/client-scopes" | find_id_by_name "roles")
OFFLINE_SCOPE_ID=$(api_get "/admin/realms/${KC_REALM}/client-scopes" | find_id_by_name "offline_access")

api PUT "/admin/realms/${KC_REALM}/clients/${WEB_CLIENT_UUID}/optional-client-scopes/${ROLES_SCOPE_ID}"
api PUT "/admin/realms/${KC_REALM}/clients/${WEB_CLIENT_UUID}/optional-client-scopes/${OFFLINE_SCOPE_ID}"

# 7. Create OpenSearch Dashboards client (confidential)
echo "Creating ${KC_OSD_CLIENT_ID} client..."
api POST "/admin/realms/${KC_REALM}/clients" \
  "{\"clientId\":\"${KC_OSD_CLIENT_ID}\",\"enabled\":true,\"publicClient\":false,\"standardFlowEnabled\":true,\"directAccessGrantsEnabled\":false,\"rootUrl\":\"https://${OPENSEARCH_HOST}\",\"redirectUris\":[\"https://${OPENSEARCH_HOST}/*\"],\"webOrigins\":[\"https://${OPENSEARCH_HOST}\"],\"secret\":\"${KC_OSD_CLIENT_SECRET}\",\"defaultClientScopes\":[\"openid\",\"profile\",\"email\",\"azul\"]}"

# 8. Create service client (service account for API)
echo "Creating ${KC_SERVICE_CLIENT_ID} client..."
api POST "/admin/realms/${KC_REALM}/clients" \
  "{\"clientId\":\"${KC_SERVICE_CLIENT_ID}\",\"enabled\":true,\"publicClient\":false,\"serviceAccountsEnabled\":true,\"standardFlowEnabled\":false,\"directAccessGrantsEnabled\":false,\"secret\":\"${KC_SERVICE_CLIENT_SECRET}\",\"defaultClientScopes\":[\"openid\",\"profile\",\"azul\"]}"

# 9. Create test user
echo "Creating test user: ${TEST_USER}..."
api POST "/admin/realms/${KC_REALM}/users" \
  "{\"username\":\"${TEST_USER}\",\"enabled\":true,\"emailVerified\":true,\"firstName\":\"${TEST_FIRST_NAME}\",\"lastName\":\"${TEST_LAST_NAME}\",\"email\":\"${TEST_USER}@${DOMAIN}\",\"credentials\":[{\"type\":\"password\",\"value\":\"${TEST_PASSWORD}\",\"temporary\":false}]}"

USER_ID=$(api_get "/admin/realms/${KC_REALM}/users?username=${TEST_USER}" | python3 -c '
import sys, json
try:
    d = json.load(sys.stdin)
    if isinstance(d, list) and d and isinstance(d[0], dict): print(d[0]["id"])
except Exception:
    pass')

# 10. Assign roles to test user
ROLES_JSON=$(api_get "/admin/realms/${KC_REALM}/roles" | python3 -c '
import sys, json
wanted = ("azul-access","azul_read","azul_admin","azul_write","s-any","s-official")
try:
    d = json.load(sys.stdin)
    roles = [r for r in d if isinstance(r, dict) and r.get("name") in wanted] if isinstance(d, list) else []
except Exception:
    roles = []
print(json.dumps(roles))')

if [[ -n "$USER_ID" ]]; then
    curl -s -o /dev/null -w "  Assign roles -> %{http_code}\n" -X POST \
      "${KC_URL}/admin/realms/${KC_REALM}/users/${USER_ID}/role-mappings/realm" \
      -H "Authorization: Bearer ${TOKEN}" \
      -H 'Content-Type: application/json' \
      -d "$ROLES_JSON"
else
    echo "  WARNING: test user '${TEST_USER}' not found — skipping role assignment"
fi

GENERAL_GID=$(api_get "/admin/realms/${KC_REALM}/groups" | find_id_by_name "general")
if [[ -n "$GENERAL_GID" ]]; then
    api PUT "/admin/realms/${KC_REALM}/users/${USER_ID}/groups/${GENERAL_GID}" '{}'
else
    echo "  WARNING: 'general' group not found — test user not added to group (non-fatal)"
fi

# 11. Create admin user
echo "Creating admin user: ${ADMIN_USER}..."
api POST "/admin/realms/${KC_REALM}/users" \
  "{\"username\":\"${ADMIN_USER}\",\"enabled\":true,\"emailVerified\":true,\"firstName\":\"${ADMIN_FIRST_NAME}\",\"lastName\":\"${ADMIN_LAST_NAME}\",\"email\":\"${ADMIN_USER}@${DOMAIN}\",\"credentials\":[{\"type\":\"password\",\"value\":\"${ADMIN_PASSWORD}\",\"temporary\":false}]}"

ADMIN_USER_ID=$(api_get "/admin/realms/${KC_REALM}/users?username=${ADMIN_USER}" | python3 -c '
import sys, json
try:
    d = json.load(sys.stdin)
    if isinstance(d, list) and d and isinstance(d[0], dict): print(d[0]["id"])
except Exception:
    pass')

if [[ -n "$ADMIN_USER_ID" ]]; then
    curl -s -o /dev/null -w "  Assign roles -> %{http_code}\n" -X POST \
      "${KC_URL}/admin/realms/${KC_REALM}/users/${ADMIN_USER_ID}/role-mappings/realm" \
      -H "Authorization: Bearer ${TOKEN}" \
      -H 'Content-Type: application/json' \
      -d "$ROLES_JSON"

    OS_ADMIN_GID=$(api_get "/admin/realms/${KC_REALM}/groups" | find_id_by_name "opensearch-admins")
    if [[ -n "$OS_ADMIN_GID" ]]; then
        api PUT "/admin/realms/${KC_REALM}/users/${ADMIN_USER_ID}/groups/${OS_ADMIN_GID}" '{}'
    else
        echo "  WARNING: 'opensearch-admins' group not found — admin user not added to group (non-fatal)"
    fi
else
    echo "  WARNING: admin user '${ADMIN_USER}' not found — skipping role + group assignment"
fi

echo ""

# Kick the Dashboards pod: it's usually in kubelet exponential-backoff from
# crashes before the realm existed. Deleting forces an immediate restart with
# the realm now in place, instead of waiting out minutes of backoff.
OSD_POD=$(kubectl -n "$NAMESPACE" get pod -l opensearch.cluster.dashboards="azul-opensearch" \
    -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)
if [[ -n "$OSD_POD" ]]; then
    echo "Restarting OpenSearch Dashboards so it picks up the new realm..."
    kubectl -n "$NAMESPACE" delete pod "$OSD_POD" --force --grace-period=0 >/dev/null 2>&1 || true
fi

echo ""
echo "=== Keycloak configuration complete ==="
echo "Realm:      ${KC_REALM}"
echo "Web client: ${KC_WEB_CLIENT_ID}"
echo "Test user:  ${TEST_USER} / ${TEST_PASSWORD}"
echo "Admin user: ${ADMIN_USER} / ${ADMIN_PASSWORD}"
