AZUL Infrastructure - Offline Install Package
==============================================

Target: k3s cluster (air-gapped)


BEFORE YOU START
----------------
1. Load all container images from images.txt into your offline registry
2. Edit config.sh:
   - Set IMG_* variables to point each image at your offline registry
   - Set CLUSTER_IP to your k3s ingress IP
   - Set hostnames to match your domain
   - Set credentials (if you change OS_ADMIN_PASS / OS_DASH_PASS, regenerate
     the bcrypt hashes in values.yaml — see CREDENTIALS section below)
3. Edit values.yaml if you need to change:
   - Storage class (local-path -> your storage class)
   - Ingress class (nginx -> your ingress class)
   - Resource requests/limits
4. If your registry needs auth, add imagePullSecrets to values.yaml


INSTALL ORDER
-------------
Run each script in order. Wait for each to complete before the next.

  ./000_setup_certs.sh                # Verify cert-manager (installed by Rancher) is healthy
  ./00_install_ingress.sh             # nginx-ingress controller (DaemonSet, hostPort 80/443)
  ./01_install_strimzi.sh             # Kafka operator (CRDs)
  ./02_install_opensearch_operator.sh # OpenSearch operator (CRDs)
  ./03_install_keycloak.sh            # Keycloak + PostgreSQL (auth)
  ./04_install_kafka.sh               # Kafka broker (event store)
  ./05_install_opensearch.sh          # OpenSearch + Dashboards + Keycloak TLS cert + CA trust patch
  ./06_install_minio.sh               # MinIO (S3 object storage)
  ./07_setup_coredns.sh               # Install (if missing) and/or add *.kp.local entries to CoreDNS
  ./08_setup_keycloak.sh              # Create Azul realm, roles, clients, users


UPDATE (after install — push config.sh changes to running cluster)
------------------------------------------------------------------
  ./09_update.sh                # interactive menu
  ./09_update.sh passwords      # re-set Keycloak user passwords from config.sh
  ./09_update.sh certs          # force renewal of all TLS certs + restart dependent pods
  ./09_update.sh coredns        # re-apply CoreDNS hosts entries (after changing hostnames)
  ./09_update.sh all            # everything

  To change OpenSearch internal user passwords (admin/kibanaserver/azul_writer),
  see the manual steps documented at the top of 09_update.sh.


RECOVERY (uninstall a single failed component and re-install it)
----------------------------------------------------------------
  ./uninstall_all.sh --help                     # list components
  ./uninstall_all.sh opensearch-op              # e.g. if step 02 failed
  ./02_install_opensearch_operator.sh           # retry


ARCHITECTURE & TRAFFIC FLOW
---------------------------
All pod-to-pod traffic stays inside the cluster (10.244.0.0/16). Only the
ingress exposes services externally.

  [Browser]
      |  https://azul.kp.local           <-- External (via nginx ingress on CLUSTER_IP:443)
      v
  +------------------------+
  | nginx-ingress          |
  +------------------------+
      |
      +--> webui                         (static UI files)
      +--> restapi-0                     (main API)
              |
              +--> opensearch.azul-infra.svc:9200   (search/store — HTTPS, self-signed)
              +--> kafka.azul-infra.svc:9092        (event dispatch — plain TCP)
              +--> redis.azul.svc:6379              (session cache)
              +--> s3-store-minio.azul-infra.svc:9000  (binary storage — HTTP)
              +--> keycloak.azul.kp.local:443       (JWT validation, JWKS — via ingress)

SERVICE DNS (cluster-internal, from values.yaml):
  external.opensearch.endpoint: https://azul-opensearch.azul-infra.svc:9200
  external.filestore.endpoint: s3-store-minio.azul-infra.svc:9000
  external.kafka.endpoint:     azul-kafka-kafka-bootstrap.azul-infra.svc:9092
  external.redis.endpoint:     azul-redis-master:6379

AUTH FLOW:
  1. Browser -> Keycloak -> gets JWT
  2. Browser -> REST API with JWT
  3. REST API validates JWT by fetching JWKS from Keycloak (outbound via ingress)
  4. REST API forwards JWT to OpenSearch (cluster-internal)
  5. OpenSearch validates JWT itself by fetching JWKS from Keycloak

PORTS (internal, none exposed outside ingress):
  restapi        8000 HTTP
  webui          8080 HTTP
  dispatcher     8111 HTTP
  redis          6379 TCP
  opensearch     9200 HTTPS (+ 9300 TCP transport)
  kafka          9092 TCP
  minio          9000 HTTP (+ 9001 console)
  keycloak       8080 HTTP
  postgres       5432 TCP


CERTIFICATE INFRASTRUCTURE
--------------------------
All TLS certs come from a single self-signed CA created by cert-manager.
There is NO single "setup-certs" script — cert creation is split between
the helm chart templates and the install scripts:

CHAIN OF TRUST:
  azul-opensearch-selfsigned-issuer  (root, self-signed)
      |
      +-> azul-opensearch-ca-certificate  ->  azul-opensearch-ca-cert (Secret)
                                              (this is THE CA for everything)
              |
              +-> azul-opensearch-ca-issuer  (CA Issuer)
                      |
                      +-> azul-opensearch-certs      (OpenSearch node TLS)
                      +-> azul-opensearch-admin-certs (OpenSearch admin client TLS)
                      +-> keycloak-tls               (Keycloak ingress TLS)
                      +-> azul-web-tls               (Azul web ingress TLS, in azul ns)

WHERE EACH CERT IS CREATED:

  1. Helm chart templates (charts/azul-infra/templates/opensearch.yaml)
     Triggered by: ./05_install_opensearch.sh
     Creates:
       - Issuer: azul-opensearch-selfsigned-issuer
       - Certificate: azul-opensearch-ca-certificate  (secret: azul-opensearch-ca-cert)
       - Issuer: azul-opensearch-ca-issuer
       - Certificate: azul-opensearch-certs       (for OpenSearch nodes)
       - Certificate: azul-opensearch-admin-certs (for OpenSearch admin)

  2. 05_install_opensearch.sh  (after OpenSearch is green)
     Creates:
       - Certificate: keycloak-tls-cert  (secret: keycloak-tls)
       CA trust patch:
       - Appends the current CA to the azul-opensearch-certs CONFIGMAP
         so OpenSearch can trust the Keycloak ingress TLS when it fetches
         JWKS to validate JWTs.

  3. 01_install_core.sh  (in offline-core package)
     Creates (in azul namespace):
       - Secret (copy): azul-opensearch-ca-cert
       - ConfigMap: azul-ca-cert  (PEM file for pods to trust)
       - Issuer: azul-ca-issuer
       - Certificate: azul-web-tls

WHY THIS MATTERS:
- OpenSearch uses TLS internally (self-signed by its CA)
- Keycloak runs plain HTTP internally; TLS terminates at ingress (keycloak-tls)
- Azul pods calling Keycloak for JWKS hit the ingress, so they need:
    1. CoreDNS to resolve keycloak.azul.kp.local  (step 07)
    2. The CA in their trust store to accept the ingress TLS cert
  This is why the CA is patched into the OpenSearch ca-certificates configmap
  (step 05) and copied to the azul namespace as azul-ca-cert (core install).

CERT RENEWAL:
  cert-manager auto-renews all Certificate objects before expiry (default 30
  days before). No manual action needed.


CREDENTIALS
-----------
All credentials are in config.sh. The OpenSearch passwords MUST match the
bcrypt hashes in values.yaml (opensearch.internalUsers section).

To regenerate hashes after changing OS_ADMIN_PASS:
  python3 -c "import bcrypt; print(bcrypt.hashpw(b'YOUR_PASSWORD', bcrypt.gensalt(12)).decode())"

Then update the matching hash in values.yaml under opensearch.internalUsers.


UNINSTALL
---------
  ./uninstall_all.sh

  - Removes all helm releases in reverse order
  - Lists leftover PVCs (data is preserved)
  - KEEPS cert-manager if other consumers exist (e.g. Rancher)
  - KEEPS Strimzi and cert-manager CRDs (helm resource-policy: keep)

For a full wipe:
  kubectl -n azul-infra delete pvc --all
  kubectl delete namespace azul-infra kafka opensearch-operator


CONTENTS
--------
  config.sh                                              # All environment config
  values.yaml                                            # Helm values (storage, ingress, etc.)
  images.txt                                             # Container images to pull
  charts/cert-manager-v1.17.2.tgz                        # cert-manager chart
  charts/strimzi-kafka-operator-helm-3-chart-0.50.0.tgz  # Strimzi chart
  charts/opensearch-operator-2.8.0.tgz                   # OpenSearch operator chart
  charts/azul-infra/                                     # AZUL infra chart (Kafka, OpenSearch, MinIO, Keycloak)
