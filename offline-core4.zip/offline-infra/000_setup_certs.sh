#!/usr/bin/env bash
# 000 - Verify cert-manager (installed by Rancher) and probe readiness
#
# In this offline environment, cert-manager is installed and managed by Rancher.
# These scripts do NOT install it. This script just verifies it is present,
# healthy, and that its webhook is reachable — otherwise every Certificate /
# Issuer resource created by later steps (05, 07, setup-certs.sh) will fail.
#
# What it checks:
#   1. CRDs: certificates.cert-manager.io, issuers.cert-manager.io
#   2. Deployments: cert-manager / cert-manager-webhook / cert-manager-cainjector
#   3. Webhook reachability: creates a throwaway test Certificate in a new test
#      namespace and waits for cert-manager to react.
#
# If this script fails, install/repair cert-manager in Rancher before running
# the rest of the scripts.
set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

FAIL=0
pass() { echo "  ✓ $*"; }
fail() { echo "  ✗ $*"; FAIL=1; }
hr()   { echo "----------------------------------------"; }

echo "=== cert-manager pre-flight check ==="
hr

# --- 1. CRDs ---
echo "1. CRDs"
for crd in certificates.cert-manager.io issuers.cert-manager.io clusterissuers.cert-manager.io; do
    if kubectl get crd "$crd" >/dev/null 2>&1; then
        pass "$crd"
    else
        fail "$crd — CRD missing (cert-manager not installed)"
    fi
done

if [[ "$FAIL" == "1" ]]; then
    echo ""
    echo "cert-manager is NOT installed."
    echo "In Rancher: Apps -> cert-manager -> Install (choose the default namespace)."
    echo "Or install via helm:"
    echo "  helm repo add jetstack https://charts.jetstack.io && helm repo update"
    echo "  helm install cert-manager jetstack/cert-manager -n cert-manager --create-namespace --set crds.enabled=true"
    exit 1
fi

# --- 2. Deployments ---
echo ""
echo "2. Deployments"
CM_NS=""
for ns in cert-manager kube-system cattle-system; do
    if kubectl -n "$ns" get deploy cert-manager >/dev/null 2>&1; then
        CM_NS="$ns"
        break
    fi
done
if [[ -z "$CM_NS" ]]; then
    # Not in a known namespace — find it
    CM_NS=$(kubectl get deploy -A -l app.kubernetes.io/name=cert-manager -o jsonpath='{.items[0].metadata.namespace}' 2>/dev/null)
fi
if [[ -z "$CM_NS" ]]; then
    fail "cert-manager Deployment not found in any namespace"
    exit 1
fi
pass "cert-manager namespace: $CM_NS"

for d in cert-manager cert-manager-webhook cert-manager-cainjector; do
    READY=$(kubectl -n "$CM_NS" get deploy "$d" -o jsonpath='{.status.readyReplicas}' 2>/dev/null || echo 0)
    WANT=$(kubectl -n "$CM_NS" get deploy "$d" -o jsonpath='{.status.replicas}' 2>/dev/null || echo 0)
    if [[ -n "$READY" && "$READY" == "$WANT" && "$READY" != "0" ]]; then
        pass "$d  ($READY/$WANT ready)"
    else
        fail "$d  ($READY/$WANT ready)"
    fi
done

if [[ "$FAIL" == "1" ]]; then
    echo ""
    echo "cert-manager is installed but not healthy. Check:"
    echo "  kubectl -n $CM_NS get pods"
    echo "  kubectl -n $CM_NS describe deploy cert-manager-webhook"
    exit 1
fi

# --- 3. Webhook reachability: throwaway Certificate ---
echo ""
echo "3. Webhook reachability"
TEST_NS="cert-manager-test-$$"
kubectl create namespace "$TEST_NS" >/dev/null 2>&1
trap 'kubectl delete namespace "$TEST_NS" --wait=false >/dev/null 2>&1 || true' EXIT

kubectl apply -f - >/dev/null 2>&1 <<EOF
apiVersion: cert-manager.io/v1
kind: Issuer
metadata:
  name: probe-issuer
  namespace: ${TEST_NS}
spec:
  selfSigned: {}
---
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: probe-cert
  namespace: ${TEST_NS}
spec:
  secretName: probe-cert-tls
  commonName: probe.local
  duration: 1h
  privateKey:
    size: 2048
  issuerRef:
    name: probe-issuer
    kind: Issuer
EOF

if kubectl -n "$TEST_NS" wait certificate/probe-cert --for=condition=Ready --timeout=30s >/dev/null 2>&1; then
    pass "cert-manager issued a test certificate — webhook is reachable"
else
    fail "cert-manager did not issue the test certificate within 30s"
    echo ""
    kubectl -n "$TEST_NS" describe certificate probe-cert 2>&1 | awk '/Events:/,/^$/' | head -15 | sed 's/^/  /'
    echo ""
    echo "Common causes:"
    echo "  - cert-manager-webhook Pod can't reach the API server"
    echo "  - Network policy blocking 10.42.0.0/16 or 10.43.0.0/16 (pod/svc nets on k3s)"
    echo "  - Webhook TLS cert has expired / needs to be re-bootstrapped"
    exit 1
fi

hr
echo "RESULT: cert-manager is healthy and ready for AZUL."
echo ""
echo "Next: run ./00_install_ingress.sh"
