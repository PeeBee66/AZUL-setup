#!/usr/bin/env bash
# Shared config for AZUL core app install.
# Edit these values for your target environment.

# --- Container Registry ---
# Set to your offline registry (e.g. "myregistry.local:5000")
# Leave empty to pull from upstream (internet required).
REGISTRY=""

# --- Kubernetes ---
NAMESPACE="azul"
INFRA_NAMESPACE="azul-infra"

# --- Hostnames ---
AZUL_HOST="azul.kp.local"
KEYCLOAK_HOST="keycloak.azul.kp.local"

# --- Keycloak identity (must match offline-infra/config.sh) ---
KC_REALM="azul"
KC_WEB_CLIENT_ID="azul-web"

# --- Container Images ---
# Azul custom images — customRegistry is prepended to each image name
# To use an offline registry: set AZUL_IMAGE_REGISTRY="myregistry.local:5000/asdazul/"
AZUL_IMAGE_REGISTRY="docker.io/asdazul/"
AZUL_IMAGE_TAG="9.0.0"

# External images (full path:tag)
IMG_REDIS="docker.io/redis:8.4.0-bookworm"

# --- Credentials ---
# OpenSearch writer password (must match bcrypt hash in infra values.yaml azul_writer user)
OS_WRITER_PASS="cuvJ7K09EgApwfV2o9rQ7avR554uRP7e"
# bcrypt: $2b$12$5887eR1nNYkgcn/GHHs/8OHQpDCMhlCamvEyyHf7QGlbaAYAf5DXi

# MinIO keys (must match the s3-keys secret in azul-infra namespace)
S3_ACCESS_KEY="b26340be283b45acc0ba6afbf2789800"
S3_SECRET_KEY="38fbf2b72e819df4e9d7dbfaecf9983f20dae7a6ebec0611410af9331caf361e"

# External S3 backup endpoint (backup/recovery feature — external MinIO on host)
# Only used if recovery is enabled. Leave default if not using backup/restore.
EXTERNAL_S3_ENDPOINT="192.168.66.41:9100"
EXTERNAL_S3_SECURE="false"

# Backup MinIO credentials
BACKUP_S3_USER="azul-backup"
BACKUP_S3_PASSWORD="azul-backup-secret"

# --- Certificate Settings ---
# These control the azul-web-tls ingress certificate (created by setup-certs.sh).
# Must match what was used for infra — keep these aligned with offline-infra/config.sh.

CERT_KEY_SIZE="2048"                  # 2048 or 4096
CERT_KEY_ALGORITHM="RSA"              # RSA or ECDSA
CERT_WEB_DURATION="8760h"             # 1 year
CERT_WEB_RENEW_BEFORE="720h"          # 30 days before expiry
# Internal cert settings (used by setup-certs.sh when re-issuing keycloak-tls)
CERT_INTERNAL_DURATION="87600h"       # 10 years
CERT_INTERNAL_RENEW_BEFORE="8760h"    # 1 year
