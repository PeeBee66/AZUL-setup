#!/usr/bin/env bash
# 01 - Install Strimzi Kafka Operator (required by Kafka)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/strimzi-kafka-operator-helm-3-chart-0.50.0.tgz"

REGISTRY_ARGS=()
if [[ -n "$REGISTRY" ]]; then
  REGISTRY_ARGS=(
    --set defaultImageRegistry="${REGISTRY}"
    --set defaultImageRepository=strimzi
  )
fi

echo "=== Installing Strimzi Kafka Operator ==="
helm install strimzi-kafka-operator "$CHART" \
  -n kafka --create-namespace \
  --set watchAnyNamespace=true \
  "${REGISTRY_ARGS[@]}"

echo "Waiting for Strimzi operator to be ready..."
kubectl -n kafka rollout status deployment/strimzi-cluster-operator --timeout=180s

echo "=== Strimzi Kafka Operator installed ==="
