#!/usr/bin/env bash
# Uninstall all AZUL infra components (reverse order)
set -uo pipefail

echo "=== Uninstalling AZUL Infrastructure ==="
echo "This will remove all AZUL infra components. PVCs are kept by default."
read -p "Continue? (y/N) " -r
[[ "$REPLY" =~ ^[Yy]$ ]] || exit 0

echo "Removing infra components..."
helm uninstall azul-minio      -n azul-infra 2>/dev/null && echo "  MinIO removed"      || echo "  MinIO not found"
helm uninstall azul-opensearch  -n azul-infra 2>/dev/null && echo "  OpenSearch removed"  || echo "  OpenSearch not found"
helm uninstall azul-kafka       -n azul-infra 2>/dev/null && echo "  Kafka removed"       || echo "  Kafka not found"
helm uninstall azul-keycloak    -n azul-infra 2>/dev/null && echo "  Keycloak removed"    || echo "  Keycloak not found"

echo "Removing operators..."
helm uninstall opensearch-operator    -n opensearch-operator 2>/dev/null && echo "  OpenSearch operator removed" || echo "  OpenSearch operator not found"
helm uninstall strimzi-kafka-operator -n kafka               2>/dev/null && echo "  Strimzi removed"             || echo "  Strimzi not found"
helm uninstall cert-manager           -n cert-manager        2>/dev/null && echo "  cert-manager removed"        || echo "  cert-manager not found"

echo ""
echo "PVCs are still present. To delete data:"
echo "  kubectl -n azul-infra get pvc"
echo "  kubectl -n azul-infra delete pvc <name>"
echo ""
echo "Note: CoreDNS hosts entries (step 07) are NOT removed."
echo "=== Uninstall complete ==="
