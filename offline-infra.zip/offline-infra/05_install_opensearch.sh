#!/usr/bin/env bash
# 05 - Install OpenSearch (requires cert-manager from step 00, OpenSearch operator from step 02)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/azul-infra"
VALUES="${SCRIPT_DIR}/values.yaml"

# OpenSearch images are pulled by the operator using the defaultRepo value
REGISTRY_ARGS=()
if [[ -n "$REGISTRY" ]]; then
  REGISTRY_ARGS=(
    --set defaultRepo="${REGISTRY}"
  )
fi

echo "=== Installing OpenSearch ==="

kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

# Create credential secrets (passwords must match bcrypt hashes in values.yaml)
if ! kubectl -n "$NAMESPACE" get secret azul-cluster-admincredentials >/dev/null 2>&1; then
  echo "Creating OpenSearch admin credentials secret..."
  kubectl -n "$NAMESPACE" create secret generic azul-cluster-admincredentials \
    --from-literal=username=admin \
    --from-literal=password="$OS_ADMIN_PASS"
fi

if ! kubectl -n "$NAMESPACE" get secret azul-cluster-dashboardcredentials >/dev/null 2>&1; then
  echo "Creating OpenSearch dashboard credentials secret..."
  kubectl -n "$NAMESPACE" create secret generic azul-cluster-dashboardcredentials \
    --from-literal=username=kibanaserver \
    --from-literal=password="$OS_DASH_PASS"
fi

helm install azul-opensearch "$CHART" \
  -n "$NAMESPACE" \
  -f "$VALUES" \
  --set keycloak.enable=false \
  --set kafka.enable=false \
  --set minio.main.enable=false \
  --set minio.backup.enable=false \
  "${REGISTRY_ARGS[@]}"

echo "Waiting for OpenSearch cluster to be ready (this takes several minutes)..."

# Wait for the OpenSearch cluster to report green
echo "Polling opensearchclusters status..."
for i in $(seq 1 60); do
  HEALTH=$(kubectl -n "$NAMESPACE" get opensearchclusters azul-opensearch -o jsonpath='{.status.health}' 2>/dev/null || echo "unknown")
  if [[ "$HEALTH" == "green" ]]; then
    echo "OpenSearch cluster is green."
    break
  fi
  echo "  [$i/60] health=$HEALTH, waiting 10s..."
  sleep 10
done

# Create Keycloak TLS cert signed by the OpenSearch CA issuer.
# Dashboards needs to trust Keycloak's TLS for OIDC — this cert is signed by
# the same CA that Dashboards trusts via NODE_EXTRA_CA_CERTS.
if ! kubectl -n "$NAMESPACE" get secret keycloak-tls >/dev/null 2>&1; then
  echo "Creating Keycloak TLS certificate (signed by OpenSearch CA)..."
  kubectl apply -f - <<EOF
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: keycloak-tls-cert
  namespace: ${NAMESPACE}
spec:
  secretName: keycloak-tls
  duration: 87600h0m0s
  renewBefore: 8760h0m0s
  commonName: ${KEYCLOAK_HOST}
  dnsNames:
    - ${KEYCLOAK_HOST}
  privateKey:
    size: 2048
    algorithm: RSA
  usages:
    - digital signature
    - key encipherment
    - server auth
  issuerRef:
    name: azul-opensearch-ca-issuer
    kind: Issuer
EOF
  echo "Waiting for keycloak-tls cert to be ready..."
  kubectl -n "$NAMESPACE" wait certificate/keycloak-tls-cert --for=condition=Ready --timeout=60s
fi

echo "=== OpenSearch installed ==="
