#!/usr/bin/env bash
# 02 - Install OpenSearch Operator (required by OpenSearch)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/opensearch-operator-2.8.0.tgz"

REGISTRY_ARGS=()
if [[ -n "$REGISTRY" ]]; then
  REGISTRY_ARGS=(
    --set manager.image.repository="${REGISTRY}/opensearchproject/opensearch-operator"
    --set kubeRbacProxy.image.repository="${REGISTRY}/kubebuilder/kube-rbac-proxy"
  )
fi

echo "=== Installing OpenSearch Operator ==="
helm install opensearch-operator "$CHART" \
  -n opensearch-operator --create-namespace \
  "${REGISTRY_ARGS[@]}"

echo "Waiting for OpenSearch operator to be ready..."
kubectl -n opensearch-operator rollout status deployment/opensearch-operator-controller-manager --timeout=180s

echo "=== OpenSearch Operator installed ==="
