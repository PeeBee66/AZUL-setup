AZUL Infrastructure - Offline Install Package
==============================================

Target: k3s cluster (air-gapped)

BEFORE YOU START
----------------
1. Load all container images from images.txt into your offline registry
2. Edit config.sh:
   - Set REGISTRY to your offline registry (e.g. "myregistry.local:5000")
   - Set CLUSTER_IP to your k3s ingress IP
   - Set hostnames to match your domain
   - Set credentials (if you change OS passwords, regenerate bcrypt hashes in values.yaml)
3. Edit values.yaml for your environment:
   - Hostnames (*.kp.local -> your domain)
   - Storage class (local-path -> your storage class)
   - Ingress class (nginx -> your ingress class)
4. If your registry needs auth, add imagePullSecrets to values.yaml

INSTALL ORDER
-------------
Run each script in order. Wait for each to complete before the next.

  ./00_install_cert_manager.sh        # TLS certificate management
  ./01_install_strimzi.sh             # Kafka operator (CRDs)
  ./02_install_opensearch_operator.sh # OpenSearch operator (CRDs)
  ./03_install_keycloak.sh            # Keycloak + PostgreSQL (auth)
  ./04_install_kafka.sh               # Kafka broker (event store)
  ./05_install_opensearch.sh          # OpenSearch + Dashboards (search) + Keycloak TLS cert
  ./06_install_minio.sh               # MinIO (S3 object storage)
  ./07_setup_coredns.sh               # Add *.kp.local entries to CoreDNS
  ./08_setup_keycloak.sh              # Create Azul realm, roles, clients, users

CREDENTIALS
-----------
All credentials are in config.sh. The OpenSearch passwords MUST match the
bcrypt hashes in values.yaml (opensearch.internalUsers section). To regenerate:

  python3 -c "import bcrypt; print(bcrypt.hashpw(b'YOUR_PASSWORD', bcrypt.gensalt(12)).decode())"

UNINSTALL
---------
  ./uninstall_all.sh

CONTENTS
--------
  config.sh                                           # Credentials, registry, hostnames
  values.yaml                                         # Helm values (storage, ingress, etc.)
  charts/cert-manager-v1.17.2.tgz                    # cert-manager
  charts/strimzi-kafka-operator-helm-3-chart-0.50.0.tgz  # Strimzi
  charts/opensearch-operator-2.8.0.tgz                # OpenSearch operator
  charts/azul-infra/                                  # AZUL infra chart
  images.txt                                          # Container images to pull
