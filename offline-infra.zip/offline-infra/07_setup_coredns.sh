#!/usr/bin/env bash
# 07 - Add host entries to CoreDNS
# Pods inside the cluster can't resolve external DNS entries (e.g. Pi-hole).
# This adds static hosts so pods can reach Azul services via their ingress hostnames.
#
# Edit hostnames and CLUSTER_IP in config.sh before running.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

echo "=== Configuring CoreDNS with Azul host entries ==="

# Check if hosts block already exists
EXISTING=$(kubectl -n kube-system get configmap coredns -o jsonpath='{.data.Corefile}' 2>/dev/null)
if echo "$EXISTING" | grep -q "$KEYCLOAK_HOST"; then
  echo "CoreDNS already has Azul host entries. Skipping."
  exit 0
fi

# Build the hosts block from config.sh variables
HOSTS_BLOCK="    hosts {
        ${CLUSTER_IP} ${KEYCLOAK_HOST}
        ${CLUSTER_IP} ${OPENSEARCH_HOST}
        ${CLUSTER_IP} ${MINIO_HOST}
        ${CLUSTER_IP} ${MINIO_API_HOST}
        ${CLUSTER_IP} ${AZUL_HOST}
        fallthrough
    }
"

# Patch CoreDNS Corefile to insert hosts block after the prometheus line
kubectl -n kube-system get configmap coredns -o json | \
  HOSTS_BLOCK="$HOSTS_BLOCK" python3 -c "
import json, sys, os, re
cm = json.load(sys.stdin)
corefile = cm['data']['Corefile']
hosts = os.environ['HOSTS_BLOCK']
corefile = re.sub(r'(    prometheus :\d+\n)', r'\1' + hosts, corefile)
cm['data']['Corefile'] = corefile
cm['metadata'].pop('resourceVersion', None)
json.dump(cm, sys.stdout)
" | kubectl apply -f -

echo "Restarting CoreDNS..."
kubectl -n kube-system rollout restart deployment/coredns
kubectl -n kube-system rollout status deployment/coredns --timeout=60s

echo "=== CoreDNS configured ==="
