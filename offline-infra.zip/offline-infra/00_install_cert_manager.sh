#!/usr/bin/env bash
# 00 - Install cert-manager (required by OpenSearch for TLS certificates)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/cert-manager-v1.17.2.tgz"

REGISTRY_ARGS=()
if [[ -n "$REGISTRY" ]]; then
  REGISTRY_ARGS=(
    --set image.repository="${REGISTRY}/jetstack/cert-manager-controller"
    --set webhook.image.repository="${REGISTRY}/jetstack/cert-manager-webhook"
    --set cainjector.image.repository="${REGISTRY}/jetstack/cert-manager-cainjector"
    --set startupapicheck.image.repository="${REGISTRY}/jetstack/cert-manager-startupapicheck"
  )
fi

echo "=== Installing cert-manager ==="
helm install cert-manager "$CHART" \
  -n cert-manager --create-namespace \
  --set crds.enabled=true \
  "${REGISTRY_ARGS[@]}"

echo "Waiting for cert-manager to be ready..."
kubectl -n cert-manager rollout status deployment/cert-manager --timeout=120s
kubectl -n cert-manager rollout status deployment/cert-manager-webhook --timeout=120s

echo "=== cert-manager installed ==="
