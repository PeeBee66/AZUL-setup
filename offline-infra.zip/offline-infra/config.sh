#!/usr/bin/env bash
# Shared config for all install scripts.
# Edit these values for your target environment.

# --- Container Registry ---
# Set to your offline registry (e.g. "myregistry.local:5000")
# Leave empty to pull from upstream (internet required).
REGISTRY=""

# --- Kubernetes ---
NAMESPACE="azul-infra"
CLUSTER_IP="192.168.66.201"

# --- Hostnames (must match values.yaml ingress settings) ---
AZUL_HOST="azul.kp.local"
KEYCLOAK_HOST="keycloak-azul.kp.local"
OPENSEARCH_HOST="opensearch-azul.kp.local"
MINIO_HOST="minio-azul.kp.local"
MINIO_API_HOST="minio-api-azul.kp.local"

# --- Credentials ---
# These MUST match the bcrypt hashes in values.yaml opensearch.internalUsers.
# If you change these, regenerate the hashes:
#   python3 -c "import bcrypt; print(bcrypt.hashpw(b'YOUR_PASSWORD', bcrypt.gensalt(12)).decode())"

# OpenSearch (values.yaml users: admin, monitor, azul_writer)
OS_ADMIN_PASS="cuvJ7K09EgApwfV2o9rQ7avR554uRP7e"
# bcrypt: $2b$12$E0UZmxoizsBfIe83GLANoefDcUrqiSNuqLMJ72NCnfF2urN19.k7K

# OpenSearch Dashboards (values.yaml user: kibanaserver)
OS_DASH_PASS="4xIQW0pLfSWFbvnHCJWpWJUqKCIYio4A"
# bcrypt: $2b$12$KNrt1DvaU/PwSH8Mc9fmJeGgasFSVYU2cZK6O5ZZw1gfjORb2EQlS

# Keycloak
KC_ADMIN_PASSWORD="aDwQL6kkEl3MIcyTXBNMpCmC+oAPHWl0"
KC_DB_PASSWORD="MAgLmTJwrtesmwVuOp5vcVg8EIHBhmQ1"

# MinIO
S3_ACCESS_KEY="b26340be283b45acc0ba6afbf2789800"
S3_SECRET_KEY="38fbf2b72e819df4e9d7dbfaecf9983f20dae7a6ebec0611410af9331caf361e"

# --- Keycloak Realm Setup ---
KC_LOCAL_PORT="18080"
TEST_USER="basic"
TEST_PASSWORD="basic12345"
ADMIN_USER="azuladmin"
ADMIN_PASSWORD="admin12345"
DOMAIN="kp.local"
