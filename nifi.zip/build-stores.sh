#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "$0")" && pwd)"
CA_DIR="$PROJECT_ROOT/CA"
SERVER_DIR="$PROJECT_ROOT/SERVER"
PASSWORD="Password22"

echo "========================================="
echo " NiFi TLS Store Builder & Validator"
echo "========================================="

# ── Step 1: Convert .cer → .crt ──────────────────────────────
echo ""
echo "[1/5] Converting SERVER.cer → SERVER.crt"

if [ ! -f "$SERVER_DIR/SERVER.cer" ]; then
    echo "ERROR: $SERVER_DIR/SERVER.cer not found" >&2
    exit 1
fi

openssl x509 -in "$SERVER_DIR/SERVER.cer" -out "$SERVER_DIR/SERVER.crt" -outform PEM
echo "  ✔ SERVER.crt written (PEM format)"

# ── Step 2: Build keystore.p12 ───────────────────────────────
echo ""
echo "[2/5] Building keystore.p12 (server key + cert + CA chain)"

openssl pkcs12 -export -legacy \
    -in "$SERVER_DIR/SERVER.cer" \
    -inkey "$SERVER_DIR/SERVER.key" \
    -certfile "$CA_DIR/ca.crt" \
    -out "$SERVER_DIR/keystore.p12" \
    -name "nifi-server" \
    -password "pass:$PASSWORD"

echo "  ✔ keystore.p12 created"

# ── Step 3: Build truststore.p12 ─────────────────────────────
echo ""
echo "[3/5] Building truststore.p12 (CA cert + server cert)"

# Remove old truststore if present
rm -f "$SERVER_DIR/truststore.p12"

# Import CA certificate
keytool -importcert -noprompt \
    -alias "nifi-ca" \
    -file "$CA_DIR/ca.crt" \
    -keystore "$SERVER_DIR/truststore.p12" \
    -storetype PKCS12 \
    -storepass "$PASSWORD"

# Import server certificate
keytool -importcert -noprompt \
    -alias "nifi-server" \
    -file "$SERVER_DIR/SERVER.crt" \
    -keystore "$SERVER_DIR/truststore.p12" \
    -storetype PKCS12 \
    -storepass "$PASSWORD"

echo "  ✔ truststore.p12 created"

# ── Step 4: Validate keystore.p12 ────────────────────────────
echo ""
echo "[4/5] Validating keystore.p12"
echo "  --- keytool -list ---"
keytool -list -v \
    -keystore "$SERVER_DIR/keystore.p12" \
    -storetype PKCS12 \
    -storepass "$PASSWORD" 2>&1 | grep -E "Keystore type|Keystore provider|Entry type|Alias name|Owner|Issuer|Valid from|Subject Alternative"

echo ""

# Verify the private key matches the cert
CERT_MOD=$(openssl x509 -noout -modulus -in "$SERVER_DIR/SERVER.cer" | openssl md5)
KEY_MOD=$(openssl rsa -noout -modulus -in "$SERVER_DIR/SERVER.key" | openssl md5)
if [ "$CERT_MOD" = "$KEY_MOD" ]; then
    echo "  ✔ Private key matches certificate"
else
    echo "  ✗ MISMATCH: private key does not match certificate" >&2
    exit 1
fi

# ── Step 5: Validate truststore.p12 ──────────────────────────
echo ""
echo "[5/5] Validating truststore.p12"
echo "  --- keytool -list ---"
keytool -list \
    -keystore "$SERVER_DIR/truststore.p12" \
    -storetype PKCS12 \
    -storepass "$PASSWORD" 2>&1

echo ""

# Count entries
ENTRY_COUNT=$(keytool -list \
    -keystore "$SERVER_DIR/truststore.p12" \
    -storetype PKCS12 \
    -storepass "$PASSWORD" 2>&1 | grep -c "trustedCertEntry")

if [ "$ENTRY_COUNT" -eq 2 ]; then
    echo "  ✔ Truststore has $ENTRY_COUNT trusted entries (CA + server)"
else
    echo "  ✗ Expected 2 trusted entries, found $ENTRY_COUNT" >&2
    exit 1
fi

# ── Summary ──────────────────────────────────────────────────
echo ""
echo "========================================="
echo " ALL CHECKS PASSED"
echo "========================================="
echo " keystore.p12   → $SERVER_DIR/keystore.p12"
echo " truststore.p12 → $SERVER_DIR/truststore.p12"
echo " Password       → $PASSWORD"
echo " Java version   → $(java -version 2>&1 | head -1)"
echo " keytool        → $(keytool 2>&1 | head -1)"
echo "========================================="
