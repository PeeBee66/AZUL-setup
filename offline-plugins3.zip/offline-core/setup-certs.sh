#!/usr/bin/env bash
# =============================================================================
# AZUL Certificate Setup
# =============================================================================
# Consolidates ALL TLS certificate setup in one place.
#
# Certificate chain of trust:
#
#   azul-opensearch-selfsigned-issuer  (root, self-signed)
#       |
#       +-> azul-opensearch-ca-certificate  ->  azul-opensearch-ca-cert (SECRET)
#                                               (this is THE CA)
#               |
#               +-> azul-opensearch-ca-issuer  (CA Issuer in azul-infra ns)
#                       |
#                       +-> azul-opensearch-certs       (OpenSearch node TLS)
#                       +-> azul-opensearch-admin-certs (OpenSearch admin TLS)
#                       +-> keycloak-tls                (Keycloak ingress TLS)
#                       +-> azul-web-tls                (Azul web ingress TLS, in azul ns)
#
# The root, CA, and OpenSearch certs are created by the azul-infra helm chart
# template (opensearch.yaml) — they exist automatically after 05_install_opensearch.
#
# This script creates the additional certs needed for end-to-end trust:
#   - keycloak-tls   (ingress TLS for Keycloak)
#   - ca-trust patch (appends current CA to OpenSearch's trust bundle so it
#                     accepts the Keycloak ingress TLS when fetching JWKS)
#   - azul-ca-cert   (PEM file for azul-ns pods to trust OpenSearch)
#   - azul-web-tls   (ingress TLS for Azul web UI)
#
# USAGE:
#   ./setup-certs.sh infra    # certs in azul-infra ns (keycloak-tls + CA patch)
#   ./setup-certs.sh azul     # certs in azul ns       (CA configmap + web TLS)
#   ./setup-certs.sh all      # both (infra + azul)
#
# CALLED BY:
#   05_install_opensearch.sh  --> setup-certs.sh infra
#   offline-core/01_install_core.sh --> setup-certs.sh azul
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

# Infra namespace: always "azul-infra" (the CA and Keycloak live here)
# Override with INFRA_NAMESPACE env var if your environment uses a different name.
INFRA_NS="${INFRA_NAMESPACE:-azul-infra}"
# Azul namespace: default "azul" (set AZUL_NAMESPACE to override)
AZUL_NS="${AZUL_NAMESPACE:-azul}"
CA_SECRET="azul-opensearch-ca-cert"
OS_CERTS_CM="azul-opensearch-certs"
CA_ISSUER="azul-opensearch-ca-issuer"

# Cert settings with defaults (overridden by config.sh)
: "${CERT_KEY_SIZE:=2048}"
: "${CERT_KEY_ALGORITHM:=RSA}"
: "${CERT_INTERNAL_DURATION:=87600h}"
: "${CERT_INTERNAL_RENEW_BEFORE:=8760h}"
: "${CERT_WEB_DURATION:=8760h}"
: "${CERT_WEB_RENEW_BEFORE:=720h}"
: "${TEMP_DIR:=/tmp}"

# --- Helpers -----------------------------------------------------------------

log() { echo "[certs] $*"; }

wait_for_ca() {
    log "Waiting for ${CA_SECRET} to exist in ${INFRA_NS}..."
    for i in $(seq 1 60); do
        if kubectl -n "$INFRA_NS" get secret "$CA_SECRET" >/dev/null 2>&1; then
            log "CA secret found."
            return 0
        fi
        sleep 5
    done
    log "FATAL: ${CA_SECRET} did not appear after 5 min. Is OpenSearch installed?"
    return 1
}

# --- Cert creation functions -------------------------------------------------

# Create the Keycloak ingress TLS cert (signed by the OpenSearch CA).
# Required so Azul pods + OpenSearch can trust Keycloak's TLS endpoint
# when fetching JWKS for JWT validation.
create_keycloak_tls() {
    if kubectl -n "$INFRA_NS" get secret keycloak-tls >/dev/null 2>&1; then
        log "keycloak-tls already exists — skipping"
        return 0
    fi
    log "Creating keycloak-tls cert for ${KEYCLOAK_HOST}..."
    kubectl apply -f - <<EOF
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: keycloak-tls-cert
  namespace: ${INFRA_NS}
spec:
  secretName: keycloak-tls
  duration: ${CERT_INTERNAL_DURATION}
  renewBefore: ${CERT_INTERNAL_RENEW_BEFORE}
  commonName: ${KEYCLOAK_HOST}
  dnsNames:
    - ${KEYCLOAK_HOST}
  privateKey:
    size: ${CERT_KEY_SIZE}
    algorithm: ${CERT_KEY_ALGORITHM}
  usages:
    - digital signature
    - key encipherment
    - server auth
  issuerRef:
    name: ${CA_ISSUER}
    kind: Issuer
EOF
    kubectl -n "$INFRA_NS" wait certificate/keycloak-tls-cert --for=condition=Ready --timeout=60s
}

# Patch the OpenSearch ca-certificates configmap to include the current CA.
# OpenSearch fetches Keycloak's JWKS over HTTPS — it must trust the ingress
# TLS cert (keycloak-tls), which is signed by the current CA. The chart bakes
# an OLDER "Test CA" into the configmap; each install generates a NEW CA,
# so we append it and restart the node.
patch_opensearch_ca_trust() {
    local current_ca existing
    current_ca=$(kubectl -n "$INFRA_NS" get secret "$CA_SECRET" -o jsonpath='{.data.ca\.crt}' | base64 -d)
    existing=$(kubectl -n "$INFRA_NS" get cm "$OS_CERTS_CM" -o jsonpath='{.data.ca-certificates}' 2>/dev/null || echo "")

    if [[ "$existing" == *"$current_ca"* ]]; then
        log "Current CA already trusted by OpenSearch — skipping"
        return 0
    fi

    log "Appending current CA to ${OS_CERTS_CM} configmap..."
    kubectl -n "$INFRA_NS" get cm "$OS_CERTS_CM" -o json | \
        CURRENT_CA="$current_ca" python3 -c "
import json, sys, os
cm = json.load(sys.stdin)
cm['data']['ca-certificates'] = cm['data']['ca-certificates'].rstrip() + \
    '\n\n# Current azul-opensearch-ca-cert (for Keycloak JWKS TLS trust)\n' + \
    os.environ['CURRENT_CA'] + '\n'
cm['metadata'].pop('resourceVersion', None)
print(json.dumps(cm))
" | kubectl apply -f -

    log "Restarting OpenSearch node to pick up updated CA trust store..."
    kubectl -n "$INFRA_NS" delete pod azul-opensearch-nodes-0 --wait=false 2>/dev/null || true
    sleep 10
    for i in $(seq 1 30); do
        if kubectl -n "$INFRA_NS" get pod azul-opensearch-nodes-0 \
            -o jsonpath='{.status.containerStatuses[?(@.name=="opensearch")].ready}' 2>/dev/null \
            | grep -q true; then
            log "OpenSearch node is ready."
            return 0
        fi
        log "  [$i/30] waiting for OpenSearch..."
        sleep 10
    done
    log "WARNING: OpenSearch did not become ready within 5 min"
    return 1
}

# In the target namespace (azul):
#   - copy the CA secret so namespace-scoped Issuer can reference it
#   - create a CA issuer
#   - create a configmap with ca.crt (mounted into pods that need to trust OS)
#   - create the web ingress TLS cert
create_azul_ns_certs() {
    local target_ns="${1:-$AZUL_NS}"
    local azul_host="${AZUL_HOST:-azul.kp.local}"

    log "Setting up certs in namespace ${target_ns} (web host: ${azul_host})..."

    kubectl create namespace "$target_ns" --dry-run=client -o yaml | kubectl apply -f -

    # 1. Copy CA secret
    if ! kubectl -n "$target_ns" get secret "$CA_SECRET" >/dev/null 2>&1; then
        log "  Copying ${CA_SECRET} to ${target_ns}..."
        kubectl get secret "$CA_SECRET" -n "$INFRA_NS" -o json \
            | python3 -c "
import sys, json
s = json.load(sys.stdin)
s['metadata'] = {'name': '${CA_SECRET}', 'namespace': '${target_ns}'}
print(json.dumps(s))
" | kubectl apply -f -
    fi

    # 2. CA configmap (ca.crt PEM for pods that need to trust OpenSearch)
    if ! kubectl -n "$target_ns" get configmap azul-ca-cert >/dev/null 2>&1; then
        log "  Creating azul-ca-cert configmap..."
        local tmp="${TEMP_DIR}/azul-ca-cert-$$.pem"
        kubectl get secret "$CA_SECRET" -n "$INFRA_NS" \
            -o jsonpath='{.data.ca\.crt}' | base64 -d > "$tmp"
        kubectl -n "$target_ns" create configmap azul-ca-cert --from-file=ca.crt="$tmp"
        rm -f "$tmp"
    fi

    # 3. CA Issuer (namespace-scoped)
    if ! kubectl -n "$target_ns" get issuer azul-ca-issuer >/dev/null 2>&1; then
        log "  Creating azul-ca-issuer..."
        kubectl apply -f - <<EOF
apiVersion: cert-manager.io/v1
kind: Issuer
metadata:
  name: azul-ca-issuer
  namespace: ${target_ns}
spec:
  ca:
    secretName: ${CA_SECRET}
EOF
    fi

    # 4. Web TLS cert
    if ! kubectl -n "$target_ns" get secret azul-web-tls >/dev/null 2>&1; then
        log "  Creating azul-web-tls cert for ${azul_host}..."
        kubectl apply -f - <<EOF
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: azul-web-tls
  namespace: ${target_ns}
spec:
  secretName: azul-web-tls
  commonName: ${azul_host}
  issuerRef:
    name: azul-ca-issuer
    kind: Issuer
  dnsNames:
    - ${azul_host}
  duration: ${CERT_WEB_DURATION}
  renewBefore: ${CERT_WEB_RENEW_BEFORE}
  privateKey:
    size: ${CERT_KEY_SIZE}
    algorithm: ${CERT_KEY_ALGORITHM}
EOF
        kubectl -n "$target_ns" wait certificate/azul-web-tls --for=condition=Ready --timeout=60s
    fi
}

# --- Main --------------------------------------------------------------------

# Skip main if sourced
if [[ "${BASH_SOURCE[0]}" != "${0}" ]]; then
    return 0
fi

MODE="${1:-all}"

case "$MODE" in
    infra)
        wait_for_ca
        create_keycloak_tls
        patch_opensearch_ca_trust
        log "=== Infra cert setup complete ==="
        ;;
    azul)
        wait_for_ca
        create_azul_ns_certs "${2:-$AZUL_NS}"
        log "=== Azul cert setup complete ==="
        ;;
    all)
        wait_for_ca
        create_keycloak_tls
        patch_opensearch_ca_trust
        create_azul_ns_certs "${2:-$AZUL_NS}"
        log "=== All cert setup complete ==="
        ;;
    *)
        echo "Usage: $0 {infra|azul|all} [azul-namespace]"
        echo ""
        echo "  infra  - keycloak-tls + CA trust patch (in ${INFRA_NS})"
        echo "  azul   - CA secret/configmap/issuer/web-tls (in azul namespace)"
        echo "  all    - both of the above"
        exit 1
        ;;
esac
