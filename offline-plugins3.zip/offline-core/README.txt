AZUL Core Application - Offline Install Package
================================================

Target: k3s cluster (air-gapped)
Prerequisite: offline-infra must be installed and running first.


BEFORE YOU START
----------------
1. Load all container images from images.txt into your registry
2. Edit config.sh:
   - AZUL_IMAGE_REGISTRY -> your offline registry path (e.g. "myregistry.local:5000/asdazul/")
   - IMG_REDIS           -> your redis image
   - Hostnames must match what infra was installed with
   - Credentials must match infra (S3_ACCESS_KEY, OS_WRITER_PASS, etc.)
3. Edit values.yaml for your environment:
   - storageClassName (line 17)
   - ingressClassName in web.ingress (line 186)


INSTALL
-------
  ./01_install_core.sh

This:
  1. Creates the 'azul' namespace
  2. Copies the s3-keys secret from azul-infra
  3. Creates redis, metastore-creds, s3-backup-keys secrets (from config.sh)
  4. Copies the OpenSearch CA cert to azul namespace (configmap + secret)
  5. Creates cert-manager Issuer and web TLS cert (azul-web-tls)
  6. Installs the azul helm chart (core only, plugins disabled)

Metastore ingest pods (ms-ingest-binary, ms-ingest-plugin, ms-ingest-status)
crash-loop 3-4 times on startup — this is NORMAL (race with dispatchers).


ARCHITECTURE
------------
All pod-to-pod traffic stays inside the cluster.

  [Browser]
      |  https://azul.kp.local
      v
  nginx-ingress
      |
      +--> webui (UI files)
      +--> docs (API docs)
      +--> restapi-0 -+-> opensearch.azul-infra.svc:9200
                      +-> kafka-bootstrap.azul-infra.svc:9092
                      +-> redis.azul.svc:6379
                      +-> minio.azul-infra.svc:9000
                      +-> keycloak-azul.kp.local (JWT validation)
      +--> dispatcher -> kafka, redis, opensearch
      +--> metastore (ageoff + 3 ingest pods)

PORTS: restapi 8000, webui/docs 8080, dispatcher 8111, redis 6379


CERTIFICATES (this package's contribution)
------------------------------------------
Creates in the azul namespace:

  1. Secret: azul-opensearch-ca-cert  (copied from azul-infra)
  2. ConfigMap: azul-ca-cert          (ca.crt file — for pods to trust OpenSearch)
  3. Issuer: azul-ca-issuer           (cert-manager Issuer using the CA)
  4. Certificate: azul-web-tls        (ingress TLS for azul.kp.local)

The CA itself (azul-opensearch-ca-cert) is created by the infra install (step 05).
This package just consumes it. All certs auto-renew via cert-manager.

See offline-infra/README.txt CERTIFICATE INFRASTRUCTURE section for the full chain.


UNINSTALL
---------
  ./uninstall.sh

  - Removes the azul helm release
  - Lists leftover PVCs (data preserved) and secrets

For a full wipe:
  kubectl -n azul delete pvc --all
  kubectl delete namespace azul


CONTENTS
--------
  config.sh       # Registry, hostnames, credentials
  values.yaml     # Helm values (edit hostnames, storage, ingress)
  images.txt      # Core container images (7 asdazul + redis)
  charts/azul/    # AZUL application Helm chart (v9.0.0)
