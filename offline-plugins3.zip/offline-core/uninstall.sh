#!/usr/bin/env bash
# Uninstall AZUL Core Application
#
# USAGE:
#   ./uninstall.sh            # remove helm release (keep PVCs)
#   ./uninstall.sh --purge    # remove helm release + PVCs + secrets + namespace
set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

PURGE=false
[[ "${1:-}" == "--purge" ]] && PURGE=true

echo "=== Uninstalling AZUL Core ==="
if [[ "$PURGE" == "true" ]]; then
    echo "*** --purge: will delete PVCs + secrets + namespace ==="
else
    echo "PVCs and secrets preserved (use --purge to wipe)"
fi
read -p "Continue? (y/N) " -r
[[ "$REPLY" =~ ^[Yy]$ ]] || exit 0

# --- Helm release ---
helm uninstall azul -n "$NAMESPACE" 2>/dev/null && echo "  azul helm release removed" || echo "  azul not found"

# --- Manually-created resources ---
echo "Cleaning up manually-created resources in ${NAMESPACE}..."

# Secrets created by 01_install_core.sh
for s in s3-keys redis metastore-creds s3-backup-keys azul-opensearch-ca-cert azul-web-tls; do
    kubectl -n "$NAMESPACE" delete secret "$s" --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
done

# ConfigMap created by setup-certs.sh
kubectl -n "$NAMESPACE" delete configmap azul-ca-cert --ignore-not-found=true 2>/dev/null | sed 's/^/  /'

# cert-manager resources created by setup-certs.sh
kubectl -n "$NAMESPACE" delete certificate azul-web-tls --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
kubectl -n "$NAMESPACE" delete issuer azul-ca-issuer --ignore-not-found=true 2>/dev/null | sed 's/^/  /'

if [[ "$PURGE" == "true" ]]; then
    echo "Purging PVCs..."
    kubectl -n "$NAMESPACE" delete pvc --all --wait=false 2>/dev/null | sed 's/^/  /' | tail -10
    echo "Deleting namespace ${NAMESPACE}..."
    kubectl delete namespace "$NAMESPACE" --wait=false 2>/dev/null | sed 's/^/  /'
fi

echo ""
echo "=== Leftovers ==="
if kubectl get ns "$NAMESPACE" >/dev/null 2>&1; then
    LEFTOVER_PVC=$(kubectl -n "$NAMESPACE" get pvc --no-headers 2>/dev/null)
    LEFTOVER_SECRET=$(kubectl -n "$NAMESPACE" get secrets --no-headers 2>/dev/null | grep -v "default-token\|sh.helm")
    [[ -n "$LEFTOVER_PVC" ]]     && echo "PVCs:" && echo "$LEFTOVER_PVC" | awk '{print "  "$1}'
    [[ -n "$LEFTOVER_SECRET" ]]  && echo "Secrets:" && echo "$LEFTOVER_SECRET" | awk '{print "  "$1}'
    [[ -z "$LEFTOVER_PVC" && -z "$LEFTOVER_SECRET" ]] && echo "  (namespace is empty)"
else
    echo "  (namespace '${NAMESPACE}' removed)"
fi

echo ""
echo "=== Uninstall complete ==="
