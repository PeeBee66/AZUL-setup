#!/usr/bin/env bash
# Keycloak diagnostic — tells you why Keycloak won't start.
#
# Covers the most common offline-environment failure modes:
#   - Image pull failures (Keycloak or Postgres)
#   - Storage issues (Postgres PVC Pending/stuck)
#   - Secret missing or malformed
#   - Postgres not accepting Keycloak's password (persistent-state issue)
#   - Keycloak startup errors (memory, DB connection, hostname validation)
#   - DNS problems inside the pod
#
# Run this in your offline env and paste the output if you need help diagnosing.
set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

hr() { echo "----------------------------------------"; }
pass() { echo "  ✓ $*"; }
fail() { echo "  ✗ $*"; }
info() { echo "  • $*"; }

echo "=== Keycloak Diagnostic ==="
hr

# --- 1. Namespace ---
echo "1. Namespace '$NAMESPACE'"
if ! kubectl get ns "$NAMESPACE" >/dev/null 2>&1; then
    fail "Namespace doesn't exist — run ./03_install_keycloak.sh first"
    exit 1
fi
pass "exists"

# --- 2. Helm release ---
echo ""
echo "2. Helm release 'azul-keycloak'"
if ! helm status azul-keycloak -n "$NAMESPACE" >/dev/null 2>&1; then
    fail "helm release missing — run ./03_install_keycloak.sh"
    exit 1
fi
pass "deployed (revision $(helm status azul-keycloak -n $NAMESPACE -o json | python3 -c 'import sys,json;print(json.load(sys.stdin)["version"])'))"

# --- 3. Secret ---
echo ""
echo "3. Secret 'keycloak'"
if ! kubectl -n "$NAMESPACE" get secret keycloak >/dev/null 2>&1; then
    fail "secret missing — run ./03_install_keycloak.sh"
    exit 1
fi
DB_PASS_LEN=$(kubectl -n "$NAMESPACE" get secret keycloak -o jsonpath='{.data.DB_PASSWORD}' | base64 -d 2>/dev/null | wc -c)
KC_PASS_LEN=$(kubectl -n "$NAMESPACE" get secret keycloak -o jsonpath='{.data.KEYCLOAK_ADMIN_PASSWORD}' | base64 -d 2>/dev/null | wc -c)
if [[ "$DB_PASS_LEN" -gt 0 ]]; then pass "DB_PASSWORD present (${DB_PASS_LEN} chars)"; else fail "DB_PASSWORD missing"; fi
if [[ "$KC_PASS_LEN" -gt 0 ]]; then pass "KEYCLOAK_ADMIN_PASSWORD present (${KC_PASS_LEN} chars)"; else fail "KEYCLOAK_ADMIN_PASSWORD missing"; fi

# Compare with config.sh
CONFIG_DB_PASS_LEN=${#KC_DB_PASSWORD}
CONFIG_KC_PASS_LEN=${#KC_ADMIN_PASSWORD}
SECRET_DB=$(kubectl -n "$NAMESPACE" get secret keycloak -o jsonpath='{.data.DB_PASSWORD}' | base64 -d 2>/dev/null)
SECRET_KC=$(kubectl -n "$NAMESPACE" get secret keycloak -o jsonpath='{.data.KEYCLOAK_ADMIN_PASSWORD}' | base64 -d 2>/dev/null)
if [[ "$SECRET_DB" == "$KC_DB_PASSWORD" ]]; then pass "DB_PASSWORD matches config.sh"; else fail "DB_PASSWORD differs from config.sh!"; fi
if [[ "$SECRET_KC" == "$KC_ADMIN_PASSWORD" ]]; then pass "KEYCLOAK_ADMIN_PASSWORD matches config.sh"; else fail "KEYCLOAK_ADMIN_PASSWORD differs from config.sh!"; fi

# --- 4. Postgres ---
echo ""
echo "4. Postgres"
PG_PVC=$(kubectl -n "$NAMESPACE" get pvc postgres-claim -o json 2>/dev/null | python3 -c "
import sys, json
try:
    p = json.load(sys.stdin)
    print(p['status']['phase'], p['spec'].get('storageClassName','?'), p['spec']['resources']['requests']['storage'])
except: print('MISSING')")
info "PVC postgres-claim: ${PG_PVC}"
if [[ "$PG_PVC" != Bound* ]]; then
    fail "Postgres PVC is not Bound — storage class missing or broken?"
    kubectl -n "$NAMESPACE" describe pvc postgres-claim 2>/dev/null | awk '/Events:/,/^$/' | head -10 | sed 's/^/    /'
else
    pass "PVC Bound"
fi

PG_POD=$(kubectl -n "$NAMESPACE" get pod -l app=postgres -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
if [[ -z "$PG_POD" ]]; then
    fail "No Postgres pod exists"
else
    PG_STATUS=$(kubectl -n "$NAMESPACE" get pod "$PG_POD" -o jsonpath='{.status.phase}')
    PG_READY=$(kubectl -n "$NAMESPACE" get pod "$PG_POD" -o jsonpath='{.status.containerStatuses[0].ready}')
    PG_RESTARTS=$(kubectl -n "$NAMESPACE" get pod "$PG_POD" -o jsonpath='{.status.containerStatuses[0].restartCount}')
    PG_IMAGE=$(kubectl -n "$NAMESPACE" get pod "$PG_POD" -o jsonpath='{.spec.containers[0].image}')
    info "Pod: $PG_POD  Status: $PG_STATUS  Ready: $PG_READY  Restarts: $PG_RESTARTS"
    info "Image: $PG_IMAGE"

    if [[ "$PG_READY" == "true" ]]; then
        pass "Postgres Running and Ready"
        # Test the connection with the secret password
        echo "  Testing DB authentication..."
        AUTH=$(kubectl -n "$NAMESPACE" exec "$PG_POD" -- sh -c "PGPASSWORD='${SECRET_DB}' psql -h localhost -U keycloak -d keycloak -c 'SELECT 1' 2>&1 || true")
        if echo "$AUTH" | grep -q "1 row"; then
            pass "Postgres accepts DB_PASSWORD from secret"
        elif echo "$AUTH" | grep -iq "password authentication failed"; then
            fail "AUTH FAILED — secret has a password, but Postgres DB has a DIFFERENT one"
            info "  This is THE common Keycloak failure in offline/reinstalls."
            info "  The PVC survives uninstalls, so the DB keeps the OLD password."
            info "  FIX: ./uninstall_all.sh keycloak --purge  &&  ./03_install_keycloak.sh"
        else
            info "  Auth test result: $(echo "$AUTH" | head -3)"
        fi
    else
        fail "Postgres not Ready"
        info "Last events:"
        kubectl -n "$NAMESPACE" describe pod "$PG_POD" 2>/dev/null | awk '/Events:/,/^$/' | tail -10 | sed 's/^/    /'
        info "Last log lines:"
        kubectl -n "$NAMESPACE" logs "$PG_POD" --tail=10 2>&1 | sed 's/^/    /'
    fi
fi

# --- 5. Keycloak pods ---
echo ""
echo "5. Keycloak pods"
KC_PODS=$(kubectl -n "$NAMESPACE" get pods -l app=keycloak --no-headers 2>/dev/null)
if [[ -z "$KC_PODS" ]]; then
    fail "No Keycloak pods — check deployment:"
    kubectl -n "$NAMESPACE" get deployment keycloak 2>&1 | sed 's/^/    /'
else
    echo "$KC_PODS" | while read line; do
        name=$(echo "$line" | awk '{print $1}')
        ready=$(echo "$line" | awk '{print $2}')
        status=$(echo "$line" | awk '{print $3}')
        restarts=$(echo "$line" | awk '{print $4}')
        if [[ "$status" == "Running" ]] && [[ "$ready" == "1/1" ]]; then
            pass "$name  $ready  $status  (restarts: $restarts)"
        else
            fail "$name  $ready  $status  (restarts: $restarts)"
        fi
    done

    FIRST_KC=$(echo "$KC_PODS" | awk 'NR==1{print $1}')
    KC_IMAGE=$(kubectl -n "$NAMESPACE" get pod "$FIRST_KC" -o jsonpath='{.spec.containers[0].image}' 2>/dev/null)
    info "Image: $KC_IMAGE"

    # Pod not Ready — show events + last logs
    BAD_KC=$(echo "$KC_PODS" | awk '$2 != "1/1" || $3 != "Running"{print $1; exit}')
    if [[ -n "$BAD_KC" ]]; then
        echo ""
        echo "  Events for $BAD_KC:"
        kubectl -n "$NAMESPACE" describe pod "$BAD_KC" 2>/dev/null | awk '/Events:/,/^$/' | tail -12 | sed 's/^/    /'
        echo ""
        echo "  Last logs from $BAD_KC (main container):"
        kubectl -n "$NAMESPACE" logs "$BAD_KC" --tail=20 2>&1 | tail -20 | sed 's/^/    /'
        echo ""
        echo "  Previous container logs (if it was restarting):"
        kubectl -n "$NAMESPACE" logs "$BAD_KC" --previous --tail=20 2>&1 | grep -iE "error|fail|exception|unable|cannot|refused" | tail -10 | sed 's/^/    /'
    fi
fi

# --- 6. Keycloak service ---
echo ""
echo "6. Keycloak service"
if kubectl -n "$NAMESPACE" get svc keycloak >/dev/null 2>&1; then
    pass "service 'keycloak' exists"
    ENDPOINTS=$(kubectl -n "$NAMESPACE" get endpoints keycloak -o jsonpath='{.subsets[*].addresses[*].ip}' 2>/dev/null)
    if [[ -n "$ENDPOINTS" ]]; then
        pass "endpoints: $ENDPOINTS"
    else
        fail "No endpoints — no Ready Keycloak pods backing the service"
    fi
else
    fail "keycloak service missing"
fi

# --- 7. Ingress ---
echo ""
echo "7. Ingress"
if kubectl -n "$NAMESPACE" get ingress keycloak >/dev/null 2>&1; then
    HOST=$(kubectl -n "$NAMESPACE" get ingress keycloak -o jsonpath='{.spec.rules[0].host}')
    if [[ "$HOST" == "$KEYCLOAK_HOST" ]]; then
        pass "ingress host: $HOST"
    else
        fail "ingress host mismatch: ingress has '$HOST' but config.sh KEYCLOAK_HOST='$KEYCLOAK_HOST'"
    fi
    SEC=$(kubectl -n "$NAMESPACE" get ingress keycloak -o jsonpath='{.spec.tls[0].secretName}')
    if kubectl -n "$NAMESPACE" get secret "$SEC" >/dev/null 2>&1; then
        pass "TLS secret '$SEC' exists"
    else
        fail "TLS secret '$SEC' missing — setup-certs.sh didn't run or cert not issued yet"
    fi
else
    fail "ingress 'keycloak' missing"
fi

hr
echo "Done. Most common offline Keycloak failures:"
echo "  1. Postgres auth failure (persistent PVC from old install) — fix: uninstall with --purge"
echo "  2. Keycloak ImagePullBackOff — fix: set IMG_KEYCLOAK in config.sh to offline registry"
echo "  3. Postgres ImagePullBackOff — fix: set IMG_POSTGRES in config.sh"
echo "  4. Postgres stuck Pending — fix: check storage class, longhorn health"
echo "  5. Keycloak can't resolve 'postgres' — cluster DNS broken (run ./diagnose-dns.sh)"
