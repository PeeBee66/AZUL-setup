#!/usr/bin/env bash
# 05 - Install OpenSearch (requires cert-manager from step 00, OpenSearch operator from step 02)
#
# Cert setup (keycloak-tls + CA trust patch) is delegated to setup-certs.sh
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/azul-infra"
VALUES="${SCRIPT_DIR}/values.yaml"

# Build defaultRepo arg (only if IMG_OS_REPO is set)
OS_REPO_ARGS=()
if [[ -n "$IMG_OS_REPO" ]]; then
  OS_REPO_ARGS=(--set defaultRepo="$IMG_OS_REPO")
fi

echo "=== Installing OpenSearch ==="

# --- Generate bcrypt hashes from config.sh passwords ---
# OpenSearch's security plugin uses bcrypt hashes in the internalUsers config.
# The values.yaml has PLACEHOLDER hashes — we override them with freshly-generated
# hashes that match the plaintext passwords in config.sh. This way, changing a
# password in config.sh "just works" without manual hash regeneration.
if ! python3 -c "import bcrypt" 2>/dev/null; then
  echo "FATAL: Python 'bcrypt' module required. Install with:"
  echo "  RHEL/Rocky: dnf install python3-bcrypt"
  echo "  Ubuntu:     apt install python3-bcrypt"
  echo "  pip:        pip3 install bcrypt"
  exit 1
fi

bcrypt_hash() {
  python3 -c "import bcrypt,sys; print(bcrypt.hashpw(sys.argv[1].encode(), bcrypt.gensalt(12)).decode())" "$1"
}

echo "Generating bcrypt hashes for internal users..."
OS_ADMIN_HASH=$(bcrypt_hash "$OS_ADMIN_PASS")
OS_DASH_HASH=$(bcrypt_hash "$OS_DASH_PASS")
OS_MONITOR_HASH=$(bcrypt_hash "$OS_MONITOR_PASS")
OS_WRITER_HASH=$(bcrypt_hash "$OS_WRITER_PASS")

kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

if ! kubectl -n "$NAMESPACE" get secret azul-cluster-admincredentials >/dev/null 2>&1; then
  echo "Creating OpenSearch admin credentials secret..."
  kubectl -n "$NAMESPACE" create secret generic azul-cluster-admincredentials \
    --from-literal=username=admin \
    --from-literal=password="$OS_ADMIN_PASS"
fi

if ! kubectl -n "$NAMESPACE" get secret azul-cluster-dashboardcredentials >/dev/null 2>&1; then
  echo "Creating OpenSearch dashboard credentials secret..."
  kubectl -n "$NAMESPACE" create secret generic azul-cluster-dashboardcredentials \
    --from-literal=username=kibanaserver \
    --from-literal=password="$OS_DASH_PASS"
fi

helm install azul-opensearch "$CHART" \
  -n "$NAMESPACE" \
  -f "$VALUES" \
  --set keycloak.enable=false \
  --set kafka.enable=false \
  --set minio.main.enable=false \
  --set minio.backup.enable=false \
  --set opensearch.ingress.host="$OPENSEARCH_HOST" \
  --set opensearch.dashboard.ingress.host="$OPENSEARCH_HOST" \
  --set "opensearch.dashboard.additionalConfig.opensearch_security\.openid\.connect_url=https://${KEYCLOAK_HOST}/realms/${KC_REALM}/.well-known/openid-configuration" \
  --set "opensearch.dashboard.additionalConfig.opensearch_security\.openid\.base_redirect_url=https://${OPENSEARCH_HOST}" \
  --set "opensearch.dashboard.additionalConfig.opensearch_security\.openid\.client_id=${KC_OSD_CLIENT_ID}" \
  --set "opensearch.dashboard.additionalConfig.opensearch_security\.openid\.client_secret=${KC_OSD_CLIENT_SECRET}" \
  --set "opensearch.securityConfig.config.dynamic.authc.openid_auth_domain.http_authenticator.config.openid_connect_url=https://${KEYCLOAK_HOST}/realms/${KC_REALM}/.well-known/openid-configuration" \
  --set opensearch.certificateSuffix="$CERT_OS_SUFFIX" \
  --set opensearch.cert.caCommonName="$CERT_CA_COMMON_NAME" \
  --set opensearch.cert.caDuration="$CERT_CA_DURATION" \
  --set opensearch.cert.duration="$CERT_INTERNAL_DURATION" \
  --set opensearch.cert.renewBefore="$CERT_INTERNAL_RENEW_BEFORE" \
  --set opensearch.cert.keySize="$CERT_KEY_SIZE" \
  --set opensearch.cert.keyAlgorithm="$CERT_KEY_ALGORITHM" \
  --set-string "opensearch.internalUsers.admin.hash=${OS_ADMIN_HASH}" \
  --set-string "opensearch.internalUsers.kibanaserver.hash=${OS_DASH_HASH}" \
  --set-string "opensearch.internalUsers.monitor.hash=${OS_MONITOR_HASH}" \
  --set-string "opensearch.internalUsers.azul_writer.hash=${OS_WRITER_HASH}" \
  "${OS_REPO_ARGS[@]}"

echo "Waiting for OpenSearch cluster to be ready (this takes several minutes)..."
for i in $(seq 1 60); do
  HEALTH=$(kubectl -n "$NAMESPACE" get opensearchclusters azul-opensearch -o jsonpath='{.status.health}' 2>/dev/null || echo "unknown")
  if [[ "$HEALTH" == "green" ]]; then
    echo "OpenSearch cluster is green."
    break
  fi
  echo "  [$i/60] health=$HEALTH, waiting 10s..."
  sleep 10
done

# --- Delegate all cert setup to setup-certs.sh ---
"${SCRIPT_DIR}/setup-certs.sh" infra

echo "=== OpenSearch installed ==="
