#!/usr/bin/env bash
# 03 - Install Keycloak + PostgreSQL
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/azul-infra"
VALUES="${SCRIPT_DIR}/values.yaml"

echo "=== Installing Keycloak + PostgreSQL ==="

kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

if ! kubectl -n "$NAMESPACE" get secret keycloak >/dev/null 2>&1; then
  echo "Creating keycloak secret..."
  kubectl -n "$NAMESPACE" create secret generic keycloak \
    --from-literal=DB_PASSWORD="$KC_DB_PASSWORD" \
    --from-literal=KEYCLOAK_ADMIN_PASSWORD="$KC_ADMIN_PASSWORD"
fi

helm install azul-keycloak "$CHART" \
  -n "$NAMESPACE" \
  -f "$VALUES" \
  --set kafka.enable=false \
  --set opensearch.enable=false \
  --set minio.main.enable=false \
  --set minio.backup.enable=false \
  --set keycloak.ingress.hostname="$KEYCLOAK_HOST" \
  --set keycloak.image="$IMG_KEYCLOAK" \
  --set keycloak.postgresImage="$IMG_POSTGRES"

echo "Waiting for PostgreSQL..."
kubectl -n "$NAMESPACE" rollout status deployment/postgres --timeout=120s
echo "Waiting for Keycloak..."
kubectl -n "$NAMESPACE" rollout status deployment/keycloak --timeout=180s

echo "=== Keycloak + PostgreSQL installed ==="
