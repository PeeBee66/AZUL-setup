# AZUL Install Troubleshooting — Issues Found & Fixed

This document captures every problem encountered during install/test cycles
and the exact commands used to diagnose and fix them. Use it as a reference
when an install fails.

All commands assume:
```bash
export KUBECONFIG=/home/kp-admin/KUBS/kubeconfig
```


## 1. OpenSearch single-node quorum failure

### Symptom
After `05_install_opensearch.sh`:
- Pod `azul-opensearch-nodes-0` stays `0/1 Running`
- API returns `cluster_manager_not_discovered_exception`
- Logs show: `election requires a node with id [X], have discovered [Y]`

### Root cause
The OpenSearch operator creates a temporary `bootstrap` pod to initialize the
cluster, then deletes it. The remaining data node was bootstrapped with the
bootstrap pod's ID in its cluster state — when the bootstrap pod is removed,
the data node can't form a quorum because the cluster expects the removed node.

### Diagnosis commands
```bash
kubectl -n azul-infra get pods -l opster.io/opensearch-cluster=azul-opensearch
kubectl -n azul-infra logs azul-opensearch-nodes-0 -c opensearch --tail=20
kubectl -n azul-infra get opensearchclusters
kubectl -n azul-infra exec azul-opensearch-nodes-0 -c opensearch -- \
  curl -sk -u admin:PASSWORD https://localhost:9200/_cluster/health
```

### Fix (baked into values.yaml)
Added to `values.yaml` under `opensearch.general.additionalConfig`:
```yaml
additionalConfig:
  cluster.initial_cluster_manager_nodes: "azul-opensearch-nodes-0"
```

This tells OpenSearch to accept `nodes-0` as a valid initial master, so when
the bootstrap pod is removed, the main node can self-elect.


## 2. OpenSearch passwords didn't match bcrypt hashes

### Symptom
- `401 Authentication finally failed` on OpenSearch API calls
- REST API returns 500 "could not get user account"

### Root cause
The bcrypt hashes in `values.yaml` (`opensearch.internalUsers`) are
independent of the `azul-cluster-admincredentials` secret. They must match
each other — if hashes are regenerated or passwords changed, they drift apart.

### Diagnosis commands
```bash
# Check credentials in use
kubectl -n azul-infra get secret azul-cluster-admincredentials \
  -o jsonpath='{.data.password}' | base64 -d; echo

# Check hash in security config
kubectl -n azul-infra get secret azul-opensearch-securityconfig \
  -o jsonpath='{.data.internal_users\.yml}' | base64 -d | head -10

# Verify password matches hash
python3 -c "import bcrypt; print(bcrypt.checkpw(b'PASSWORD_HERE', b'BCRYPT_HASH_HERE'))"
```

### Fix (baked into values.yaml)
Regenerated bcrypt hashes matching passwords in `config.sh`:
```bash
python3 -c "import bcrypt; print(bcrypt.hashpw(b'cuvJ7K09EgApwfV2o9rQ7avR554uRP7e', bcrypt.gensalt(12)).decode())"
```

Updated `values.yaml` under `opensearch.internalUsers.{admin,kibanaserver,monitor,azul_writer}.hash`.


## 3. CoreDNS missing `*.kp.local` entries

### Symptom
- Dashboards crash-loops with `getaddrinfo EBUSY keycloak-azul.kp.local`
- REST API can't validate JWTs: `could not get user account: (401, b'Authentication finally failed')`

### Root cause
Pods can't resolve `keycloak-azul.kp.local` from inside the cluster. CoreDNS's
default config forwards to `/etc/resolv.conf` which (on nodes) may not know
about Pi-hole entries for `*.kp.local`.

### Diagnosis commands
```bash
kubectl -n kube-system get configmap coredns -o jsonpath='{.data.Corefile}'
kubectl run dns-test --rm -i --restart=Never --image=busybox -- \
  nslookup keycloak-azul.kp.local
```

### Fix (script 07)
`07_setup_coredns.sh` patches the CoreDNS configmap to add:
```
hosts {
    192.168.66.201 keycloak-azul.kp.local
    192.168.66.201 opensearch-azul.kp.local
    ...
    fallthrough
}
```


## 4. Keycloak TLS cert missing

### Symptom
- Dashboards: `DEPTH_ZERO_SELF_SIGNED_CERT` when calling Keycloak
- OpenSearch logs: `PKIX path validation failed: Path does not chain with any of the trust anchors`

### Root cause
The ingress references `secretName: keycloak-tls` but the secret didn't exist.
Without it, nginx serves its default fake cert.

### Diagnosis commands
```bash
kubectl -n azul-infra get secret keycloak-tls
kubectl -n azul-infra get ingress keycloak -o yaml | grep secretName
kubectl -n azul-infra get certificates
kubectl -n azul-infra get issuers
```

### Fix (script 05 → setup-certs.sh)
`setup-certs.sh infra` creates a Certificate using the OpenSearch CA issuer:
```yaml
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: keycloak-tls-cert
  namespace: azul-infra
spec:
  secretName: keycloak-tls
  commonName: keycloak-azul.kp.local
  dnsNames: [keycloak-azul.kp.local]
  issuerRef:
    name: azul-opensearch-ca-issuer
    kind: Issuer
```


## 5. OpenSearch doesn't trust the current CA

### Symptom
- OpenSearch logs: `PKIX path validation failed` when fetching JWKS
- REST API: `could not get user account: (401, b'Authentication finally failed')` (after apparent login success)

### Root cause
The `azul-opensearch-certs` configmap has an older "Test CA" baked into the
chart from a previous install. cert-manager generates a **new** self-signed CA
on each install, so the trust bundle is stale.

### Diagnosis commands
```bash
# Compare current CA fingerprint vs configmap
kubectl -n azul-infra get secret azul-opensearch-ca-cert \
  -o jsonpath='{.data.ca\.crt}' | base64 -d | openssl x509 -noout -fingerprint

kubectl -n azul-infra get cm azul-opensearch-certs \
  -o jsonpath='{.data.ca-certificates}' | grep -A30 "Test CA" \
  | openssl x509 -noout -fingerprint

# OpenSearch error
kubectl -n azul-infra logs azul-opensearch-nodes-0 -c opensearch --tail=50 \
  | grep -i "pkix\|keyset"
```

### Fix (script 05 → setup-certs.sh `patch_opensearch_ca_trust`)
Append current CA to the configmap and restart the OpenSearch node:
```bash
CURRENT_CA=$(kubectl -n azul-infra get secret azul-opensearch-ca-cert \
  -o jsonpath='{.data.ca\.crt}' | base64 -d)

kubectl -n azul-infra get cm azul-opensearch-certs -o json | \
  CURRENT_CA="$CURRENT_CA" python3 -c "
import json, sys, os
cm = json.load(sys.stdin)
cm['data']['ca-certificates'] = cm['data']['ca-certificates'].rstrip() + \
    '\n\n# Current azul-opensearch-ca-cert\n' + os.environ['CURRENT_CA'] + '\n'
cm['metadata'].pop('resourceVersion', None)
print(json.dumps(cm))
" | kubectl apply -f -

kubectl -n azul-infra delete pod azul-opensearch-nodes-0
```


## 6. Keycloak realm missing

### Symptom
- Dashboards: `Response Error: 404 Not Found` on OIDC discovery
- Payload: `{"error":"Realm does not exist"}`

### Root cause
Keycloak installs with only the `master` realm. The `azul` realm and all its
clients/roles/users must be created separately.

### Diagnosis commands
```bash
curl -k -H "Host: keycloak-azul.kp.local" \
  https://192.168.66.201/realms/azul/.well-known/openid-configuration
# 404 = realm doesn't exist

# List realms via admin API
POD=$(kubectl -n azul-infra get pods -l app=keycloak -o jsonpath='{.items[0].metadata.name}')
KC_PASS=$(kubectl get secret keycloak -n azul-infra -o jsonpath='{.data.KEYCLOAK_ADMIN_PASSWORD}' | base64 -d)
kubectl -n azul-infra exec "$POD" -- bash -c "
  /opt/keycloak/bin/kcadm.sh config credentials --server http://localhost:8080 \
    --realm master --user admin --password '$KC_PASS' >/dev/null
  /opt/keycloak/bin/kcadm.sh get realms --fields realm,enabled
"
```

### Fix (script 08)
`08_setup_keycloak.sh` creates the realm via port-forward + REST API:
- Realm: `azul`
- Roles: `azul-access`, `azul_read`, `azul_admin`, `azul_write`, `s-any`, `s-official`
- Groups: `general`, `opensearch-admins`
- Client scopes: `azul` (with realm-roles + subject mappers), `audience`
- Clients: `azul-web` (public), `opensearch-dashboards` (confidential), `azul-service`
- Users: `basic`, `azuladmin`


## 7. Admin user not created (script interrupted)

### Symptom
- `basic` login works, `azuladmin` returns `invalid_grant: Invalid user credentials`

### Root cause
Earlier run of `08_setup_keycloak.sh` was interrupted (port-forward killed
mid-run, Python exception in group lookup). The test user was created but
step 11 (admin user) didn't complete.

### Diagnosis commands
```bash
# Test each user
for u in basic:basic12345 azuladmin:admin12345; do
  user=${u%:*}; pass=${u#*:}
  curl -k -s -X POST \
    "https://keycloak-azul.kp.local/realms/azul/protocol/openid-connect/token" \
    --resolve "keycloak-azul.kp.local:443:192.168.66.201" \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -d "username=$user&password=$pass&grant_type=password&client_id=azul-web" \
    | python3 -c "import sys,json; d=json.load(sys.stdin); \
      print(f'{\"$user\":12} {\"OK\" if \"access_token\" in d else \"FAIL\"}')"
done

# List users in realm
POD=$(kubectl -n azul-infra get pods -l app=keycloak -o jsonpath='{.items[0].metadata.name}')
KC_PASS=$(kubectl get secret keycloak -n azul-infra -o jsonpath='{.data.KEYCLOAK_ADMIN_PASSWORD}' | base64 -d)
kubectl -n azul-infra exec "$POD" -- bash -c "
  /opt/keycloak/bin/kcadm.sh config credentials --server http://localhost:8080 \
    --realm master --user admin --password '$KC_PASS' >/dev/null
  /opt/keycloak/bin/kcadm.sh get users -r azul --fields username,enabled
"
```

### Fix (inline command or re-run 08)
Option 1 — re-run the script (idempotent, 409s on existing resources):
```bash
./08_setup_keycloak.sh
```

Option 2 — create the missing user manually via kcadm:
```bash
kubectl -n azul-infra exec "$POD" -- bash -c "
  /opt/keycloak/bin/kcadm.sh config credentials --server http://localhost:8080 \
    --realm master --user admin --password '$KC_PASS'
  /opt/keycloak/bin/kcadm.sh create users -r azul \
    -s username=azuladmin -s enabled=true -s emailVerified=true
  /opt/keycloak/bin/kcadm.sh set-password -r azul \
    --username azuladmin --new-password admin12345
  for role in azul-access azul_read azul_admin azul_write s-any s-official; do
    /opt/keycloak/bin/kcadm.sh add-roles -r azul --uusername azuladmin --rolename \$role
  done
"
```

### Permanent fix
Removed `set -e` from `08_setup_keycloak.sh` so one failed API call doesn't
abort subsequent steps. Added `09_update.sh passwords` mode to reset user
passwords from config.sh idempotently.


## 8. Dashboards stuck in CrashLoopBackOff from pre-setup state

### Symptom
- Dashboards pod has many restarts even after CoreDNS + realm are fixed
- Restart intervals get exponentially long (up to 5 min)

### Root cause
K8s applies exponential backoff to crashing pods. If Dashboards started
before steps 07 and 08, it can take 10+ minutes to self-recover after the
prerequisites are in place.

### Diagnosis commands
```bash
kubectl -n azul-infra get pods -l opster.io/opensearch-dashboard=azul-opensearch
kubectl -n azul-infra logs <pod> --previous | grep -iE "error|fatal" | tail -3
```

### Fix (one-shot)
Delete the stuck pod to force immediate restart:
```bash
kubectl -n azul-infra delete pod $(kubectl -n azul-infra get pods \
  -o name | grep dash)
```


## 9. OpenSearch operator install timed out

### Symptom
```
Waiting for deployment "opensearch-operator-controller-manager" rollout to finish: 0 of 1 updated replicas are available...
error: timed out waiting for the condition
```
Retry fails with: `cannot reuse a name that is still in use`

### Root cause
The helm release is created even if the deployment doesn't become Ready in
time. Re-running `helm install` with the same name fails.

### Diagnosis commands
```bash
kubectl -n opensearch-operator get pods
kubectl -n opensearch-operator describe pod <pod-name> | tail -20
helm list -n opensearch-operator
```

### Fix (uninstall_all.sh per-component)
```bash
./uninstall_all.sh opensearch-op
./02_install_opensearch_operator.sh
```

Works the same way for any failed component: `strimzi`, `keycloak`, `kafka`,
`opensearch`, `minio`, `cert-manager`, `coredns`.


## 10. cert-manager install hung on startupapicheck

### Symptom
`00_install_cert_manager.sh` appears to hang after showing "Install complete",
with no further output for 1-2 minutes.

### Root cause
cert-manager chart includes a post-install hook Job (`startupapicheck`) that
verifies the webhook is working. `helm install` waits for all hooks to
complete. On some clusters this hook takes 1-2 minutes to succeed.

### Diagnosis commands
```bash
kubectl -n cert-manager get jobs
kubectl -n cert-manager get pods -l app.kubernetes.io/component=startupapicheck
kubectl -n cert-manager logs <startupapicheck-pod>
```

### Permanent fix (in install script)
Added to `00_install_cert_manager.sh`:
```bash
helm install cert-manager ... \
  --set startupapicheck.enabled=false \
  ...
```
Our own `kubectl rollout status` checks provide equivalent verification.


## 11. cert-manager shared with Rancher

### Symptom
Concern that uninstalling cert-manager would break Rancher's TLS cert renewal.

### Diagnosis commands
```bash
kubectl get certificates -A
kubectl get issuers -A
kubectl get clusterissuers
```

### Permanent fix (in uninstall_all.sh)
Before removing cert-manager, check for consumers outside Azul namespaces:
```bash
OTHER_CERTS=$(kubectl get certificates -A --no-headers 2>/dev/null \
  | awk '$1 !~ /^(azul|azul-infra)$/ {print $1"/"$2}')
# ... if any found, keep cert-manager
```


## Quick Reference — Full Diagnostic One-liner

Run this to check end-to-end health:

```bash
# Pod health
kubectl -n azul-infra get pods
kubectl -n azul get pods 2>/dev/null

# Auth flow
TOKEN=$(curl -k -s -X POST \
  "https://keycloak-azul.kp.local/realms/azul/protocol/openid-connect/token" \
  --resolve "keycloak-azul.kp.local:443:192.168.66.201" \
  -H 'Content-Type: application/x-www-form-urlencoded' \
  -d "username=basic&password=basic12345&grant_type=password&client_id=azul-web&scope=openid profile azul" \
  | python3 -c "import sys,json; print(json.load(sys.stdin).get('access_token','FAIL'))")
echo "Token: ${TOKEN:0:30}..."
curl -k -s --resolve "azul.kp.local:443:192.168.66.201" \
  -H "Authorization: Bearer $TOKEN" \
  "https://azul.kp.local/api/v0/users/me" -w "\n API: %{http_code}\n"
curl -k -s --resolve "azul.kp.local:443:192.168.66.201" \
  -H "Authorization: Bearer $TOKEN" \
  "https://azul.kp.local/api/v0/users/me/opensearch" -w "\n API+OS: %{http_code}\n"
```

All three should return HTTP 200 when the cluster is healthy.
