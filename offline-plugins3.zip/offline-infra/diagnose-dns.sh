#!/usr/bin/env bash
# Standalone DNS diagnostics — works offline (no image pulls)
#
# Run this when:
#   - Keycloak and OpenSearch can't talk
#   - Dashboards crash-loops with "getaddrinfo" errors
#   - OpenSearch logs show "PKIX path validation" or JWKS fetch failures
#
# It uses EXISTING pods to test DNS, so no image pulls are needed.
set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

FAIL=0

hr() { echo "----------------------------------------"; }
pass() { echo "  ✓ $*"; }
fail() { echo "  ✗ $*"; FAIL=1; }
info() { echo "  • $*"; }

echo "=== CoreDNS Diagnostic ==="
hr

# --- 1. Deployment exists ---
echo "1. CoreDNS deployment in kube-system"
if ! kubectl -n kube-system get deployment coredns >/dev/null 2>&1; then
    fail "No 'coredns' deployment — cluster DNS is broken"
    exit 1
fi
pass "deployment exists"

# --- 2. Pod status ---
echo ""
echo "2. CoreDNS pod status"
kubectl -n kube-system get pods -l k8s-app=kube-dns --no-headers | while read line; do
    name=$(echo "$line" | awk '{print $1}')
    ready=$(echo "$line" | awk '{print $2}')
    status=$(echo "$line" | awk '{print $3}')
    restarts=$(echo "$line" | awk '{print $4}')
    if [[ "$status" == "Running" ]] && [[ "$ready" == "1/1" ]]; then
        pass "$name  $ready  $status  (restarts: $restarts)"
    else
        fail "$name  $ready  $status  (restarts: $restarts)"
    fi
done

BAD_PODS=$(kubectl -n kube-system get pods -l k8s-app=kube-dns --no-headers 2>/dev/null | awk '$3 != "Running" || $2 != "1/1"')
if [[ -n "$BAD_PODS" ]]; then
    echo ""
    echo "   Events for first bad pod:"
    FIRST=$(echo "$BAD_PODS" | awk 'NR==1{print $1}')
    kubectl -n kube-system describe pod "$FIRST" 2>/dev/null | awk '/Events:/,/^$/' | head -15 | sed 's/^/     /'
fi

# --- 3. Image in use ---
echo ""
echo "3. CoreDNS image"
IMAGE=$(kubectl -n kube-system get deployment coredns -o jsonpath='{.spec.template.spec.containers[0].image}')
info "Deployment spec:  $IMAGE"
CONFIG_IMAGE="${COREDNS_IMAGE:-}"
if [[ -n "$CONFIG_IMAGE" ]]; then
    info "config.sh says:   $CONFIG_IMAGE"
    if [[ "$IMAGE" == "$CONFIG_IMAGE" ]]; then
        pass "Images match"
    else
        fail "Images don't match — run 07_setup_coredns.sh to apply COREDNS_IMAGE"
    fi
else
    info "config.sh COREDNS_IMAGE: (empty, using cluster default)"
fi

# --- 4. Hosts block in Corefile ---
echo ""
echo "4. Corefile hosts block"
COREFILE=$(kubectl -n kube-system get configmap coredns -o jsonpath='{.data.Corefile}' 2>/dev/null)
for h in "$KEYCLOAK_HOST" "$OPENSEARCH_HOST" "$MINIO_HOST" "$MINIO_API_HOST" "$AZUL_HOST"; do
    if echo "$COREFILE" | grep -q "$h"; then
        pass "$h  →  $CLUSTER_IP"
    else
        fail "$h NOT in Corefile — run 07_setup_coredns.sh"
    fi
done

# --- 5. DNS resolution test using existing pods (no image pull) ---
echo ""
echo "5. DNS resolution from inside the cluster"

# Find any Running pod with a shell. Prefer pods with getent/nslookup.
# Keycloak (JRE), OpenSearch (JRE), MinIO (go), Postgres (debian) all have getent.
TEST_POD=""
TEST_NS=""
for ns in azul-infra azul kube-system; do
    if kubectl get ns "$ns" >/dev/null 2>&1; then
        # Find a Running pod
        p=$(kubectl -n "$ns" get pods --no-headers --field-selector=status.phase=Running 2>/dev/null \
            | awk 'NR==1{print $1}')
        if [[ -n "$p" ]]; then
            TEST_POD="$p"; TEST_NS="$ns"; break
        fi
    fi
done

if [[ -z "$TEST_POD" ]]; then
    info "No Running pod available to test DNS from. Deploy Keycloak first (step 03)."
else
    info "Testing from pod: $TEST_NS/$TEST_POD"
    # Test each hostname — use getent (most universal) fallback to /etc/hosts inspection
    for h in "$KEYCLOAK_HOST" kubernetes.default.svc.cluster.local; do
        result=$(kubectl -n "$TEST_NS" exec "$TEST_POD" -- sh -c "getent hosts $h 2>/dev/null || nslookup $h 2>/dev/null | grep -i 'Address' | tail -1" 2>/dev/null)
        if [[ -n "$result" ]]; then
            pass "resolves: $h  →  $(echo "$result" | awk '{print $1}')"
        else
            fail "CANNOT resolve: $h"
        fi
    done
fi

# --- 6. kube-dns service ---
echo ""
echo "6. kube-dns Service"
if kubectl -n kube-system get svc kube-dns >/dev/null 2>&1; then
    CLUSTER_DNS=$(kubectl -n kube-system get svc kube-dns -o jsonpath='{.spec.clusterIP}')
    pass "kube-dns ClusterIP: $CLUSTER_DNS"
else
    fail "kube-dns service missing"
fi

hr
if [[ "$FAIL" == "1" ]]; then
    echo "RESULT: Issues found — see ✗ marks above"
    echo ""
    echo "Common fixes:"
    echo "  - If CoreDNS pods ImagePullBackOff:  set COREDNS_IMAGE in config.sh"
    echo "  - If hosts entries missing:          run ./07_setup_coredns.sh"
    echo "  - If DNS resolution fails:           see troubleshooting section below"
    exit 1
else
    echo "RESULT: CoreDNS is healthy."
fi
