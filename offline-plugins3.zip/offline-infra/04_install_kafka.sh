#!/usr/bin/env bash
# 04 - Install Kafka (requires Strimzi operator from step 01)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/azul-infra"
VALUES="${SCRIPT_DIR}/values.yaml"

echo "=== Installing Kafka ==="

kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

helm install azul-kafka "$CHART" \
  -n "$NAMESPACE" \
  -f "$VALUES" \
  --set keycloak.enable=false \
  --set opensearch.enable=false \
  --set minio.main.enable=false \
  --set minio.backup.enable=false \
  --set kafka.kafkactl.image="$IMG_KAFKACTL"

echo "Waiting for Kafka cluster to be ready (this takes a few minutes)..."
kubectl -n "$NAMESPACE" wait kafka/azul-kafka --for=condition=Ready --timeout=300s 2>/dev/null || \
  echo "Check manually: kubectl -n $NAMESPACE get kafka"

echo "=== Kafka installed ==="
