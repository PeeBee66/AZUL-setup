#!/usr/bin/env bash
# 02 - Install OpenSearch Operator (required by OpenSearch)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/opensearch-operator-2.8.0.tgz"

echo "=== Installing OpenSearch Operator ==="
helm install opensearch-operator "$CHART" \
  -n opensearch-operator --create-namespace \
  --set manager.image.repository="${IMG_OS_OPERATOR%:*}" \
  --set manager.image.tag="${IMG_OS_OPERATOR##*:}" \
  --set kubeRbacProxy.image.repository="${IMG_KUBE_RBAC_PROXY%:*}" \
  --set kubeRbacProxy.image.tag="${IMG_KUBE_RBAC_PROXY##*:}"

echo "Waiting for OpenSearch operator to be ready..."
kubectl -n opensearch-operator rollout status deployment/opensearch-operator-controller-manager --timeout=180s

echo "=== OpenSearch Operator installed ==="
