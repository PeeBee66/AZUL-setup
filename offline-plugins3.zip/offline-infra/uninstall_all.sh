#!/usr/bin/env bash
# Uninstall AZUL infra components.
#
# USAGE:
#   ./uninstall_all.sh                   # uninstall ALL components (interactive)
#   ./uninstall_all.sh all               # same as above, no prompt
#   ./uninstall_all.sh all --purge       # ALSO delete PVCs + namespaces (full wipe)
#   ./uninstall_all.sh cert-manager      # only cert-manager (safety-checked)
#   ./uninstall_all.sh strimzi           # only Strimzi operator
#   ./uninstall_all.sh opensearch-op     # only OpenSearch operator
#   ./uninstall_all.sh keycloak          # only Keycloak + Postgres (helm + secret)
#   ./uninstall_all.sh keycloak --purge  # also deletes postgres-claim PVC
#   ./uninstall_all.sh kafka             # only Kafka
#   ./uninstall_all.sh kafka --purge     # also deletes kafka PVC
#   ./uninstall_all.sh opensearch        # only OpenSearch + Dashboards + its certs
#   ./uninstall_all.sh opensearch --purge # also deletes opensearch PVC
#   ./uninstall_all.sh minio             # only MinIO
#   ./uninstall_all.sh minio --purge     # also deletes minio PVC
#   ./uninstall_all.sh coredns           # remove CoreDNS hosts entries
#   ./uninstall_all.sh purge             # JUST nuke PVCs + namespaces (after uninstalls)
#
# PURGE MODE:
#   Keycloak, OpenSearch, Kafka, and MinIO keep their PVCs by default so you
#   don't lose data. But if you're reinstalling with different PASSWORDS or
#   CONFIG, the old PVC state (e.g. Postgres's Keycloak DB with old passwords)
#   will override the new secrets — causing login failures.
#
#   Use --purge when you want a TRULY clean slate for fresh config.

set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

TARGET="${1:-all}"
PURGE_FLAG="${2:-}"
if [[ "$PURGE_FLAG" == "--purge" ]] || [[ "$TARGET" == "purge" ]]; then
    PURGE=true
else
    PURGE=false
fi

log() { echo "[uninstall] $*"; }

# --- Per-component uninstall functions ---------------------------------------

uninstall_cert_manager() {
    log "cert-manager:"
    OTHER_CERTS=$(kubectl get certificates -A --no-headers 2>/dev/null | awk '$1 !~ /^(azul|azul-infra)$/ {print $1"/"$2}')
    OTHER_ISSUERS=$(kubectl get issuers -A --no-headers 2>/dev/null | awk '$1 !~ /^(azul|azul-infra)$/ {print $1"/"$2}')
    OTHER_CLUSTER_ISSUERS=$(kubectl get clusterissuers --no-headers 2>/dev/null | awk '{print $1}')

    if [[ -n "$OTHER_CERTS" || -n "$OTHER_ISSUERS" || -n "$OTHER_CLUSTER_ISSUERS" ]]; then
        log "  KEPT — other consumers detected:"
        [[ -n "$OTHER_CERTS" ]]           && echo "$OTHER_CERTS"           | awk '{print "    Certificate: "$1}'
        [[ -n "$OTHER_ISSUERS" ]]         && echo "$OTHER_ISSUERS"         | awk '{print "    Issuer: "$1}'
        [[ -n "$OTHER_CLUSTER_ISSUERS" ]] && echo "$OTHER_CLUSTER_ISSUERS" | awk '{print "    ClusterIssuer: "$1}'
        log "  Force removal: helm uninstall cert-manager -n cert-manager"
    else
        helm uninstall cert-manager -n cert-manager 2>/dev/null && log "  removed" || log "  not found"
    fi
}

uninstall_strimzi() {
    log "Strimzi Kafka operator:"
    helm uninstall strimzi-kafka-operator -n kafka 2>/dev/null && log "  removed" || log "  not found"
    log "  (Strimzi CRDs kept — kafka namespace kept)"
}

uninstall_opensearch_op() {
    log "OpenSearch operator:"
    helm uninstall opensearch-operator -n opensearch-operator 2>/dev/null && log "  removed" || log "  not found"
}

uninstall_keycloak() {
    log "Keycloak + Postgres:"
    helm uninstall azul-keycloak -n azul-infra 2>/dev/null && log "  helm release removed" || log "  helm release not found"
    # Manually-created secret (03_install_keycloak.sh creates this outside helm)
    kubectl -n azul-infra delete secret keycloak --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
    if [[ "$PURGE" == "true" ]]; then
        # CRITICAL: postgres-claim contains the Keycloak DB. If you keep it,
        # old realm/users/passwords will persist and break reinstalls with new config.
        kubectl -n azul-infra delete pvc postgres-claim --ignore-not-found=true --wait=false 2>/dev/null | sed 's/^/  /'
        kubectl -n azul-infra delete pod -l app=postgres --grace-period=0 --force 2>/dev/null >/dev/null
    fi
}

uninstall_kafka() {
    log "Kafka:"
    helm uninstall azul-kafka -n azul-infra 2>/dev/null && log "  helm release removed" || log "  helm release not found"
    if [[ "$PURGE" == "true" ]]; then
        kubectl -n azul-infra delete pvc -l strimzi.io/cluster=azul-kafka --ignore-not-found=true --wait=false 2>/dev/null && log "  kafka PVCs removed"
        kubectl -n azul-infra delete pvc data-0-azul-kafka-nodes-0 --ignore-not-found=true --wait=false 2>/dev/null >/dev/null
    fi
}

uninstall_opensearch() {
    log "OpenSearch:"
    # cert-manager resources (setup-certs.sh creates these outside helm)
    kubectl -n azul-infra delete certificate keycloak-tls-cert --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
    kubectl -n azul-infra delete secret keycloak-tls --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
    # Credential secrets (05_install_opensearch.sh creates these outside helm)
    kubectl -n azul-infra delete secret azul-cluster-admincredentials azul-cluster-dashboardcredentials --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
    # Uninstall helm release (this removes CA/node/admin certs/issuers that are chart-owned)
    helm uninstall azul-opensearch -n azul-infra 2>/dev/null && log "  helm release removed" || log "  helm release not found"
    if [[ "$PURGE" == "true" ]]; then
        # PVC (data)
        kubectl -n azul-infra delete pvc data-azul-opensearch-nodes-0 --ignore-not-found=true --wait=false 2>/dev/null | sed 's/^/  /'
        # Chart-created secrets that may survive helm uninstall (cert-manager managed)
        kubectl -n azul-infra delete secret \
            azul-opensearch-ca-cert \
            azul-opensearch-certs \
            azul-opensearch-admin-certs \
            azul-opensearch-securityconfig \
            --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
        # Chart-created Certificate + Issuer CRs (helm should delete these, but
        # cert-manager may recreate the secrets — delete explicitly)
        kubectl -n azul-infra delete certificate \
            azul-opensearch-ca-certificate \
            azul-opensearch-certs \
            azul-opensearch-admin-certs \
            --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
        kubectl -n azul-infra delete issuer \
            azul-opensearch-selfsigned-issuer \
            azul-opensearch-ca-issuer \
            --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
        # ConfigMap (trust bundle, patched by setup-certs.sh)
        kubectl -n azul-infra delete configmap azul-opensearch-certs --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
    fi
}

uninstall_minio() {
    log "MinIO:"
    helm uninstall azul-minio -n azul-infra 2>/dev/null && log "  helm release removed" || log "  helm release not found"
    # Manually-created secret (06_install_minio.sh creates this outside helm)
    kubectl -n azul-infra delete secret s3-keys --ignore-not-found=true 2>/dev/null | sed 's/^/  /'
    if [[ "$PURGE" == "true" ]]; then
        kubectl -n azul-infra delete pvc data-s3-store-minio-0 --ignore-not-found=true --wait=false 2>/dev/null | sed 's/^/  /'
    fi
}

uninstall_coredns() {
    log "CoreDNS hosts entries:"
    COREFILE=$(kubectl -n kube-system get configmap coredns -o jsonpath='{.data.Corefile}' 2>/dev/null)
    if echo "$COREFILE" | grep -q "$KEYCLOAK_HOST"; then
        HOSTS_ENTRIES=$(echo "$COREFILE" | awk '/hosts \{/,/^    \}/' | grep -vE 'hosts \{|^    \}|fallthrough' | wc -l)
        EXPECTED=5
        if [[ "$HOSTS_ENTRIES" -eq "$EXPECTED" ]]; then
            kubectl -n kube-system get configmap coredns -o json | python3 -c "
import json, sys, re
cm = json.load(sys.stdin)
cm['data']['Corefile'] = re.sub(r'    hosts \{[^}]*fallthrough\n    \}\n', '', cm['data']['Corefile'])
cm['metadata'].pop('resourceVersion', None)
print(json.dumps(cm))
" | kubectl apply -f - >/dev/null
            kubectl -n kube-system rollout restart deployment/coredns >/dev/null
            kubectl -n kube-system rollout status deployment/coredns --timeout=60s >/dev/null 2>&1
            log "  removed"
        else
            log "  KEPT — hosts block has $HOSTS_ENTRIES entries (expected $EXPECTED). Edit manually:"
            log "    kubectl -n kube-system edit configmap coredns"
        fi
    else
        log "  (no Azul hosts entries found)"
    fi
}

show_leftovers() {
    echo ""
    echo "=== Leftover PVCs in azul-infra (data preserved) ==="
    LEFTOVER=$(kubectl -n azul-infra get pvc --no-headers 2>/dev/null)
    if [[ -n "$LEFTOVER" ]]; then
        echo "$LEFTOVER" | awk '{printf "  %-40s %-10s %s\n", $1, $2, $4}'
        echo "  (delete: kubectl -n azul-infra delete pvc --all)"
    else
        echo "  (none)"
    fi
    echo ""
    echo "=== Leftover namespaces ==="
    for ns in azul-infra kafka opensearch-operator cert-manager; do
        kubectl get ns "$ns" >/dev/null 2>&1 && echo "  $ns"
    done
}

# --- Dispatch ----------------------------------------------------------------

case "$TARGET" in
    all)
        if [[ -z "${1:-}" ]]; then
            echo "=== Uninstalling AZUL Infrastructure (ALL) ==="
            if [[ "$PURGE" == "true" ]]; then
                echo "*** --purge mode: PVCs and namespaces will ALSO be deleted (data loss) ***"
            else
                echo "PVCs are kept by default (data preserved)."
            fi
            read -p "Continue? (y/N) " -r
            [[ "$REPLY" =~ ^[Yy]$ ]] || exit 0
        fi
        # Reverse order of install
        uninstall_minio
        uninstall_opensearch
        uninstall_kafka
        uninstall_keycloak
        uninstall_opensearch_op
        uninstall_strimzi
        uninstall_cert_manager
        uninstall_coredns
        if [[ "$PURGE" == "true" ]]; then
            log "Clearing finalizers on OpenSearch CRs (operator is gone, can't clean itself)..."
            for ns in azul-infra; do
                kubectl -n "$ns" get opensearchclusters -o name 2>/dev/null | while read cr; do
                    kubectl -n "$ns" patch "$cr" -p '{"metadata":{"finalizers":[]}}' --type=merge 2>/dev/null | sed 's/^/  /'
                done
                # Same for Kafka CRs (Strimzi gone)
                kubectl -n "$ns" get kafkas.kafka.strimzi.io -o name 2>/dev/null | while read cr; do
                    kubectl -n "$ns" patch "$cr" -p '{"metadata":{"finalizers":[]}}' --type=merge 2>/dev/null | sed 's/^/  /'
                done
                kubectl -n "$ns" get kafkanodepools.kafka.strimzi.io -o name 2>/dev/null | while read cr; do
                    kubectl -n "$ns" patch "$cr" -p '{"metadata":{"finalizers":[]}}' --type=merge 2>/dev/null | sed 's/^/  /'
                done
            done
            log "Removing namespaces (purge)..."
            kubectl delete ns azul-infra azul kafka opensearch-operator --wait=false 2>/dev/null | sed 's/^/  /'
            log "Removing Strimzi + OpenSearch CRDs (purge)..."
            kubectl get crd 2>/dev/null | grep -E 'strimzi|opster' | awk '{print $1}' | xargs -r kubectl delete crd --wait=false 2>/dev/null | sed 's/^/  /' | tail -3
        fi
        show_leftovers
        ;;
    purge)
        # Nuke ALL PVCs and namespaces (assumes helm releases already removed)
        echo "=== PURGE — deleting all Azul PVCs and namespaces ==="
        echo "This is irreversible. Data will be lost."
        read -p "Continue? (y/N) " -r
        [[ "$REPLY" =~ ^[Yy]$ ]] || exit 0
        for ns in azul-infra azul; do
            if kubectl get ns "$ns" >/dev/null 2>&1; then
                log "Deleting PVCs in $ns..."
                kubectl -n "$ns" delete pvc --all --wait=false 2>/dev/null | sed 's/^/  /' | tail -10
            fi
        done
        log "Deleting namespaces..."
        kubectl delete ns azul-infra azul kafka opensearch-operator --wait=false 2>/dev/null | sed 's/^/  /'
        log "Removing Strimzi + OpenSearch CRDs..."
        kubectl get crd 2>/dev/null | grep -E 'strimzi|opster' | awk '{print $1}' | xargs -r kubectl delete crd --wait=false 2>/dev/null | sed 's/^/  /' | tail -3
        ;;
    cert-manager)      uninstall_cert_manager ;;
    strimzi)           uninstall_strimzi ;;
    opensearch-op|opensearch-operator) uninstall_opensearch_op ;;
    keycloak)          uninstall_keycloak ;;
    kafka)             uninstall_kafka ;;
    opensearch)        uninstall_opensearch ;;
    minio)             uninstall_minio ;;
    coredns)           uninstall_coredns ;;
    -h|--help|help)
        grep -E "^#( |$)" "$0" | sed 's/^# \{0,1\}//'
        exit 0
        ;;
    *)
        echo "ERROR: unknown component: $TARGET"
        echo "Run '$0 --help' for usage."
        exit 1
        ;;
esac

echo ""
echo "=== Uninstall complete ==="
