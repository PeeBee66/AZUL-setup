#!/usr/bin/env bash
# 07 - Configure CoreDNS for AZUL
#
# What this script does:
#   1. Shows current CoreDNS image (diagnostic)
#   2. If COREDNS_IMAGE is set in config.sh, patches the deployment to use it
#      (useful in offline envs or when Rancher's mirrored image fails)
#   3. Adds *.kp.local hosts entries to the CoreDNS configmap
#   4. Restarts CoreDNS and verifies it comes back up
#
# CoreDNS itself is a cluster component — we don't install it, we only configure it.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

echo "=== CoreDNS setup ==="

# --- Pre-flight: verify CoreDNS deployment exists ---
if ! kubectl -n kube-system get deployment coredns >/dev/null 2>&1; then
    echo "FATAL: No 'coredns' deployment found in kube-system."
    echo "CoreDNS is a cluster component. Ensure your k3s/Talos cluster is healthy."
    exit 1
fi

# --- Show current state ---
CURRENT_IMAGE=$(kubectl -n kube-system get deployment coredns \
    -o jsonpath='{.spec.template.spec.containers[0].image}')
echo "Current CoreDNS image: ${CURRENT_IMAGE}"

# Check pod health — detect ImagePullBackOff, CrashLoop, etc.
POD_ISSUES=$(kubectl -n kube-system get pods -l k8s-app=kube-dns --no-headers 2>/dev/null \
    | awk '$3 != "Running" || $2 != $2 {print "  "$0}')
if [[ -n "$POD_ISSUES" ]]; then
    echo "WARNING: CoreDNS pods are not all Running:"
    echo "$POD_ISSUES"
    # Common cause: image can't be pulled — show the error
    BAD_POD=$(kubectl -n kube-system get pods -l k8s-app=kube-dns --no-headers \
        | awk '$3 != "Running"{print $1; exit}')
    if [[ -n "$BAD_POD" ]]; then
        echo ""
        echo "Last events for $BAD_POD:"
        kubectl -n kube-system describe pod "$BAD_POD" | grep -A2 "Events:" | tail -6 | sed 's/^/  /'
    fi
    echo ""
fi

# --- Apply COREDNS_IMAGE override if set ---
if [[ -n "${COREDNS_IMAGE:-}" ]]; then
    if [[ "$CURRENT_IMAGE" != "$COREDNS_IMAGE" ]]; then
        echo "Overriding CoreDNS image: ${CURRENT_IMAGE} -> ${COREDNS_IMAGE}"
        kubectl -n kube-system set image deployment/coredns coredns="$COREDNS_IMAGE"
    else
        echo "CoreDNS image already set to ${COREDNS_IMAGE}"
    fi
else
    echo "COREDNS_IMAGE not set in config.sh — keeping ${CURRENT_IMAGE}"
fi

# --- Apply hosts entries ---
EXISTING=$(kubectl -n kube-system get configmap coredns -o jsonpath='{.data.Corefile}' 2>/dev/null)
if echo "$EXISTING" | grep -q "$KEYCLOAK_HOST"; then
    echo "Hosts entries already present — skipping configmap patch."
else
    echo "Adding Azul host entries to CoreDNS configmap..."
    HOSTS_BLOCK="    hosts {
        ${CLUSTER_IP} ${KEYCLOAK_HOST}
        ${CLUSTER_IP} ${OPENSEARCH_HOST}
        ${CLUSTER_IP} ${MINIO_HOST}
        ${CLUSTER_IP} ${MINIO_API_HOST}
        ${CLUSTER_IP} ${AZUL_HOST}
        fallthrough
    }
"
    kubectl -n kube-system get configmap coredns -o json | \
        HOSTS_BLOCK="$HOSTS_BLOCK" python3 -c "
import json, sys, os, re
cm = json.load(sys.stdin)
corefile = cm['data']['Corefile']
corefile = re.sub(r'(    prometheus :\d+\n)', r'\1' + os.environ['HOSTS_BLOCK'], corefile)
cm['data']['Corefile'] = corefile
cm['metadata'].pop('resourceVersion', None)
json.dump(cm, sys.stdout)
" | kubectl apply -f -
fi

# --- Restart CoreDNS and wait ---
echo "Restarting CoreDNS..."
kubectl -n kube-system rollout restart deployment/coredns

echo "Waiting for CoreDNS to become ready (timeout 120s)..."
if ! kubectl -n kube-system rollout status deployment/coredns --timeout=120s; then
    echo ""
    echo "FATAL: CoreDNS failed to roll out. Current state:"
    kubectl -n kube-system get pods -l k8s-app=kube-dns
    echo ""
    BAD_POD=$(kubectl -n kube-system get pods -l k8s-app=kube-dns --no-headers \
        | awk '$3 != "Running"{print $1; exit}')
    if [[ -n "$BAD_POD" ]]; then
        echo "Events for $BAD_POD:"
        kubectl -n kube-system describe pod "$BAD_POD" | grep -A5 "Events:" | tail -10
    fi
    echo ""
    echo "If this is 'ImagePullBackOff', set COREDNS_IMAGE in config.sh to a working image."
    exit 1
fi

echo "=== CoreDNS configured — image: $(kubectl -n kube-system get deploy coredns -o jsonpath='{.spec.template.spec.containers[0].image}') ==="
