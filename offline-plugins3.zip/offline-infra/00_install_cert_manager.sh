#!/usr/bin/env bash
# 00 - Install cert-manager (required by OpenSearch for TLS certificates)
#
# NOTE: cert-manager is often shared infrastructure (Rancher, ingress, etc.).
# This script detects an existing install and skips if already present.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/cert-manager-v1.17.2.tgz"

# --- Detect existing cert-manager install (any helm release, any namespace) ---
EXISTING=$(helm list -A -o json 2>/dev/null | python3 -c "
import sys, json
for r in json.load(sys.stdin):
    if r['chart'].startswith('cert-manager'):
        print(f\"{r['name']}\t{r['namespace']}\t{r['chart']}\")" 2>/dev/null)

if [[ -n "$EXISTING" ]]; then
    echo "=== cert-manager already installed — skipping ==="
    echo "$EXISTING" | awk -F'\t' '{printf "  Release: %s  Namespace: %s  Chart: %s\n", $1, $2, $3}'
    echo ""
    echo "If you need to reinstall, remove the existing release first:"
    echo "$EXISTING" | awk -F'\t' '{printf "  helm uninstall %s -n %s\n", $1, $2}'
    exit 0
fi

# Also check if the CRDs already exist (cert-manager installed via another method)
if kubectl get crd certificates.cert-manager.io >/dev/null 2>&1 && \
   kubectl get deployment cert-manager -n cert-manager >/dev/null 2>&1; then
    echo "=== cert-manager deployment exists (not managed by helm) — skipping ==="
    kubectl get deployment -n cert-manager 2>/dev/null | grep cert-manager
    exit 0
fi

echo "=== Installing cert-manager ==="
# startupapicheck.enabled=false — this post-install hook verifies the webhook is
# reachable but can hang 1-2 min on some clusters. Our own rollout-status checks
# below do the same verification, so we skip it.
helm install cert-manager "$CHART" \
  -n cert-manager --create-namespace \
  --set crds.enabled=true \
  --set startupapicheck.enabled=false \
  --set image.repository="${IMG_CERTMGR_CONTROLLER%:*}" \
  --set image.tag="${IMG_CERTMGR_CONTROLLER##*:}" \
  --set webhook.image.repository="${IMG_CERTMGR_WEBHOOK%:*}" \
  --set webhook.image.tag="${IMG_CERTMGR_WEBHOOK##*:}" \
  --set cainjector.image.repository="${IMG_CERTMGR_CAINJECTOR%:*}" \
  --set cainjector.image.tag="${IMG_CERTMGR_CAINJECTOR##*:}"

echo "Waiting for cert-manager to be ready..."
kubectl -n cert-manager rollout status deployment/cert-manager --timeout=120s
kubectl -n cert-manager rollout status deployment/cert-manager-webhook --timeout=120s

echo "=== cert-manager installed ==="
