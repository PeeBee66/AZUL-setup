#!/usr/bin/env bash
# Shared config for AZUL plugins install.
# Edit these values for your target environment.

# --- Container Registry ---
# Set to your offline registry (e.g. "myregistry.local:5000")
# Leave empty to pull from upstream (internet required).
REGISTRY=""

# --- Kubernetes ---
NAMESPACE="azul"

# --- Hostnames (must match what was used in offline-core) ---
AZUL_HOST="azul.kp.local"
KEYCLOAK_HOST="keycloak-azul.kp.local"

# --- Keycloak identity (must match offline-infra / offline-core) ---
KC_REALM="azul"
KC_WEB_CLIENT_ID="azul-web"

# --- Container Images ---
# Azul custom images — customRegistry is prepended to each image name
# To use an offline registry: set AZUL_IMAGE_REGISTRY="myregistry.local:5000/asdazul/"
AZUL_IMAGE_REGISTRY="docker.io/asdazul/"
AZUL_IMAGE_TAG="9.0.0"

# External images (full path:tag)
IMG_REDIS="docker.io/redis:8.4.0-bookworm"
IMG_TIKA="docker.io/apache/tika:3.2.3.0-full"
IMG_GIT_SYNC="registry.k8s.io/git-sync/git-sync:v4.5.0"

# --- External S3 backup (backup/recovery feature) ---
EXTERNAL_S3_ENDPOINT="192.168.66.41:9100"
EXTERNAL_S3_SECURE="false"
