AZUL Plugins - Offline Install Package
======================================

Target: k3s cluster (air-gapped)
Prerequisite: offline-core must be installed and running first.


BEFORE YOU START
----------------
1. Load all plugin container images from images.txt into your registry
2. Edit config.sh:
   - AZUL_IMAGE_REGISTRY -> your offline registry (same as offline-core)
   - IMG_TIKA, IMG_GIT_SYNC, IMG_REDIS -> matching your registry
   - Hostnames must match offline-core
3. Edit values.yaml to enable/disable individual plugins (plugins: section, line 489+)


INSTALL
-------
  ./01_install_plugins.sh

This does a `helm upgrade` on the existing 'azul' release, switching
pluginsEnabled from false to true and enabling the plugins in values.yaml.

Adds approximately 50 plugin pods across these categories:
  - office      (8 plugins — DDE, decrypt, macros, OLE, OpenXML, RTF, etc.)
  - tika        (metadata extraction — has Apache Tika sidecar)
  - generic     (40 plugins — yara, ghidra, exiftool, portex, etc.)
  - yara-x      (YARA-X rule scanning)
  - suricata    (Suricata IDS rules)
  - maco        (MACO extractor)

Disabled by default (enable in values.yaml if needed):
  - assemblyline, dynamic, nsrl, retrohunt, report-feeds, virustotal


NO NEW CERTIFICATES
-------------------
This package doesn't create any new certs. Plugin pods use the same CA
(azul-ca-cert configmap) that was set up by offline-core.

See offline-infra/README.txt CERTIFICATE INFRASTRUCTURE section for the
full cert chain.


RESOURCE NOTES
--------------
The heavy plugins (ghidra, mandiant-capa, unbox) request 2Gi memory each.
CPU requests have been reduced to 10m to help scheduling on small clusters.

If pods go Pending with "Insufficient cpu", either:
  - Add more cluster nodes
  - Disable unused plugins in values.yaml
  - Reduce resource requests further


DOWNGRADE (remove plugins, keep core)
-------------------------------------
  ./uninstall.sh

This does a helm upgrade back to the core values (pluginsEnabled: false).
Plugin pods are terminated but core pods keep running.

To fully remove AZUL, use offline-core/uninstall.sh.


CONTENTS
--------
  config.sh       # Registry, hostnames, image paths
  values.yaml     # Full values with plugins enabled
  images.txt      # Plugin container images (37 asdazul + tika + git-sync)
  charts/azul/    # AZUL application Helm chart (v9.0.0)
