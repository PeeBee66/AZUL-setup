#!/usr/bin/env bash
# Uninstall AZUL Core Application
set -uo pipefail

echo "=== Uninstalling AZUL Core ==="
read -p "Continue? (y/N) " -r
[[ "$REPLY" =~ ^[Yy]$ ]] || exit 0

helm uninstall azul -n azul 2>/dev/null && echo "  azul removed" || echo "  azul not found"

echo ""
echo "=== Leftover PVCs (data is preserved) ==="
LEFTOVER=$(kubectl -n azul get pvc --no-headers 2>/dev/null)
if [[ -n "$LEFTOVER" ]]; then
    echo "$LEFTOVER" | awk '{printf "  %-40s %-10s %s\n", $1, $2, $4}'
    echo ""
    echo "To delete all PVC data in azul:"
    echo "  kubectl -n azul delete pvc --all"
else
    echo "  (none)"
fi
echo ""
echo "=== Leftover secrets in azul ==="
kubectl -n azul get secrets --no-headers 2>/dev/null | awk '{print "  " $1}' || echo "  (none)"
echo ""
echo "To fully clean the namespace:"
echo "  kubectl delete namespace azul"
echo ""
echo "=== Uninstall complete ==="
