#!/usr/bin/env bash
# 01 - Install AZUL Core Application
# Requires: infra running (azul-infra namespace with Kafka, OpenSearch, MinIO, Keycloak)
#
# Cert setup (CA secret/configmap/issuer, web-tls) is delegated to setup-certs.sh
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/azul"
VALUES="${SCRIPT_DIR}/values.yaml"

IMAGE_ARGS=(
  --set images.customRegistry="$AZUL_IMAGE_REGISTRY"
  --set images.external.redis="$IMG_REDIS"
)

echo "=== Installing AZUL Core Application ==="

# --- Create namespace ---
kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

# --- Create secrets ---

# Copy MinIO keys from infra namespace
if ! kubectl -n "$NAMESPACE" get secret s3-keys >/dev/null 2>&1; then
  echo "Copying s3-keys from ${INFRA_NAMESPACE}..."
  kubectl get secret s3-keys -n "$INFRA_NAMESPACE" -o json \
    | python3 -c "
import sys, json
s = json.load(sys.stdin)
s['metadata'] = {'name': 's3-keys', 'namespace': '${NAMESPACE}'}
print(json.dumps(s))
" | kubectl apply -f -
fi

# Redis
if ! kubectl -n "$NAMESPACE" get secret redis >/dev/null 2>&1; then
  REDIS_PASS=$(openssl rand -base64 16)
  echo "Creating redis secret..."
  kubectl -n "$NAMESPACE" create secret generic redis \
    --from-literal=redis-username="" \
    --from-literal=redis-password="$REDIS_PASS" \
    --from-literal=password="$REDIS_PASS"
fi

# Metastore credentials (OpenSearch writer)
if ! kubectl -n "$NAMESPACE" get secret metastore-creds >/dev/null 2>&1; then
  echo "Creating metastore-creds secret..."
  kubectl -n "$NAMESPACE" create secret generic metastore-creds \
    --from-literal=writer="$OS_WRITER_PASS"
fi

# S3 backup keys (for recovery feature)
if ! kubectl -n "$NAMESPACE" get secret s3-backup-keys >/dev/null 2>&1; then
  echo "Creating s3-backup-keys secret..."
  kubectl -n "$NAMESPACE" create secret generic s3-backup-keys \
    --from-literal=access_key="$BACKUP_S3_USER" \
    --from-literal=secret_key="$BACKUP_S3_PASSWORD"
fi

# --- Delegate all cert setup to setup-certs.sh ---
# Creates in $NAMESPACE: CA secret copy, azul-ca-cert configmap, azul-ca-issuer, azul-web-tls cert
INFRA_NAMESPACE="$INFRA_NAMESPACE" AZUL_NAMESPACE="$NAMESPACE" \
  "${SCRIPT_DIR}/setup-certs.sh" azul "$NAMESPACE"

# --- Install chart ---
echo "Installing azul chart (core only, plugins disabled)..."
helm install azul "$CHART" \
  -n "$NAMESPACE" \
  -f "$VALUES" \
  --set "web.ingress.hosts[0]=${AZUL_HOST}" \
  --set "security.oidc.authority_url=https://${KEYCLOAK_HOST}/realms/azul" \
  --set-string "recovery.externalS3Endpoint=${EXTERNAL_S3_ENDPOINT}" \
  --set-string "recovery.externalS3Secure=${EXTERNAL_S3_SECURE}" \
  "${IMAGE_ARGS[@]}"

echo ""
echo "Waiting for core pods (metastore ingest pods may crash-loop 3-4 times on startup — this is normal)..."
echo "Monitor with:"
echo "  kubectl -n $NAMESPACE get pods -w"

echo "=== AZUL Core installed ==="
