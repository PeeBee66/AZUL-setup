#!/usr/bin/env bash
# Shared config for all infra install scripts.
# Edit these values for your target environment.

# --- Container Registry ---
# Set to your offline registry (e.g. "myregistry.local:5000")
# Leave empty to use upstream defaults (internet required).
REGISTRY=""

# --- Kubernetes ---
NAMESPACE="azul-infra"
CLUSTER_IP="192.168.66.201"

# --- Hostnames ---
AZUL_HOST="azul.kp.local"
KEYCLOAK_HOST="keycloak-azul.kp.local"
OPENSEARCH_HOST="opensearch-azul.kp.local"
MINIO_HOST="minio-azul.kp.local"
MINIO_API_HOST="minio-api-azul.kp.local"

# --- Container Images ---
# cert-manager
IMG_CERTMGR_CONTROLLER="quay.io/jetstack/cert-manager-controller:v1.17.2"
IMG_CERTMGR_WEBHOOK="quay.io/jetstack/cert-manager-webhook:v1.17.2"
IMG_CERTMGR_CAINJECTOR="quay.io/jetstack/cert-manager-cainjector:v1.17.2"
IMG_CERTMGR_STARTUP="quay.io/jetstack/cert-manager-startupapicheck:v1.17.2"

# Strimzi (defaultImageRegistry + defaultImageRepository cover all strimzi images)
IMG_STRIMZI_REGISTRY="quay.io"
IMG_STRIMZI_REPOSITORY="strimzi"
IMG_STRIMZI_TAG="0.50.0"

# OpenSearch Operator
IMG_OS_OPERATOR="opensearchproject/opensearch-operator:2.8.0"
IMG_KUBE_RBAC_PROXY="gcr.io/kubebuilder/kube-rbac-proxy:v0.15.0"

# Keycloak + Postgres
IMG_KEYCLOAK="quay.io/keycloak/keycloak:26.1"
IMG_POSTGRES="postgres:17.4"

# Kafka (broker images come from Strimzi above, this is just kafkactl)
IMG_KAFKACTL="deviceinsight/kafkactl:v5.13.0-ubuntu"

# OpenSearch (operator pulls these — defaultRepo prefixes the image name)
IMG_OS_REPO=""  # leave empty for default Docker Hub, or set to "myregistry.local:5000"

# MinIO
IMG_MINIO="minio/minio:RELEASE.2025-09-07T16-13-09Z"

# --- Credentials ---
# OpenSearch (values.yaml users: admin, monitor, azul_writer)
OS_ADMIN_PASS="cuvJ7K09EgApwfV2o9rQ7avR554uRP7e"
# bcrypt: $2b$12$E0UZmxoizsBfIe83GLANoefDcUrqiSNuqLMJ72NCnfF2urN19.k7K

# OpenSearch Dashboards (values.yaml user: kibanaserver)
OS_DASH_PASS="4xIQW0pLfSWFbvnHCJWpWJUqKCIYio4A"
# bcrypt: $2b$12$KNrt1DvaU/PwSH8Mc9fmJeGgasFSVYU2cZK6O5ZZw1gfjORb2EQlS

# Keycloak
KC_ADMIN_PASSWORD="aDwQL6kkEl3MIcyTXBNMpCmC+oAPHWl0"
KC_DB_PASSWORD="MAgLmTJwrtesmwVuOp5vcVg8EIHBhmQ1"

# MinIO
S3_ACCESS_KEY="b26340be283b45acc0ba6afbf2789800"
S3_SECRET_KEY="38fbf2b72e819df4e9d7dbfaecf9983f20dae7a6ebec0611410af9331caf361e"

# --- Keycloak Realm Setup ---
KC_LOCAL_PORT="18080"
TEST_USER="basic"
TEST_PASSWORD="basic12345"
ADMIN_USER="azuladmin"
ADMIN_PASSWORD="admin12345"
DOMAIN="kp.local"
