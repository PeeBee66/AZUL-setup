#!/usr/bin/env bash
# 05 - Install OpenSearch (requires cert-manager from step 00, OpenSearch operator from step 02)
#
# Cert setup (keycloak-tls + CA trust patch) is delegated to setup-certs.sh
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/azul-infra"
VALUES="${SCRIPT_DIR}/values.yaml"

# Build defaultRepo arg (only if IMG_OS_REPO is set)
OS_REPO_ARGS=()
if [[ -n "$IMG_OS_REPO" ]]; then
  OS_REPO_ARGS=(--set defaultRepo="$IMG_OS_REPO")
fi

echo "=== Installing OpenSearch ==="

kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

if ! kubectl -n "$NAMESPACE" get secret azul-cluster-admincredentials >/dev/null 2>&1; then
  echo "Creating OpenSearch admin credentials secret..."
  kubectl -n "$NAMESPACE" create secret generic azul-cluster-admincredentials \
    --from-literal=username=admin \
    --from-literal=password="$OS_ADMIN_PASS"
fi

if ! kubectl -n "$NAMESPACE" get secret azul-cluster-dashboardcredentials >/dev/null 2>&1; then
  echo "Creating OpenSearch dashboard credentials secret..."
  kubectl -n "$NAMESPACE" create secret generic azul-cluster-dashboardcredentials \
    --from-literal=username=kibanaserver \
    --from-literal=password="$OS_DASH_PASS"
fi

helm install azul-opensearch "$CHART" \
  -n "$NAMESPACE" \
  -f "$VALUES" \
  --set keycloak.enable=false \
  --set kafka.enable=false \
  --set minio.main.enable=false \
  --set minio.backup.enable=false \
  --set opensearch.ingress.host="$OPENSEARCH_HOST" \
  --set opensearch.dashboard.ingress.host="$OPENSEARCH_HOST" \
  --set "opensearch.dashboard.additionalConfig.opensearch_security\.openid\.connect_url=https://${KEYCLOAK_HOST}/realms/azul/.well-known/openid-configuration" \
  --set "opensearch.dashboard.additionalConfig.opensearch_security\.openid\.base_redirect_url=https://${OPENSEARCH_HOST}" \
  --set "opensearch.securityConfig.config.dynamic.authc.openid_auth_domain.http_authenticator.config.openid_connect_url=https://${KEYCLOAK_HOST}/realms/azul/.well-known/openid-configuration" \
  "${OS_REPO_ARGS[@]}"

echo "Waiting for OpenSearch cluster to be ready (this takes several minutes)..."
for i in $(seq 1 60); do
  HEALTH=$(kubectl -n "$NAMESPACE" get opensearchclusters azul-opensearch -o jsonpath='{.status.health}' 2>/dev/null || echo "unknown")
  if [[ "$HEALTH" == "green" ]]; then
    echo "OpenSearch cluster is green."
    break
  fi
  echo "  [$i/60] health=$HEALTH, waiting 10s..."
  sleep 10
done

# --- Delegate all cert setup to setup-certs.sh ---
"${SCRIPT_DIR}/setup-certs.sh" infra

echo "=== OpenSearch installed ==="
