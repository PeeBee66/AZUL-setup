#!/usr/bin/env bash
# Uninstall AZUL infra components.
#
# USAGE:
#   ./uninstall_all.sh                   # uninstall ALL components (interactive)
#   ./uninstall_all.sh all               # same as above, no prompt
#   ./uninstall_all.sh cert-manager      # only cert-manager (safety-checked)
#   ./uninstall_all.sh strimzi           # only Strimzi operator
#   ./uninstall_all.sh opensearch-op     # only OpenSearch operator
#   ./uninstall_all.sh keycloak          # only Keycloak + Postgres
#   ./uninstall_all.sh kafka             # only Kafka
#   ./uninstall_all.sh opensearch        # only OpenSearch + Dashboards + its certs
#   ./uninstall_all.sh minio             # only MinIO
#   ./uninstall_all.sh coredns           # remove CoreDNS hosts entries
#
# Good for recovering from a failed install step — re-run the uninstall for
# that one component, then re-run the corresponding install script.

set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

TARGET="${1:-all}"

log() { echo "[uninstall] $*"; }

# --- Per-component uninstall functions ---------------------------------------

uninstall_cert_manager() {
    log "cert-manager:"
    OTHER_CERTS=$(kubectl get certificates -A --no-headers 2>/dev/null | awk '$1 !~ /^(azul|azul-infra)$/ {print $1"/"$2}')
    OTHER_ISSUERS=$(kubectl get issuers -A --no-headers 2>/dev/null | awk '$1 !~ /^(azul|azul-infra)$/ {print $1"/"$2}')
    OTHER_CLUSTER_ISSUERS=$(kubectl get clusterissuers --no-headers 2>/dev/null | awk '{print $1}')

    if [[ -n "$OTHER_CERTS" || -n "$OTHER_ISSUERS" || -n "$OTHER_CLUSTER_ISSUERS" ]]; then
        log "  KEPT — other consumers detected:"
        [[ -n "$OTHER_CERTS" ]]           && echo "$OTHER_CERTS"           | awk '{print "    Certificate: "$1}'
        [[ -n "$OTHER_ISSUERS" ]]         && echo "$OTHER_ISSUERS"         | awk '{print "    Issuer: "$1}'
        [[ -n "$OTHER_CLUSTER_ISSUERS" ]] && echo "$OTHER_CLUSTER_ISSUERS" | awk '{print "    ClusterIssuer: "$1}'
        log "  Force removal: helm uninstall cert-manager -n cert-manager"
    else
        helm uninstall cert-manager -n cert-manager 2>/dev/null && log "  removed" || log "  not found"
    fi
}

uninstall_strimzi() {
    log "Strimzi Kafka operator:"
    helm uninstall strimzi-kafka-operator -n kafka 2>/dev/null && log "  removed" || log "  not found"
    log "  (Strimzi CRDs kept — kafka namespace kept)"
}

uninstall_opensearch_op() {
    log "OpenSearch operator:"
    helm uninstall opensearch-operator -n opensearch-operator 2>/dev/null && log "  removed" || log "  not found"
}

uninstall_keycloak() {
    log "Keycloak + Postgres:"
    helm uninstall azul-keycloak -n azul-infra 2>/dev/null && log "  helm release removed" || log "  helm release not found"
    # Clean up the secret so re-install creates a fresh one
    kubectl -n azul-infra delete secret keycloak --ignore-not-found=true 2>/dev/null && log "  secret 'keycloak' removed"
}

uninstall_kafka() {
    log "Kafka:"
    helm uninstall azul-kafka -n azul-infra 2>/dev/null && log "  helm release removed" || log "  helm release not found"
}

uninstall_opensearch() {
    log "OpenSearch:"
    # Remove the Keycloak TLS cert created by setup-certs.sh
    kubectl -n azul-infra delete certificate keycloak-tls-cert --ignore-not-found=true 2>/dev/null && log "  keycloak-tls-cert removed"
    kubectl -n azul-infra delete secret keycloak-tls --ignore-not-found=true 2>/dev/null && log "  keycloak-tls secret removed"
    # Remove the admin/dashboard credential secrets so re-install creates fresh
    kubectl -n azul-infra delete secret azul-cluster-admincredentials --ignore-not-found=true 2>/dev/null
    kubectl -n azul-infra delete secret azul-cluster-dashboardcredentials --ignore-not-found=true 2>/dev/null
    helm uninstall azul-opensearch -n azul-infra 2>/dev/null && log "  helm release removed" || log "  helm release not found"
}

uninstall_minio() {
    log "MinIO:"
    helm uninstall azul-minio -n azul-infra 2>/dev/null && log "  helm release removed" || log "  helm release not found"
    kubectl -n azul-infra delete secret s3-keys --ignore-not-found=true 2>/dev/null
}

uninstall_coredns() {
    log "CoreDNS hosts entries:"
    COREFILE=$(kubectl -n kube-system get configmap coredns -o jsonpath='{.data.Corefile}' 2>/dev/null)
    if echo "$COREFILE" | grep -q "$KEYCLOAK_HOST"; then
        HOSTS_ENTRIES=$(echo "$COREFILE" | awk '/hosts \{/,/^    \}/' | grep -vE 'hosts \{|^    \}|fallthrough' | wc -l)
        EXPECTED=5
        if [[ "$HOSTS_ENTRIES" -eq "$EXPECTED" ]]; then
            kubectl -n kube-system get configmap coredns -o json | python3 -c "
import json, sys, re
cm = json.load(sys.stdin)
cm['data']['Corefile'] = re.sub(r'    hosts \{[^}]*fallthrough\n    \}\n', '', cm['data']['Corefile'])
cm['metadata'].pop('resourceVersion', None)
print(json.dumps(cm))
" | kubectl apply -f - >/dev/null
            kubectl -n kube-system rollout restart deployment/coredns >/dev/null
            kubectl -n kube-system rollout status deployment/coredns --timeout=60s >/dev/null 2>&1
            log "  removed"
        else
            log "  KEPT — hosts block has $HOSTS_ENTRIES entries (expected $EXPECTED). Edit manually:"
            log "    kubectl -n kube-system edit configmap coredns"
        fi
    else
        log "  (no Azul hosts entries found)"
    fi
}

show_leftovers() {
    echo ""
    echo "=== Leftover PVCs in azul-infra (data preserved) ==="
    LEFTOVER=$(kubectl -n azul-infra get pvc --no-headers 2>/dev/null)
    if [[ -n "$LEFTOVER" ]]; then
        echo "$LEFTOVER" | awk '{printf "  %-40s %-10s %s\n", $1, $2, $4}'
        echo "  (delete: kubectl -n azul-infra delete pvc --all)"
    else
        echo "  (none)"
    fi
    echo ""
    echo "=== Leftover namespaces ==="
    for ns in azul-infra kafka opensearch-operator cert-manager; do
        kubectl get ns "$ns" >/dev/null 2>&1 && echo "  $ns"
    done
}

# --- Dispatch ----------------------------------------------------------------

case "$TARGET" in
    all)
        if [[ -z "${1:-}" ]]; then
            echo "=== Uninstalling AZUL Infrastructure (ALL) ==="
            echo "This will remove all AZUL infra components. PVCs are kept by default."
            read -p "Continue? (y/N) " -r
            [[ "$REPLY" =~ ^[Yy]$ ]] || exit 0
        fi
        # Reverse order of install
        uninstall_minio
        uninstall_opensearch
        uninstall_kafka
        uninstall_keycloak
        uninstall_opensearch_op
        uninstall_strimzi
        uninstall_cert_manager
        uninstall_coredns
        show_leftovers
        ;;
    cert-manager)      uninstall_cert_manager ;;
    strimzi)           uninstall_strimzi ;;
    opensearch-op|opensearch-operator) uninstall_opensearch_op ;;
    keycloak)          uninstall_keycloak ;;
    kafka)             uninstall_kafka ;;
    opensearch)        uninstall_opensearch ;;
    minio)             uninstall_minio ;;
    coredns)           uninstall_coredns ;;
    -h|--help|help)
        grep -E "^#( |$)" "$0" | sed 's/^# \{0,1\}//'
        exit 0
        ;;
    *)
        echo "ERROR: unknown component: $TARGET"
        echo "Run '$0 --help' for usage."
        exit 1
        ;;
esac

echo ""
echo "=== Uninstall complete ==="
