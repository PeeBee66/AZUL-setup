#!/usr/bin/env bash
# 07 - Add host entries to CoreDNS
#
# CoreDNS is a cluster component provided by k3s/Talos — this script does NOT
# install it. It only patches the existing `coredns` configmap in kube-system
# to add static host entries so pods can resolve *.kp.local to the ingress IP.
#
# Required because pods can't reach external DNS (Pi-hole, corporate DNS, etc.)
# and Azul services talk to Keycloak via its public hostname (for OIDC token
# issuer matching — see README).
#
# Edit hostnames and CLUSTER_IP in config.sh before running.
#
# Optional: set COREDNS_IMAGE in config.sh to override the CoreDNS image
# (rarely needed — only if your k3s install uses a non-default image or you
# need to force-pull from a different registry).
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

echo "=== Configuring CoreDNS with Azul host entries ==="

# --- Pre-flight: verify CoreDNS is present and healthy ---
if ! kubectl -n kube-system get deployment coredns >/dev/null 2>&1; then
  echo "FATAL: No 'coredns' deployment found in kube-system namespace."
  echo "CoreDNS is a cluster component. Ensure your k3s/Talos cluster is healthy."
  exit 1
fi

READY=$(kubectl -n kube-system get deployment coredns -o jsonpath='{.status.readyReplicas}' 2>/dev/null || echo 0)
if [[ "${READY:-0}" -lt 1 ]]; then
  echo "WARNING: CoreDNS deployment is not Ready. Current state:"
  kubectl -n kube-system get pods -l k8s-app=kube-dns
  echo ""
  echo "Continuing anyway — the configmap patch will apply when CoreDNS recovers."
fi

# Show the currently deployed CoreDNS image (informational)
CURRENT_IMAGE=$(kubectl -n kube-system get deployment coredns \
  -o jsonpath='{.spec.template.spec.containers[0].image}' 2>/dev/null)
echo "CoreDNS image in use: $CURRENT_IMAGE"

# --- Check if hosts block already exists ---
EXISTING=$(kubectl -n kube-system get configmap coredns -o jsonpath='{.data.Corefile}' 2>/dev/null)
if echo "$EXISTING" | grep -q "$KEYCLOAK_HOST"; then
  echo "CoreDNS already has Azul host entries. Skipping."
  exit 0
fi

# --- Build the hosts block from config.sh variables ---
HOSTS_BLOCK="    hosts {
        ${CLUSTER_IP} ${KEYCLOAK_HOST}
        ${CLUSTER_IP} ${OPENSEARCH_HOST}
        ${CLUSTER_IP} ${MINIO_HOST}
        ${CLUSTER_IP} ${MINIO_API_HOST}
        ${CLUSTER_IP} ${AZUL_HOST}
        fallthrough
    }
"

# --- Patch the configmap ---
kubectl -n kube-system get configmap coredns -o json | \
  HOSTS_BLOCK="$HOSTS_BLOCK" python3 -c "
import json, sys, os, re
cm = json.load(sys.stdin)
corefile = cm['data']['Corefile']
hosts = os.environ['HOSTS_BLOCK']
corefile = re.sub(r'(    prometheus :\d+\n)', r'\1' + hosts, corefile)
cm['data']['Corefile'] = corefile
cm['metadata'].pop('resourceVersion', None)
json.dump(cm, sys.stdout)
" | kubectl apply -f -

# --- Optional: override CoreDNS image (only if COREDNS_IMAGE is set) ---
if [[ -n "${COREDNS_IMAGE:-}" ]]; then
  echo "Overriding CoreDNS image to: $COREDNS_IMAGE"
  kubectl -n kube-system set image deployment/coredns coredns="$COREDNS_IMAGE"
fi

# --- Restart and wait ---
echo "Restarting CoreDNS..."
kubectl -n kube-system rollout restart deployment/coredns

echo "Waiting for CoreDNS to become ready..."
if ! kubectl -n kube-system rollout status deployment/coredns --timeout=120s; then
  echo ""
  echo "FATAL: CoreDNS failed to roll out. Check pod status:"
  kubectl -n kube-system get pods -l k8s-app=kube-dns
  echo ""
  echo "Check pod events/logs:"
  kubectl -n kube-system describe pods -l k8s-app=kube-dns | tail -20
  exit 1
fi

# --- Verify name resolution works ---
echo "Verifying DNS resolution from inside the cluster..."
if kubectl run coredns-test --rm -i --restart=Never --image=busybox:latest \
     --command -- nslookup "$KEYCLOAK_HOST" 2>&1 | grep -q "$CLUSTER_IP"; then
  echo "  $KEYCLOAK_HOST resolves to $CLUSTER_IP ✓"
else
  echo "  WARNING: DNS test inconclusive (busybox may not be available offline)"
fi

echo "=== CoreDNS configured ==="
