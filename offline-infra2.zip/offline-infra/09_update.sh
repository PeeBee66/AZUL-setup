#!/usr/bin/env bash
# 09 - Update passwords and certificates after install
#
# Use this after editing config.sh to push changes to a running cluster.
#
# USAGE:
#   ./09_update.sh                  # interactive menu
#   ./09_update.sh passwords        # update Keycloak user passwords
#   ./09_update.sh certs            # force renewal of all TLS certs
#   ./09_update.sh coredns          # re-apply CoreDNS hosts entries
#   ./09_update.sh all              # everything
#
# WHAT EACH MODE DOES:
#
#   passwords:
#     - Sets TEST_USER password to TEST_PASSWORD
#     - Sets ADMIN_USER password to ADMIN_PASSWORD
#     - Does NOT change OpenSearch internal users (admin, kibanaserver, etc.)
#       — those require bcrypt hash regen in values.yaml + helm upgrade.
#       See "CHANGING OPENSEARCH PASSWORDS" below.
#
#   certs:
#     - Deletes the cert secrets. cert-manager auto-reissues within seconds.
#     - Targets: keycloak-tls, azul-opensearch-certs, azul-opensearch-admin-certs,
#       azul-opensearch-ca-cert (root CA — this cascades to ALL certs).
#     - Restarts pods that cache certs.
#
#   coredns:
#     - Re-reads hostnames from config.sh and re-applies the hosts block.
#     - Useful if you changed AZUL_HOST / KEYCLOAK_HOST in config.sh.
#
# CHANGING OPENSEARCH PASSWORDS (manual, not handled by this script):
#   1. Edit config.sh: change OS_ADMIN_PASS / OS_DASH_PASS
#   2. Generate new bcrypt hashes:
#        python3 -c "import bcrypt; print(bcrypt.hashpw(b'NEW_PASS', bcrypt.gensalt(12)).decode())"
#   3. Update values.yaml under opensearch.internalUsers (4 hashes to update)
#   4. Run: helm upgrade azul-opensearch ./charts/azul-infra -n azul-infra -f values.yaml \
#            --set keycloak.enable=false --set kafka.enable=false ...
#   5. Run: ./09_update.sh passwords (to update credential secrets)

set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

log() { echo "[update] $*"; }

# --- Password updates --------------------------------------------------------

update_keycloak_passwords() {
    log "Updating Keycloak user passwords from config.sh..."

    local pod kc_pass
    pod=$(kubectl -n "$NAMESPACE" get pods -l app=keycloak -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
    if [[ -z "$pod" ]]; then
        log "  ERROR: No Keycloak pod found in ${NAMESPACE}"
        return 1
    fi
    kc_pass=$(kubectl get secret keycloak -n "$NAMESPACE" -o jsonpath='{.data.KEYCLOAK_ADMIN_PASSWORD}' | base64 -d)

    kubectl -n "$NAMESPACE" exec "$pod" -- bash -c "
set -e
/opt/keycloak/bin/kcadm.sh config credentials \
  --server http://localhost:8080 --realm master \
  --user admin --password '${kc_pass}' 2>&1 | tail -1

echo 'Setting password for ${TEST_USER}...'
/opt/keycloak/bin/kcadm.sh set-password -r azul \
  --username '${TEST_USER}' --new-password '${TEST_PASSWORD}'

echo 'Setting password for ${ADMIN_USER}...'
/opt/keycloak/bin/kcadm.sh set-password -r azul \
  --username '${ADMIN_USER}' --new-password '${ADMIN_PASSWORD}'
" 2>&1 | sed 's/^/  /'

    log "  Verifying new passwords..."
    for u_p in "${TEST_USER}:${TEST_PASSWORD}" "${ADMIN_USER}:${ADMIN_PASSWORD}"; do
        local u=${u_p%:*} p=${u_p#*:}
        local resp
        resp=$(curl -k -s -X POST "https://${KEYCLOAK_HOST}/realms/azul/protocol/openid-connect/token" \
            --resolve "${KEYCLOAK_HOST}:443:${CLUSTER_IP}" \
            -H 'Content-Type: application/x-www-form-urlencoded' \
            -d "username=${u}&password=${p}&grant_type=password&client_id=azul-web&scope=openid")
        if echo "$resp" | grep -q '"access_token"'; then
            log "    ${u}: OK"
        else
            log "    ${u}: FAILED — $(echo "$resp" | python3 -c 'import sys,json; d=json.load(sys.stdin); print(d.get("error_description","unknown"))' 2>/dev/null)"
        fi
    done
}

# --- Certificate force renewal -----------------------------------------------

force_renew_cert() {
    local ns=$1 secret=$2 cert_name=${3:-}
    if kubectl -n "$ns" get secret "$secret" >/dev/null 2>&1; then
        log "  Deleting ${ns}/${secret} (cert-manager will re-issue)..."
        kubectl -n "$ns" delete secret "$secret" 2>&1 | sed 's/^/    /'
        # Wait for cert-manager to re-issue
        if [[ -n "$cert_name" ]]; then
            log "  Waiting for ${cert_name} to be re-issued..."
            kubectl -n "$ns" wait certificate/"$cert_name" --for=condition=Ready --timeout=60s 2>&1 | sed 's/^/    /' || \
                log "    (cert-manager may take a few more seconds)"
        fi
    else
        log "  ${ns}/${secret} not found — skipping"
    fi
}

update_certs() {
    log "Forcing certificate renewal..."
    log ""

    # Child certs first (safer — CA stays valid)
    log "Keycloak ingress cert (keycloak-tls):"
    force_renew_cert "$NAMESPACE" "keycloak-tls" "keycloak-tls-cert"

    log "Azul web ingress cert (azul-web-tls):"
    force_renew_cert "azul" "azul-web-tls" "azul-web-tls"

    log "OpenSearch node certs (azul-opensearch-certs):"
    force_renew_cert "$NAMESPACE" "azul-opensearch-certs" "azul-opensearch-certs"

    log "OpenSearch admin certs (azul-opensearch-admin-certs):"
    force_renew_cert "$NAMESPACE" "azul-opensearch-admin-certs" "azul-opensearch-admin-certs"

    log ""
    log "Restarting pods that need new certs..."
    # Restart OpenSearch to pick up new node certs
    kubectl -n "$NAMESPACE" delete pod azul-opensearch-nodes-0 --wait=false 2>/dev/null && log "  opensearch restarted"
    # Restart Keycloak so nginx ingress re-reads the TLS secret
    # (ingress auto-detects via mounted secret, but restart forces it)
    kubectl -n "$NAMESPACE" rollout restart deployment/keycloak 2>/dev/null && log "  keycloak restarted"
    # Restart azul pods that mounted the CA
    if kubectl get ns azul >/dev/null 2>&1; then
        kubectl -n azul rollout restart deployment --all 2>/dev/null && log "  azul deployments restarted"
    fi
    log "  (not restarting nginx ingress — it auto-reloads TLS secrets)"
}

# --- CoreDNS re-apply --------------------------------------------------------

update_coredns() {
    log "Re-applying CoreDNS hosts entries from config.sh..."
    "${SCRIPT_DIR}/07_setup_coredns.sh" 2>&1 | sed 's/^/  /' || true

    # If the entries already exist with OLD hostnames, 07 skips.
    # Force a re-write by removing first.
    COREFILE=$(kubectl -n kube-system get configmap coredns -o jsonpath='{.data.Corefile}' 2>/dev/null)
    if echo "$COREFILE" | grep -q "$KEYCLOAK_HOST"; then
        log "  (entries for $KEYCLOAK_HOST already present)"
    else
        log "  Force-removing old hosts block and re-adding..."
        kubectl -n kube-system get configmap coredns -o json | python3 -c "
import json, sys, re
cm = json.load(sys.stdin)
cm['data']['Corefile'] = re.sub(r'    hosts \{[^}]*fallthrough\n    \}\n', '', cm['data']['Corefile'])
cm['metadata'].pop('resourceVersion', None)
print(json.dumps(cm))
" | kubectl apply -f - >/dev/null
        "${SCRIPT_DIR}/07_setup_coredns.sh" 2>&1 | sed 's/^/  /'
    fi
}

# --- Menu --------------------------------------------------------------------

show_menu() {
    echo ""
    echo "=== AZUL Update Script ==="
    echo "Choose what to update:"
    echo "  1) Passwords    (Keycloak user passwords from config.sh)"
    echo "  2) Certs        (force renewal of all TLS certs)"
    echo "  3) CoreDNS      (re-apply hosts entries from config.sh)"
    echo "  4) All"
    echo "  q) Quit"
    echo ""
    read -p "Selection: " -r choice
    case "$choice" in
        1) update_keycloak_passwords ;;
        2) update_certs ;;
        3) update_coredns ;;
        4) update_keycloak_passwords; update_certs; update_coredns ;;
        q|Q) exit 0 ;;
        *) echo "Invalid selection"; exit 1 ;;
    esac
}

# --- Dispatch ----------------------------------------------------------------

MODE="${1:-}"

case "$MODE" in
    passwords|password|pass) update_keycloak_passwords ;;
    certs|cert)              update_certs ;;
    coredns|dns)             update_coredns ;;
    all)
        update_keycloak_passwords
        echo ""
        update_certs
        echo ""
        update_coredns
        ;;
    -h|--help|help)
        grep -E "^#( |$)" "$0" | sed 's/^# \{0,1\}//'
        exit 0
        ;;
    "")
        show_menu
        ;;
    *)
        echo "ERROR: unknown mode: $MODE"
        echo "Run '$0 --help' for usage."
        exit 1
        ;;
esac

echo ""
echo "[update] === Update complete ==="
