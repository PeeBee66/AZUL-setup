#!/usr/bin/env bash
# 01 - Install AZUL Plugins (upgrade from core-only to core + plugins)
# Requires: AZUL core already running (offline-core installed first)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/azul"
VALUES="${SCRIPT_DIR}/values.yaml"

IMAGE_ARGS=(
  --set images.customRegistry="$AZUL_IMAGE_REGISTRY"
  --set images.external.redis="$IMG_REDIS"
  --set images.external.tika_external="$IMG_TIKA"
  --set images.external.git-sync="$IMG_GIT_SYNC"
)

echo "=== Installing AZUL Plugins ==="

helm upgrade azul "$CHART" \
  -n "$NAMESPACE" \
  -f "$VALUES" \
  --set "web.ingress.hosts[0]=${AZUL_HOST}" \
  --set "security.oidc.authority_url=https://${KEYCLOAK_HOST}/realms/azul" \
  --set-string "recovery.externalS3Endpoint=${EXTERNAL_S3_ENDPOINT}" \
  --set-string "recovery.externalS3Secure=${EXTERNAL_S3_SECURE}" \
  "${IMAGE_ARGS[@]}"

echo ""
echo "Plugins are deploying. This adds ~50 pods and takes several minutes."
echo "Monitor with:"
echo "  kubectl -n $NAMESPACE get pods -w"
echo "  kubectl -n $NAMESPACE get pods | grep -v Running"

echo "=== AZUL Plugins installed ==="
