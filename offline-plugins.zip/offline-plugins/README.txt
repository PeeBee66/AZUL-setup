AZUL Plugins - Offline Install Package
======================================

Target: k3s cluster (air-gapped)
Prerequisite: offline-core must be installed and running first.

BEFORE YOU START
----------------
1. Load all container images from images.txt into your registry
2. Edit config.sh:
   - Set REGISTRY to your offline registry
3. Edit values.yaml:
   - Same edits as offline-core (hostnames, storage, ingress)
   - Enable/disable individual plugins in the plugins: section

INSTALL
-------
  ./01_install_plugins.sh

This does a helm upgrade on the existing "azul" release, switching
pluginsEnabled from false to true. Adds ~50 pods.

DOWNGRADE (remove plugins, keep core)
--------------------------------------
  ./uninstall.sh

CONTENTS
--------
  config.sh          # Registry setting
  values.yaml        # Full values with plugins enabled
  charts/azul/       # AZUL application Helm chart (v9.0.0)
  images.txt         # Plugin container images to pull
