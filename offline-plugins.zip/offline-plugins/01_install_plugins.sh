#!/usr/bin/env bash
# 01 - Install AZUL Plugins (upgrade from core-only to core + plugins)
# Requires: AZUL core already running (offline-core installed first)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/azul"
VALUES="${SCRIPT_DIR}/values.yaml"

REGISTRY_ARGS=()
if [[ -n "$REGISTRY" ]]; then
  REGISTRY_ARGS=(
    --set images.customRegistry="${REGISTRY}/asdazul/"
  )
fi

echo "=== Installing AZUL Plugins ==="

# This is a helm upgrade — same release name "azul", new values with pluginsEnabled: true
helm upgrade azul "$CHART" \
  -n "$NAMESPACE" \
  -f "$VALUES" \
  "${REGISTRY_ARGS[@]}"

echo ""
echo "Plugins are deploying. This adds ~50 pods and takes several minutes."
echo "Monitor with:"
echo "  kubectl -n $NAMESPACE get pods -w"
echo "  kubectl -n $NAMESPACE get pods | grep -v Running"

echo "=== AZUL Plugins installed ==="
