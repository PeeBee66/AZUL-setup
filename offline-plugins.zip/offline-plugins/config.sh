#!/usr/bin/env bash
# Shared config for AZUL plugins install.
# Edit these values for your target environment.

# --- Container Registry ---
# Set to your offline registry (e.g. "myregistry.local:5000")
# Leave empty to pull from upstream (internet required).
REGISTRY=""

# --- Kubernetes ---
NAMESPACE="azul"
