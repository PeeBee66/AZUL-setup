#!/usr/bin/env bash
# Downgrade back to core-only (remove plugins)
# This does NOT uninstall AZUL — it re-applies the core-only values.
set -uo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=== Removing AZUL Plugins (downgrade to core-only) ==="
echo "This will helm upgrade with pluginsEnabled: false."
echo "Use offline-core/uninstall.sh to fully remove AZUL."
read -p "Continue? (y/N) " -r
[[ "$REPLY" =~ ^[Yy]$ ]] || exit 0

# Point to the core values if available, otherwise warn
CORE_VALUES="../offline-core/values.yaml"
if [[ ! -f "$CORE_VALUES" ]]; then
  echo "ERROR: Cannot find ${CORE_VALUES}"
  echo "To remove plugins, run: helm upgrade azul <chart> -n azul -f <core-values.yaml>"
  exit 1
fi

helm upgrade azul "${SCRIPT_DIR}/charts/azul" -n azul -f "$CORE_VALUES"
echo "=== Plugins removed, core-only running ==="
