#!/usr/bin/env bash
# Shared config for AZUL core app install.
# Edit these values for your target environment.

# --- Container Registry ---
# Set to your offline registry (e.g. "myregistry.local:5000")
# Leave empty to pull from upstream (internet required).
REGISTRY=""

# --- Kubernetes ---
NAMESPACE="azul"
INFRA_NAMESPACE="azul-infra"

# --- Hostnames ---
AZUL_HOST="azul.kp.local"
KEYCLOAK_HOST="keycloak-azul.kp.local"

# --- Credentials ---
# OpenSearch writer password (must match bcrypt hash in infra values.yaml azul_writer user)
OS_WRITER_PASS="cuvJ7K09EgApwfV2o9rQ7avR554uRP7e"
# bcrypt: $2b$12$5887eR1nNYkgcn/GHHs/8OHQpDCMhlCamvEyyHf7QGlbaAYAf5DXi

# MinIO keys (must match the s3-keys secret in azul-infra namespace)
S3_ACCESS_KEY="b26340be283b45acc0ba6afbf2789800"
S3_SECRET_KEY="38fbf2b72e819df4e9d7dbfaecf9983f20dae7a6ebec0611410af9331caf361e"

# Backup MinIO (external, on host — for recovery feature)
BACKUP_S3_USER="azul-backup"
BACKUP_S3_PASSWORD="azul-backup-secret"
