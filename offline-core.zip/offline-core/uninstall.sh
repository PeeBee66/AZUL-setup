#!/usr/bin/env bash
# Uninstall AZUL Core Application
set -uo pipefail

echo "=== Uninstalling AZUL Core ==="
read -p "Continue? (y/N) " -r
[[ "$REPLY" =~ ^[Yy]$ ]] || exit 0

helm uninstall azul -n azul 2>/dev/null && echo "  azul removed" || echo "  azul not found"

echo ""
echo "PVCs and secrets are still present. To fully clean:"
echo "  kubectl -n azul delete pvc --all"
echo "  kubectl -n azul delete secrets --all"
echo "  kubectl delete namespace azul"
echo "=== Uninstall complete ==="
