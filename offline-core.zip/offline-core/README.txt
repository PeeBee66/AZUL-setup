AZUL Core Application - Offline Install Package
================================================

Target: k3s cluster (air-gapped)
Prerequisite: offline-infra must be installed and running first.

BEFORE YOU START
----------------
1. Load all container images from images.txt into your registry
2. Edit config.sh:
   - Set REGISTRY to your offline registry
   - Set hostnames (AZUL_HOST, KEYCLOAK_HOST)
   - Set credentials (must match what infra was deployed with)
3. Edit values.yaml for your environment:
   - web.ingress.hosts (line 185) -> your azul hostname
   - security.oidc.authority_url (line 414) -> your keycloak hostname
   - storageClassName (line 17) -> your storage class
   - ingressClassName (line 186) -> your ingress class

INSTALL
-------
  ./01_install_core.sh

This creates: namespace, secrets, CA configmap, web TLS cert, then helm installs.
Metastore ingest pods crash-loop 3-4 times on startup — this is NORMAL (race with dispatchers).

UNINSTALL
---------
  ./uninstall.sh

CONTENTS
--------
  config.sh          # Registry, hostnames, credentials
  values.yaml        # Helm values (edit hostnames, storage, ingress)
  charts/azul/       # AZUL application Helm chart (v9.0.0)
  images.txt         # Container images to pull
