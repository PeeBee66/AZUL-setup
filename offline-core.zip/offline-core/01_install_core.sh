#!/usr/bin/env bash
# 01 - Install AZUL Core Application
# Requires: infra running (azul-infra namespace with Kafka, OpenSearch, MinIO, Keycloak)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/config.sh"

CHART="${SCRIPT_DIR}/charts/azul"
VALUES="${SCRIPT_DIR}/values.yaml"

REGISTRY_ARGS=()
if [[ -n "$REGISTRY" ]]; then
  REGISTRY_ARGS=(
    --set images.customRegistry="${REGISTRY}/asdazul/"
  )
fi

echo "=== Installing AZUL Core Application ==="

# --- Create namespace ---
kubectl create namespace "$NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -

# --- Create secrets ---

# Copy MinIO keys from infra namespace
if ! kubectl -n "$NAMESPACE" get secret s3-keys >/dev/null 2>&1; then
  echo "Copying s3-keys from ${INFRA_NAMESPACE}..."
  kubectl get secret s3-keys -n "$INFRA_NAMESPACE" -o json \
    | python3 -c "
import sys, json
s = json.load(sys.stdin)
s['metadata'] = {'name': 's3-keys', 'namespace': '${NAMESPACE}'}
print(json.dumps(s))
" | kubectl apply -f -
fi

# Redis
if ! kubectl -n "$NAMESPACE" get secret redis >/dev/null 2>&1; then
  REDIS_PASS=$(openssl rand -base64 16)
  echo "Creating redis secret..."
  kubectl -n "$NAMESPACE" create secret generic redis \
    --from-literal=redis-username="" \
    --from-literal=redis-password="$REDIS_PASS" \
    --from-literal=password="$REDIS_PASS"
fi

# Metastore credentials (OpenSearch writer)
if ! kubectl -n "$NAMESPACE" get secret metastore-creds >/dev/null 2>&1; then
  echo "Creating metastore-creds secret..."
  kubectl -n "$NAMESPACE" create secret generic metastore-creds \
    --from-literal=writer="$OS_WRITER_PASS"
fi

# S3 backup keys (for recovery feature)
if ! kubectl -n "$NAMESPACE" get secret s3-backup-keys >/dev/null 2>&1; then
  echo "Creating s3-backup-keys secret..."
  kubectl -n "$NAMESPACE" create secret generic s3-backup-keys \
    --from-literal=access_key="$BACKUP_S3_USER" \
    --from-literal=secret_key="$BACKUP_S3_PASSWORD"
fi

# --- CA certificate configmap (pods need to trust OpenSearch self-signed cert) ---
if ! kubectl -n "$NAMESPACE" get configmap azul-ca-cert >/dev/null 2>&1; then
  echo "Creating azul-ca-cert configmap from infra CA..."
  kubectl get secret azul-opensearch-ca-cert -n "$INFRA_NAMESPACE" \
    -o jsonpath='{.data.ca\.crt}' | base64 -d > /tmp/azul-ca-cert.pem
  kubectl -n "$NAMESPACE" create configmap azul-ca-cert --from-file=ca.crt=/tmp/azul-ca-cert.pem
  rm -f /tmp/azul-ca-cert.pem
fi

# --- Web TLS certificate (signed by OpenSearch CA) ---
if ! kubectl -n "$NAMESPACE" get secret azul-web-tls >/dev/null 2>&1; then
  echo "Creating web TLS certificate..."

  # Copy CA secret to azul namespace (issuer is namespace-scoped)
  if ! kubectl -n "$NAMESPACE" get secret azul-opensearch-ca-cert >/dev/null 2>&1; then
    kubectl get secret azul-opensearch-ca-cert -n "$INFRA_NAMESPACE" -o json \
      | python3 -c "
import sys, json
s = json.load(sys.stdin)
s['metadata'] = {'name': 'azul-opensearch-ca-cert', 'namespace': '${NAMESPACE}'}
print(json.dumps(s))
" | kubectl apply -f -
  fi

  # Create CA Issuer in azul namespace
  kubectl apply -f - <<EOF
apiVersion: cert-manager.io/v1
kind: Issuer
metadata:
  name: azul-ca-issuer
  namespace: ${NAMESPACE}
spec:
  ca:
    secretName: azul-opensearch-ca-cert
EOF

  # Create web TLS cert
  kubectl apply -f - <<EOF
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: azul-web-tls
  namespace: ${NAMESPACE}
spec:
  secretName: azul-web-tls
  issuerRef:
    name: azul-ca-issuer
    kind: Issuer
  dnsNames:
    - ${AZUL_HOST}
  duration: 8760h
  renewBefore: 720h
EOF
  kubectl -n "$NAMESPACE" wait certificate/azul-web-tls --for=condition=Ready --timeout=60s
fi

# --- Install chart ---
echo "Installing azul chart (core only, plugins disabled)..."
helm install azul "$CHART" \
  -n "$NAMESPACE" \
  -f "$VALUES" \
  "${REGISTRY_ARGS[@]}"

echo ""
echo "Waiting for core pods (metastore ingest pods may crash-loop 3-4 times on startup — this is normal)..."
echo "Monitor with:"
echo "  kubectl -n $NAMESPACE get pods -w"

echo "=== AZUL Core installed ==="
